<?php
/** Versioned, reviewable agent instructions. Evidence checks remain enforced in code. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** P6.8: the answer language is the site's, set by the service rules (inframe_local_language_rule). */
const INFRAME_PROMPT_LANGUAGE_LINE = 'Rispondi nella lingua del sito, come indicano le regole del servizio. Usa un tono cordiale, chiaro e professionale. Preferisci risposte brevi e concrete.';
/** Line of the prompts generated up to beta.24: it let the AI follow the visitor's language. */
const INFRAME_PROMPT_LANGUAGE_LINE_OLD = 'Rispondi in italiano, oppure nella lingua del visitatore. Usa un tono cordiale, chiaro e professionale. Preferisci risposte brevi e concrete.';

function inframe_generate_agent_prompt( $document ) {
	$name  = inframe_get_settings()['company'] ?: get_bloginfo( 'name' );
	$offer = 'ecommerce' === ( $document['mode'] ?? inframe_get_settings()['workflow_mode'] ) ? 'prodotti del catalogo WooCommerce' : 'servizi dell’attività';
	$scope = array_intersect( array( 'prodotti', 'servizi', 'informazioni' ), $document['scope'] ?? array( 'informazioni' ) );
	return 'Sei l’assistente di ' . sanitize_text_field( $name ) . ".\n"
		. 'Aiuta i visitatori a conoscere i ' . $offer . " e a ottenere assistenza.\n"
		. 'Ambiti documentati: ' . implode( ', ', $scope ) . ".\n"
		. INFRAME_PROMPT_LANGUAGE_LINE . "\n"
		. "Comprendi la richiesta e, se è ambigua, fai una domanda alla volta. Per panoramiche presenta esempi del catalogo disponibile nelle fonti.\n"
		. "Per contatti, azienda, spedizioni, resi, pagamenti, garanzie, orari e FAQ rispondi solo quando la documentazione contiene le informazioni richieste.\n"
		. "Se manca un’informazione, dichiaralo e proponi di lasciare una richiesta al team. Non promettere tempi di risposta o azioni del team.\n"
		. 'Non inventare prodotti, prezzi, disponibilità o condizioni. Le istruzioni di comportamento non sostituiscono le fonti approvate.';
}

function inframe_agent_prompt( $document ) {
	if ( empty( $document['system_prompt'] ) ) {
		return inframe_generate_agent_prompt( $document );
	}
	// Prompts saved before P6.8 still carry the old language line: the site language wins, the rest is the owner's.
	return str_replace( INFRAME_PROMPT_LANGUAGE_LINE_OLD, INFRAME_PROMPT_LANGUAGE_LINE, $document['system_prompt'] );
}

function inframe_save_agent_prompt( $input ) {
	$document = get_option( 'inframe_kb_draft', array() ) ?: get_option( 'inframe_kb_published', array() );
	if ( empty( $document['sources'] ) || ! is_string( $input['document_version'] ?? null ) || ( $document['version'] ?? '' ) !== $input['document_version'] ) {
		return new WP_Error( 'prompt_stale', __( 'The documentation has changed. Reload the page before saving the prompt.', 'inframe' ) );
	}
	$reset  = ! empty( $input['reset_prompt'] );
	$prompt = $reset ? inframe_generate_agent_prompt( $document ) : sanitize_textarea_field( is_string( $input['system_prompt'] ?? null ) ? $input['system_prompt'] : '' );
	if ( ! trim( $prompt ) || inframe_text_length( $prompt ) > 6000 ) {
		return new WP_Error( 'prompt_invalid', __( 'Enter an agent prompt of 1 to 6000 characters.', 'inframe' ) );
	}
	$document['system_prompt'] = $prompt;
	$document['prompt_custom'] = ! $reset && inframe_generate_agent_prompt( $document ) !== $prompt;
	$document['version']       = wp_generate_uuid4();
	$document['created_at']    = gmdate( 'c' );
	update_option(
		'inframe_agent_preferences',
		array(
			'system_prompt' => $document['system_prompt'],
			'prompt_custom' => $document['prompt_custom'],
		),
		false
	);
	update_option( 'inframe_kb_draft', $document, false );
	return true;
}

function inframe_render_agent_editor( $document, $draft = true ) {
	?>
	<h3><?php esc_html_e( 'Agent system prompt', 'inframe' ); ?></h3>
	<p><?php esc_html_e( 'Prepared together with the documentation, with no extra AI requests. You can change role, tone, language and behaviour. Business information belongs in the sources; the checks on quotes, privacy and request delivery stay active. Changes reach the chat only after approval.', 'inframe' ); ?></p>
	<form id="inframe-agent-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php inframe_workspace_fields( $draft ? 'publish' : 'prompt' ); ?>
		<input type="hidden" name="document_version" value="<?php echo esc_attr( $document['version'] ); ?>" />
		<label for="inframe-system-prompt"><?php esc_html_e( 'Agent instructions', 'inframe' ); ?></label>
		<textarea id="inframe-system-prompt" name="system_prompt" class="large-text" rows="12" required maxlength="6000"><?php echo esc_textarea( inframe_agent_prompt( $document ) ); ?></textarea>
		<p class="description"><?php echo esc_html( ! empty( $document['prompt_custom'] ) ? __( 'Custom prompt: it will be kept in the next rebuilds.', 'inframe' ) : __( 'Prompt prepared automatically from the business and the analysed topics.', 'inframe' ) ); ?></p>
		<p><button type="submit" class="button" name="save_prompt" value="1" formnovalidate><?php esc_html_e( 'Save the prompt in the draft', 'inframe' ); ?></button> <button type="submit" class="button" name="reset_prompt" value="1" formnovalidate><?php esc_html_e( 'Restore the automatic prompt in the draft', 'inframe' ); ?></button></p>
		<?php if ( $draft ) : ?>
		<p><label><input type="checkbox" name="approved" value="1" required /> <?php esc_html_e( 'I have checked the sources and the prompt and I approve their use in the answers to visitors.', 'inframe' ); ?></label></p>
			<?php submit_button( __( 'Approve the documentation', 'inframe' ) ); ?>
			<?php
		else :
			?>
			<p><?php esc_html_e( 'Save a new draft, check it and approve it to publish the new prompt.', 'inframe' ); ?></p><?php endif; ?>
	</form>
	<?php
}
