<?php
/** Panel actions (admin-post and Ajax) and the lead and question lists shown by the panel pages. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_workspace_unanswered_questions() {
	$questions = inframe_local_unanswered_questions();
	echo '<section id="inframe-unanswered-questions">';
	echo '<p>' . esc_html__( 'Shows up to 50 distinct questions still present in the sessions kept for one day; questions sent as a contact request or already expired do not appear. Emails, links and long numbers are masked. The text may still contain personal data: use it only to fix the sources and the chat.', 'inframe' ) . '</p>';
	/* translators: %s: number of unanswered questions. */
	echo '<p><strong>' . esc_html( sprintf( _n( '%s unanswered question in the temporary sessions', '%s unanswered questions in the temporary sessions', count( $questions ), 'inframe' ), number_format_i18n( count( $questions ) ) ) ) . '</strong></p>';
	if ( ! $questions ) {
		echo '<p>' . esc_html__( 'No unanswered questions recorded in the available sessions.', 'inframe' ) . '</p>';
	} else {
		$test = inframe_admin_url( 'inframe-sources', array( 'tab' => 'test' ) );
		echo '<ol>';
		foreach ( $questions as $item ) {
			echo '<li><strong>' . esc_html( $item['question'] ) . '</strong> — <code>' . esc_html( $item['diagnostic'] ) . '</code>';
			if ( $item['retrieval_status'] ) {
				echo ' (<code>' . esc_html( $item['retrieval_status'] ) . '</code>)';
			}
			if ( $item['count'] > 1 ) {
				/* translators: %s: how many times the question was asked. */
				echo ' ' . esc_html( sprintf( _n( '(%s time)', '(%s times)', (int) $item['count'], 'inframe' ), number_format_i18n( $item['count'] ) ) );
			}
			// POST, not a query string: the question may contain personal data and must not reach access logs.
			echo ' <form class="inframe-inline" method="post" action="' . esc_url( $test ) . '"><input type="hidden" name="inframe_question" value="' . esc_attr( $item['question'] ) . '" /><button type="submit" class="button-link" data-inframe-retry-question="' . esc_attr( $item['question'] ) . '">' . esc_html__( 'Try it in the sources', 'inframe' ) . '</button></form> · ';
			inframe_faq_draft_button( $item['question'] );
			echo '</li>';
		}
		echo '</ol>';
	}
	echo '</section>';
}

/** "Create FAQ draft" (P6.5): POST, so the question never reaches the address bar or the access logs. */
function inframe_faq_draft_button( $question ) {
	echo '<form class="inframe-inline" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	inframe_workspace_fields( 'faq_draft' );
	echo '<input type="hidden" name="question" value="' . esc_attr( $question ) . '" /><button type="submit" class="button-link" data-inframe-faq-question="' . esc_attr( $question ) . '">' . esc_html__( 'Create FAQ draft', 'inframe' ) . '</button></form>';
}

/** P6.9: answers voted unhelpful in the last day, and the sources unhelpful answers cited in the last 30 days. */
function inframe_workspace_unhelpful_answers() {
	global $wpdb;
	$items   = inframe_local_unhelpful_answers();
	$summary = inframe_feedback_summary();
	$ids     = array_unique( array_merge( array_keys( $summary['down_sources'] ), ...array_column( $items, 'source_ids' ) ?: array( array() ) ) );
	$titles  = array();
	foreach ( $ids as $id ) {
		$titles[ $id ] = (string) $wpdb->get_var( $wpdb->prepare( "SELECT title FROM {$wpdb->prefix}inframe_sources WHERE id = %d", $id ) );
	}
	$title = static function ( $id ) use ( $titles ) {
		/* translators: %s: ID of a source that no longer exists. */
		return '' !== ( $titles[ $id ] ?? '' ) ? $titles[ $id ] : sprintf( __( 'source #%s (removed)', 'inframe' ), $id );
	};
	echo '<section id="inframe-unhelpful-answers"><h2>' . esc_html__( 'Unhelpful answers', 'inframe' ) . '</h2>';
	echo '<p>' . esc_html__( 'The answers that visitors marked as unhelpful in the sessions kept for one day, with the question masked as above. The vote is kept for 13 months without text; the question and the answer only for one day.', 'inframe' ) . '</p>';
	if ( ! $items ) {
		echo '<p>' . esc_html__( 'No answers marked as unhelpful in the available sessions.', 'inframe' ) . '</p>';
	} else {
		echo '<ol>';
		foreach ( $items as $item ) {
			echo '<li><strong>' . esc_html( $item['question'] ) . '</strong> ';
			inframe_faq_draft_button( $item['question'] );
			echo '<br />' . esc_html( $item['answer'] );
			if ( $item['source_ids'] ) {
				/* translators: %s: comma-separated list of source titles. */
				echo '<br /><span class="description">' . esc_html( sprintf( __( 'Cited sources: %s', 'inframe' ), implode( ', ', array_map( $title, $item['source_ids'] ) ) ) ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ol>';
	}
	echo '<h3>' . esc_html__( 'Sources cited in unhelpful answers (last 30 days)', 'inframe' ) . '</h3>';
	if ( ! $summary['down_sources'] ) {
		echo '<p>' . esc_html_x( 'None.', 'cited sources', 'inframe' ) . '</p>';
	} else {
		echo '<ul>';
		foreach ( array_slice( $summary['down_sources'], 0, 10, true ) as $id => $count ) {
			/* translators: 1: source title, 2: how many times it was cited in unhelpful answers. */
			echo '<li>' . esc_html( sprintf( _n( '%1$s — %2$s time', '%1$s — %2$s times', (int) $count, 'inframe' ), $title( $id ), number_format_i18n( $count ) ) ) . '</li>';
		}
		echo '</ul><p><a href="' . esc_url( inframe_admin_url( 'inframe-sources' ) ) . '">' . esc_html__( 'Check the sources', 'inframe' ) . '</a></p>';
	}
	echo '</section>';
}

/** A CSV cell for Excel: a value that starts like a formula is neutralised with an apostrophe (P6.9). */
function inframe_csv_line( $cells ) {
	$out = array();
	foreach ( $cells as $cell ) {
		$cell  = (string) $cell;
		$cell  = preg_match( '/^[=+\-@\t\r]/', $cell ) ? "'" . $cell : $cell;
		$out[] = preg_match( '/[;"\r\n]/', $cell ) ? '"' . str_replace( '"', '""', $cell ) . '"' : $cell;
	}
	return implode( ';', $out ) . "\r\n";
}

/** The leads as CSV for Excel, in the site language: UTF-8 mark, semicolons, last visitor question only (P6.9). */
function inframe_leads_csv( $filter = '' ) {
	global $wpdb;
	$table   = $wpdb->prefix . 'inframe_leads';
	$rows    = 'undelivered' === $filter
		? $wpdb->get_results( $wpdb->prepare( "SELECT id, payload, delivery, created_at FROM %i WHERE delivery <> 'accepted' ORDER BY id DESC", $table ), ARRAY_A )
		: $wpdb->get_results( $wpdb->prepare( 'SELECT id, payload, delivery, created_at FROM %i ORDER BY id DESC', $table ), ARRAY_A );
	$headers = array(
		_x( 'ID', 'CSV column', 'inframe' ),
		_x( 'Date', 'CSV column', 'inframe' ),
		_x( 'Name', 'CSV column', 'inframe' ),
		_x( 'Email', 'CSV column', 'inframe' ),
		_x( 'Phone', 'CSV column', 'inframe' ),
		_x( 'Delivery status', 'CSV column', 'inframe' ),
		_x( 'Consent', 'CSV column', 'inframe' ),
		_x( 'Consent version', 'CSV column', 'inframe' ),
		_x( 'Last question', 'CSV column', 'inframe' ),
	);
	$csv     = "\xEF\xBB\xBF" . inframe_csv_line( $headers );
	foreach ( $rows as $row ) {
		$p        = json_decode( $row['payload'], true ) ?: array();
		$question = '';
		foreach ( (array) ( $p['conversation'] ?? array() ) as $message ) {
			if ( is_array( $message ) && 'user' === ( $message['role'] ?? '' ) && is_string( $message['text'] ?? null ) ) {
				$question = $message['text'];
			}
		}
		$consented = isset( $p['consented_at'] ) ? strtotime( (string) $p['consented_at'] ) : false;
		$csv      .= inframe_csv_line(
			array(
				$row['id'],
				wp_date( 'Y-m-d H:i', strtotime( $row['created_at'] . ' UTC' ) ),
				$p['name'] ?? '',
				$p['email'] ?? '',
				$p['phone'] ?? '',
				'accepted' === $row['delivery'] ? __( 'Accepted by the email service', 'inframe' ) : __( 'To be retried', 'inframe' ),
				$consented ? wp_date( 'Y-m-d H:i', $consented ) : '',
				$p['consent_version'] ?? '',
				function_exists( 'mb_substr' ) ? mb_substr( $question, 0, 500 ) : substr( $question, 0, 500 ),
			)
		);
	}
	return $csv;
}

function inframe_workspace_readiness( $s ) {
	$issues  = inframe_frontend_setup_issues( $s );
	$blocked = 'off' === $s['display_mode'] || $issues;
	?>
	<div id="inframe-readiness" class="notice inline <?php echo $blocked ? 'notice-warning' : 'notice-success'; ?>" role="status">
		<p><strong><?php echo esc_html( $blocked ? __( 'The chat is hidden.', 'inframe' ) : ( 'live' === $s['display_mode'] ? __( 'The chat is ready for the public.', 'inframe' ) : __( 'The chat is ready for the private test.', 'inframe' ) ) ); ?></strong></p>
		<?php
		if ( 'off' === $s['display_mode'] ) :
			?>
			<p><?php esc_html_e( 'Below, choose “Test only” or “Public” and press “Save visibility”.', 'inframe' ); ?></p><?php endif; ?>
		<?php
		if ( $issues ) :
			?>
			<ul>
			<?php
			foreach ( $issues as $issue ) :
				?>
			<li><?php echo esc_html( $issue ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		<?php
		if ( 'all' !== $s['visibility'] ) :
			?>
			<p>
			<?php
			/* translators: %s: URL of the Appearance › Where it appears page. */
			echo wp_kses( sprintf( __( 'A page filter is active. Check <a href="%s">Appearance › Where it appears</a>: the chat appears only where allowed, or on the pages with its block or shortcode.', 'inframe' ), esc_url( inframe_admin_url( 'inframe-appearance', array( 'tab' => 'where' ) ) ) ), inframe_notice_html() );
			?>
			</p><?php endif; ?>
		<?php if ( ! $blocked ) : ?>
			<p><?php echo esc_html( 'test' === $s['display_mode'] ? __( 'Visitors do not see it: use “Open the test chat” below.', 'inframe' ) : __( 'Open a page of the site and wait about 3 seconds. If it does not appear, clear the cache of the site and of any CDN, then reload the page.', 'inframe' ) ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function inframe_workspace_fields( $operation ) {
	echo '<input type="hidden" name="action" value="inframe_workspace" /><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '" />';
	wp_nonce_field( 'inframe_workspace' );
	inframe_admin_return_field();
}

function inframe_workspace_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Access denied.', 'inframe' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'inframe_workspace' );
	global $wpdb;
	$input     = wp_unslash( $_POST );
	$operation = sanitize_key( $input['operation'] ?? '' );
	$result    = true;
	$message   = __( 'Operation completed.', 'inframe' );
	switch ( $operation ) {
		case 'provider':
			$test_now = ! empty( $input['test_provider'] );
			$result   = $test_now ? inframe_ai_save_and_test( $input ) : inframe_ai_save( $input );
			$message  = $test_now ? __( 'Connection saved. The provider answered correctly.', 'inframe' ) : __( 'Connection saved. You can now test it.', 'inframe' );
			$provider = inframe_ai_settings()['provider'];
			if ( defined( inframe_ai_key_constant( $provider ) ) ) {
				$message .= ' ' . inframe_ai_key_notice( $provider );
			}
			break;
		case 'limits':
			$result  = inframe_ai_save( array_intersect_key( $input, array_flip( array( 'daily_limit', 'monthly_cap', 'usd_eur', 'prices', '_prices_field' ) ) ) + array( 'daily_limit' => '' ) );
			$message = __( 'Limits saved.', 'inframe' );
			break;
		case 'initial_check':
			$check = inframe_initial_check_run();
			/* translators: %s: summary of the check results, e.g. "3 ok, 1 error". */
			$message = sprintf( __( 'Check completed: %s.', 'inframe' ), inframe_initial_check_summary( $check ) );
			$result  = inframe_initial_check_counts( $check )['error'] ? new WP_Error( 'initial_check', $message . ' ' . __( 'See below what to do.', 'inframe' ) ) : true;
			break;
		case 'test_provider':
			$result  = inframe_ai_connection_test();
			$message = __( 'The provider answered correctly.', 'inframe' );
			break;
		case 'discovery':
			$result  = inframe_save_discovery( $input );
			$message = __( 'Selection saved. Check the summary, then press “Scan the site”.', 'inframe' );
			break;
		case 'upload':
			$result  = inframe_import_file( $_FILES['document'] ?? array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated by inframe_import_file(): is_uploaded_file(), size, type; the text is sanitized.
			$message = __( 'Text imported. Check it in the sources before approving it.', 'inframe' );
			break;
		case 'manual':
			$title   = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result  = $title && $content && strlen( $content ) <= 60000 ? inframe_source_put( 'manual:' . hash( 'sha256', inframe_text_lower( $title ) ), 'manual', $title, '', $content ) : new WP_Error( 'manual_invalid', __( 'Enter a title and a text, up to 60 KB.', 'inframe' ) );
			break;
		case 'sources':
			$action = sanitize_key( $input['source_action'] ?? '' );
			$result = inframe_manage_sources( $action, $input['source_ids'] ?? array() );
			/* translators: %s: number of sources updated. */
			$message = is_wp_error( $result ) ? '' : sprintf( _n( '%s source updated. Rebuild and approve the documentation to publish the new selection.', '%s sources updated. Rebuild and approve the documentation to publish the new selection.', (int) $result, 'inframe' ), number_format_i18n( $result ) );
			if ( 'delete' === $action && ! is_wp_error( $result ) ) {
				$message .= ' ' . __( 'Removed from the plugin only. Pages come back with a new scan; documents can be uploaded again.', 'inframe' );
			}
			break;
		case 'source_edit':
			$id      = absint( $input['source_id'] ?? 0 );
			$row     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}inframe_sources WHERE id = %d AND post_id = 0", $id ), ARRAY_A );
			$title   = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result  = $row && $title && $content && strlen( $content ) <= 60000 ? inframe_source_put( $row['source_key'], $row['kind'], $title, '', $content ) : new WP_Error( 'source_edit_invalid', __( 'This source cannot be edited or the text is not valid. Enter a title and a content up to 60 KB. Pages are edited in the WordPress editor.', 'inframe' ) );
			$message = __( 'Text updated. Rebuild and approve the documentation.', 'inframe' );
			break;
		case 'prompt':
		case 'publish':
			$save_only = 'prompt' === $operation || ! empty( $input['save_prompt'] ) || ! empty( $input['reset_prompt'] );
			if ( ! $save_only && empty( $input['approved'] ) ) {
				$result = new WP_Error( 'approval_missing', __( 'Confirm that you checked the documentation and the prompt.', 'inframe' ) );
				break;
			}
			$result = isset( $input['document_version'] ) ? inframe_save_agent_prompt( $input ) : true;
			if ( ! is_wp_error( $result ) && ! $save_only ) {
				$result = inframe_publish_document();
			}
			$message = $save_only ? __( 'Prompt saved as a draft. Check and approve it to use it in the chat.', 'inframe' ) : __( 'Documentation approved. Prompt approved. You choose the chat visibility in Overview.', 'inframe' );
			break;
		case 'restore':
			$previous = get_option( 'inframe_kb_previous', array() );
			if ( empty( $previous['sources'] ) || count( inframe_current_sources( $previous ) ) !== count( $previous['sources'] ) ) {
				$result = new WP_Error( 'restore_stale', __( 'The sources of the previous version have changed. Rebuild the documentation.', 'inframe' ) );
			} else {
				update_option( 'inframe_kb_previous', get_option( 'inframe_kb_published' ), false );
				update_option( 'inframe_kb_published', $previous, false );
				update_option(
					'inframe_agent_preferences',
					array(
						'system_prompt' => inframe_agent_prompt( $previous ),
						'prompt_custom' => ! empty( $previous['prompt_custom'] ),
					),
					false
				);
				delete_option( 'inframe_kb_draft' );
			}
			break;
		case 'download':
			$doc = get_option( 'inframe_kb_published', array() );
			nocache_headers();
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="documentazione-assistente.md"' );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/markdown attachment, not HTML; the content is the approved documentation.
			echo ( $doc['markdown'] ?? '' ) . ( $doc ? "\n# " . __( 'Agent system prompt', 'inframe' ) . "\n\n" . inframe_agent_prompt( $doc ) . "\n" : '' );
			exit;
		case 'export_leads':
			$csv = inframe_leads_csv( 'undelivered' === sanitize_key( $input['status'] ?? '' ) ? 'undelivered' : '' );
			nocache_headers();
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="richieste-' . wp_date( 'Y-m-d' ) . '.csv"' );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/csv attachment, not HTML; cells are neutralised against formulas by inframe_csv_line().
			echo $csv;
			exit;
		case 'faq_draft':
			$question = is_string( $input['question'] ?? null ) ? sanitize_textarea_field( $input['question'] ) : '';
			$created  = ! inframe_faq_draft_existing( $question );
			$result   = inframe_faq_draft_create( $question );
			if ( ! is_wp_error( $result ) ) {
				$input['source_id'] = $result;
			}
			/* translators: %s: placeholder text in the FAQ draft that the owner replaces with the answer. */
			$next    = sprintf( __( 'Write the answer in place of %s, save, include the source, then rebuild and approve the documentation.', 'inframe' ), INFRAME_FAQ_PLACEHOLDER );
			$message = ( $created ? __( 'FAQ draft created and excluded.', 'inframe' ) : __( 'The FAQ draft for this question already exists.', 'inframe' ) ) . ' ' . $next;
			break;
		case 'mail_test':
			$sent   = inframe_send_mail( inframe_mail_recipient(), __( '[TEST] inFrame email check', 'inframe' ), __( 'This email checks that the plugin notifications are sent. It contains no customer data.', 'inframe' ) );
			$result = $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] );
			/* translators: %s: email address of the recipient. */
			$message = sprintf( __( 'Test email accepted by the email service for %s. Check the inbox and the spam folder: the plugin does not confirm delivery.', 'inframe' ), $sent['recipient'] );
			break;
		case 'resend_lead':
			$id = absint( $input['lead_id'] ?? 0 );
			$wpdb->update( $wpdb->prefix . 'inframe_leads', array( 'delivery' => 'pending' ), array( 'id' => $id ) );
			// The administrator explicitly requested another notification, even if previously accepted.
			$sent   = inframe_local_deliver( $id );
			$result = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			/* translators: %s: email address of the recipient. */
			$message = sprintf( __( 'New delivery accepted by the email service for %s. Check the recipient inbox.', 'inframe' ), is_wp_error( $sent ) ? '' : $sent['recipient'] );
			break;
		case 'delete_lead':
			$id     = absint( $input['lead_id'] ?? 0 );
			$result = inframe_local_delete_lead( $id ) ? true : new WP_Error( 'lead_missing', __( 'Request not found.', 'inframe' ) );
			/* translators: %s: ID of the deleted contact request. */
			$message = sprintf( __( 'Request #%s deleted.', 'inframe' ), $id );
			break;
		case 'retry_lead':
			$sent    = inframe_local_deliver( absint( $input['lead_id'] ?? 0 ) );
			$result  = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			$message = __( 'Attempt accepted by the email service. Check the status and the recipient inbox.', 'inframe' );
			break;
		default:
			$result = new WP_Error( 'operation_invalid', __( 'Invalid operation.', 'inframe' ) );
	}
	set_transient(
		'inframe_workspace_' . get_current_user_id(),
		array(
			'ok'      => ! is_wp_error( $result ),
			'message' => is_wp_error( $result ) ? $result->get_error_message() : $message,
		),
		MINUTE_IN_SECONDS
	);
	wp_safe_redirect( inframe_workspace_destination( $operation, $input ) );
	exit;
}

/** Home page of each operation (P6.16); the guided setup returns to its own step. */
function inframe_workspace_destination( $operation, $input ) {
	if ( 'faq_draft' === $operation ) {
		$id = absint( $input['source_id'] ?? 0 );
		return inframe_admin_url( 'inframe-sources', $id ? array( 'source' => $id ) : array() ) . '#inframe-source-manager';
	}
	$map    = array(
		'provider'      => array( 'inframe-settings', array( 'tab' => 'provider' ), '' ),
		'test_provider' => array( 'inframe-settings', array( 'tab' => 'provider' ), '' ),
		'limits'        => array( 'inframe-settings', array( 'tab' => 'limits' ), '' ),
		'discovery'     => array( 'inframe-sources', array( 'tab' => 'scan' ), '#inframe-discovery-form' ),
		'upload'        => array( 'inframe-sources', array(), '#inframe-source-manager' ),
		'manual'        => array( 'inframe-sources', array(), '#inframe-source-manager' ),
		'sources'       => array( 'inframe-sources', array(), '#inframe-source-manager' ),
		'source_edit'   => array( 'inframe-sources', array(), '#inframe-source-manager' ),
		'prompt'        => array( 'inframe-sources', array( 'tab' => 'docs' ), '#inframe-knowledge-review' ),
		'publish'       => array( 'inframe-sources', array( 'tab' => 'docs' ), '#inframe-knowledge-review' ),
		'restore'       => array( 'inframe-sources', array( 'tab' => 'docs' ), '' ),
		'mail_test'     => array( 'inframe-leads', array(), '#inframe-leads' ),
		'initial_check' => array( 'inframe', array(), '#inframe-initial-check' ),
		'resend_lead'   => array( 'inframe-leads', array(), '#inframe-leads' ),
		'retry_lead'    => array( 'inframe-leads', array(), '#inframe-leads' ),
		'delete_lead'   => array( 'inframe-leads', array(), '#inframe-leads' ),
	);
	$target = $map[ $operation ] ?? array( 'inframe', array(), '' );
	return inframe_admin_return_url( $input, $target[0], $target[1], $target[2] );
}

function inframe_knowledge_ajax() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'Access denied.', 'inframe' ) ), 403 );
	}
	check_ajax_referer( 'inframe_knowledge', 'nonce' );
	$operation = sanitize_key( $_POST['operation'] ?? '' );
	if ( 'scan' === $operation ) {
		$result = inframe_scan_batch( absint( $_POST['page'] ?? 1 ) );
	} elseif ( 'analyze' === $operation ) {
		$result = inframe_analyze_for_document( absint( $_POST['source_id'] ?? 0 ) );
	} elseif ( 'retrieval_test' === $operation ) {
		$query = sanitize_textarea_field( is_string( $_POST['query'] ?? null ) ? wp_unslash( $_POST['query'] ) : '' );
		if ( ! trim( $query ) || inframe_text_length( $query ) > 1000 ) {
			$result = new WP_Error( 'query_invalid', __( 'Write a question of up to 1000 characters.', 'inframe' ) );
		} else {
			$sources          = inframe_current_sources( get_option( 'inframe_kb_published', array() ), true );
			$chunks           = inframe_retrieve( $query, $sources );
			$retrieval_status = 'lexical';
			if ( ! empty( $_POST['assisted'] ) ) {
				$chunks = inframe_retrieve_assisted( $query, $sources, $chunks, $retrieval_status );
			}
			$result = array(
				'approved'         => count( $sources ),
				'retrieval_status' => $retrieval_status,
				'titles'           => array_values( array_unique( array_column( $chunks, 'title' ) ) ),
				'passages'         => array_map(
					static function ( $chunk ) {
						return array(
							'title' => $chunk['title'],
							'text'  => $chunk['text'],
						);
					},
					$chunks
				),
				'greeting'         => inframe_local_is_greeting( $query ),
				'overview'         => inframe_retrieval_is_overview( $query ),
			);
		}
	} elseif ( 'build' === $operation ) {
		$result = inframe_build_document();
		if ( ! is_wp_error( $result ) ) {
			$result = array( 'message' => __( 'Draft ready.', 'inframe' ) );
		}
	} else {
		$result = new WP_Error( 'operation_invalid', __( 'Invalid operation.', 'inframe' ) );
	}
	if ( is_wp_error( $result ) ) {
		wp_send_json_error(
			array(
				'message' => $result->get_error_message(),
				'code'    => $result->get_error_code(),
			),
			400
		);
	}
	wp_send_json_success( $result );
}

function inframe_undelivered_leads() {
	global $wpdb;
	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}inframe_leads WHERE delivery <> 'accepted'" );
}

/** P3.13 (D-030): WP-Cron runs only with site visits or a real cron; without it retention and retries stop silently. */
function inframe_cron_warning() {
	if ( ! inframe_cleanup_status()['late'] ) {
		return;
	}
	$days     = (int) inframe_get_settings()['lead_retention_days'];
	$disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? __( 'wp-config.php contains DISABLE_WP_CRON: WordPress does not start the cron by itself.', 'inframe' ) : __( 'WP-Cron starts only when someone visits the site.', 'inframe' );
	/* translators: %s: number of days delivered requests are kept. */
	$late = sprintf( __( '<strong>Automatic cleanup has not run for more than 48 hours</strong>: delivered requests are not deleted after %s days and new delivery attempts do not start.', 'inframe' ), number_format_i18n( $days ) );
	/* translators: %s: URL of wp-cron.php on this site. */
	$ask = sprintf( __( 'Ask your hosting provider for a real cron every 15 minutes on <code>%s</code>.', 'inframe' ), esc_html( site_url( 'wp-cron.php' ) ) );
	echo '<div id="inframe-cron-warning" class="notice notice-warning"><p>' . wp_kses( $late, inframe_notice_html() ) . ' ' . esc_html( $disabled ) . ' ' . wp_kses( $ask, inframe_notice_html() ) . '</p></div>';
}

function inframe_workspace_leads( $filter = '' ) {
	global $wpdb;
	// Undelivered leads first: they are kept until handled and must never fall outside the list.
	$where = 'undelivered' === $filter ? " WHERE delivery <> 'accepted'" : '';
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is a fixed string chosen above, no input.
	$rows        = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}inframe_leads$where ORDER BY delivery = 'accepted', id DESC LIMIT 50", ARRAY_A );
	$undelivered = inframe_undelivered_leads();
	$total       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}inframe_leads" );
	echo '<section id="inframe-leads">';
	if ( $undelivered ) {
		/* translators: %s: number of contact requests not delivered by email. */
		$warning = sprintf( _n( '<strong>%s request not delivered</strong>: the email was not accepted by the email service. Undelivered requests are kept until you resend or delete them.', '<strong>%s requests not delivered</strong>: the email was not accepted by the email service. Undelivered requests are kept until you resend or delete them.', $undelivered, 'inframe' ), number_format_i18n( $undelivered ) );
		echo '<div class="notice notice-warning inline"><p>' . wp_kses( $warning, inframe_notice_html() ) . '</p></div>';
	}
	echo '<ul class="subsubsub"><li><a href="' . esc_url( inframe_admin_url( 'inframe-leads' ) ) . '"' . ( $filter ? '' : ' class="current" aria-current="page"' ) . '>' . esc_html_x( 'All', 'contact requests', 'inframe' ) . ' <span class="count">(' . esc_html( number_format_i18n( $total ) ) . ')</span></a> |</li>';
	echo '<li><a href="' . esc_url( inframe_admin_url( 'inframe-leads', array( 'status' => 'undelivered' ) ) ) . '"' . ( $filter ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html_x( 'Not delivered', 'contact requests', 'inframe' ) . ' <span class="count">(' . esc_html( number_format_i18n( $undelivered ) ) . ')</span></a></li></ul>';
	echo '<form id="inframe-leads-export" class="inframe-clear" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	inframe_workspace_fields( 'export_leads' );
	if ( $filter ) {
		echo '<input type="hidden" name="status" value="undelivered" />';
	}
	submit_button( __( 'Export CSV', 'inframe' ), 'secondary', 'submit', false );
	echo ' <span class="description">' . esc_html( $filter ? __( 'Only the requests not delivered.', 'inframe' ) : __( 'All the requests.', 'inframe' ) ) . ' ' . esc_html__( 'The file contains personal data: keep it and delete it as stated in your privacy policy.', 'inframe' ) . '</span></form>';
	if ( ! $rows ) {
		echo '<p>' . esc_html__( 'No requests to show.', 'inframe' ) . '</p>';
	}
	foreach ( $rows as $row ) {
		$p = json_decode( $row['payload'], true );
		echo '<details class="inframe-lead"><summary>#' . esc_html( $row['id'] . ' — ' . $row['created_at'] . ' — ' . $p['name'] . ' — ' . ( 'accepted' === $row['delivery'] ? __( 'accepted by the email service', 'inframe' ) : __( 'email delivery to be retried', 'inframe' ) ) ) . '</summary>';
		echo '<p>' . esc_html( $p['email'] . ' ' . $p['phone'] ) . '</p>';
		if ( ! empty( $p['mail'] ) ) {
			/* translators: %s: email address of the last recipient. */
			echo '<p>' . esc_html( sprintf( __( 'Last recipient: %s', 'inframe' ), $p['mail']['recipient'] ) ) . '<br>';
			/* translators: %s: date and time of the last delivery attempt, in UTC. */
			echo esc_html( sprintf( __( 'Last attempt (UTC): %s', 'inframe' ), $p['mail']['attempted_at'] ) ) . '</p>';
			if ( ! empty( $p['mail']['error'] ) ) {
				echo '<p class="inframe-source-error">' . esc_html( $p['mail']['error'] ) . '</p>';
			}
		} else {
			echo '<p>' . esc_html__( 'Attempt details were not recorded by the previous version. The next delivery will update them.', 'inframe' ) . '</p>';
		}
		foreach ( $p['conversation'] as $m ) {
			echo '<p><strong>' . esc_html( $m['role'] ) . ':</strong> ' . esc_html( $m['text'] ) . '</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		inframe_workspace_fields( 'accepted' === $row['delivery'] ? 'resend_lead' : 'retry_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( 'accepted' === $row['delivery'] ? __( 'Resend the request email', 'inframe' ) : __( 'Retry the email delivery', 'inframe' ), 'secondary', 'submit', false );
		echo '<p class="description">' . esc_html__( 'Sends to the current recipient set in “Where requests go”. If the previous message had arrived, you will receive a copy.', 'inframe' ) . '</p></form>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'' . esc_js( __( 'Permanently delete this request?', 'inframe' ) ) . '\');">';
		inframe_workspace_fields( 'delete_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( __( 'Delete the request', 'inframe' ), 'delete', 'submit', false );
		echo '</form></details>';
	}
	echo '</section>';
}
