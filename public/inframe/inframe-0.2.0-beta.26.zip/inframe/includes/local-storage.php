<?php
/** Private knowledge, leads and counters. No uploaded document is exposed in the media library. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_local_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_sources (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		source_key varchar(191) NOT NULL,
		post_id bigint(20) unsigned NOT NULL DEFAULT 0,
		kind varchar(20) NOT NULL,
		title text NOT NULL,
		url text NOT NULL,
		content longtext NOT NULL,
		content_hash varchar(64) NOT NULL,
		analysis longtext NOT NULL,
		analysis_error text NOT NULL,
		enabled tinyint(1) NOT NULL DEFAULT 1,
		exclusion_reason varchar(20) NOT NULL DEFAULT '',
		updated_at datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY source_key (source_key),
		KEY post_id (post_id)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_leads (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		session_hash varchar(64) NOT NULL,
		payload longtext NOT NULL,
		delivery varchar(20) NOT NULL DEFAULT 'pending',
		created_at datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY session_hash (session_hash)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_counters (
		bucket varchar(64) NOT NULL,
		hits bigint(20) unsigned NOT NULL DEFAULT 0,
		expires bigint(20) unsigned NOT NULL,
		PRIMARY KEY  (bucket),
		KEY expires (expires)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_sessions (
		session_hash varchar(64) NOT NULL,
		payload longtext NOT NULL,
		expires bigint(20) unsigned NOT NULL,
		PRIMARY KEY  (session_hash),
		KEY expires (expires)
	) $charset;"
	);
	// P6.2: tokens per AI call, never their content. The conversation is a hash of the session key.
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_usage (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		created_at datetime NOT NULL,
		scope varchar(10) NOT NULL,
		conversation varchar(64) NOT NULL DEFAULT '',
		provider varchar(20) NOT NULL,
		model varchar(100) NOT NULL,
		input_tokens int(10) unsigned NOT NULL DEFAULT 0,
		output_tokens int(10) unsigned NOT NULL DEFAULT 0,
		PRIMARY KEY  (id),
		KEY created_at (created_at)
	) $charset;"
	);
	// P6.9: one vote per answer, with the cited sources; no question or answer text.
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}inframe_feedback (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		created_at datetime NOT NULL,
		conversation varchar(64) NOT NULL,
		answer_id varchar(16) NOT NULL,
		rating tinyint(4) NOT NULL,
		source_ids varchar(255) NOT NULL DEFAULT '',
		PRIMARY KEY  (id),
		UNIQUE KEY answer (conversation,answer_id),
		KEY created_at (created_at)
	) $charset;"
	);
	update_option( 'inframe_local_schema', '6', false );
	if ( ! wp_next_scheduled( 'inframe_local_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'inframe_local_cleanup' );
	}
}

function inframe_local_maybe_install() {
	if ( '6' !== get_option( 'inframe_local_schema' ) ) {
		inframe_local_install();
	}
	if ( ! wp_next_scheduled( 'inframe_local_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'inframe_local_cleanup' );
	}
}

function inframe_local_cleanup() {
	global $wpdb;
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}inframe_counters WHERE expires < %d", time() ) );
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}inframe_sessions WHERE expires < %d", time() ) ) && $ok;
	// Usage is kept 13 months, so the previous year's month can still be compared (P6.2).
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}inframe_usage WHERE created_at < %s", gmdate( 'Y-m-d H:i:s', time() - 396 * DAY_IN_SECONDS ) ) ) && $ok;
	// Votes are kept 13 months, like usage (P6.9).
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}inframe_feedback WHERE created_at < %s", gmdate( 'Y-m-d H:i:s', time() - 396 * DAY_IN_SECONDS ) ) ) && $ok;
	// Undelivered leads stay until the owner resends or deletes them: the owner may never have seen them.
	$days = (int) inframe_get_settings()['lead_retention_days'];
	$ok   = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}inframe_leads WHERE delivery = 'accepted' AND created_at < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) ) && $ok;
	if ( $ok ) {
		update_option( 'inframe_cleanup_last_run', time(), false );
	}
}

/** Late when the event is missing, or 48 hours have passed since the last successful run (or, before the first one, since it was due). */
function inframe_cleanup_status() {
	$next      = wp_next_scheduled( 'inframe_local_cleanup' );
	$last      = (int) get_option( 'inframe_cleanup_last_run', 0 );
	$reference = $last ?: (int) $next;
	return array(
		'last' => $last,
		'late' => ! $next || $reference < time() - 2 * DAY_IN_SECONDS,
	);
}

/** Delete one lead and the retries scheduled for it. Used by the panel and by the privacy eraser. */
function inframe_local_delete_lead( $id ) {
	global $wpdb;
	$deleted = (bool) $wpdb->delete( $wpdb->prefix . 'inframe_leads', array( 'id' => $id ) );
	wp_clear_scheduled_hook( 'inframe_local_retry', array( $id ) );
	return $deleted;
}

/** Keep visitor history out of object caches so retention and uninstall are deterministic. */
function inframe_local_history( $key ) {
	global $wpdb;
	$json = $wpdb->get_var( $wpdb->prepare( "SELECT payload FROM {$wpdb->prefix}inframe_sessions WHERE session_hash = %s AND expires > %d", $key, time() ) );
	return $json ? ( json_decode( $json, true ) ?: array() ) : array();
}

function inframe_local_save_history( $key, $history ) {
	global $wpdb;
	return $wpdb->replace(
		$wpdb->prefix . 'inframe_sessions',
		array(
			'session_hash' => $key,
			'payload'      => wp_json_encode( array_slice( $history, -12 ) ),
			'expires'      => time() + DAY_IN_SECONDS,
		)
	);
}

function inframe_local_delete_history( $key ) {
	global $wpdb;
	$wpdb->delete( $wpdb->prefix . 'inframe_sessions', array( 'session_hash' => $key ) );
}

/** Votes of the last days (P6.9): helpful, unhelpful, and how often each source was cited by an unhelpful answer. */
function inframe_feedback_summary( $days = 30 ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT rating, source_ids FROM %i WHERE created_at >= %s', $wpdb->prefix . 'inframe_feedback', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ), ARRAY_A );
	$out  = array(
		'total'        => 0,
		'up'           => 0,
		'down'         => 0,
		'down_sources' => array(),
	);
	foreach ( $rows ?: array() as $row ) {
		++$out['total'];
		if ( (int) $row['rating'] > 0 ) {
			++$out['up'];
			continue;
		}
		++$out['down'];
		foreach ( array_filter( array_map( 'intval', explode( ',', $row['source_ids'] ) ) ) as $id ) {
			$out['down_sources'][ $id ] = ( $out['down_sources'][ $id ] ?? 0 ) + 1;
		}
	}
	arsort( $out['down_sources'] );
	return $out;
}

/** Answers voted unhelpful in the one-day sessions (P6.9), with the question masked like the unanswered questions. */
function inframe_local_unhelpful_answers() {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT payload FROM {$wpdb->prefix}inframe_sessions WHERE expires > %d ORDER BY expires DESC LIMIT 500", time() ), ARRAY_A );
	$items = array();
	foreach ( $rows as $row ) {
		$question = '';
		foreach ( (array) json_decode( $row['payload'], true ) as $message ) {
			if ( ! is_array( $message ) ) {
				continue;
			}
			if ( 'user' === ( $message['role'] ?? '' ) && is_string( $message['text'] ?? null ) ) {
				$question = $message['text'];
			} elseif ( 'assistant' === ( $message['role'] ?? '' ) && -1 === ( $message['rating'] ?? 0 ) && count( $items ) < 50 ) {
				$items[] = array(
					'question'   => inframe_local_redact_question( $question ),
					'answer'     => inframe_local_redact_question( (string) ( $message['text'] ?? '' ) ),
					'source_ids' => array_map( 'intval', (array) ( $message['source_ids'] ?? array() ) ),
				);
			}
		}
	}
	return $items;
}

/** Use the existing one-day sessions to surface real unanswered questions to admins. */
function inframe_local_redact_question( $question ) {
	$question = preg_replace( '~https?://\S+~iu', '[link]', $question );
	$question = preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu', '[email]', $question );
	$question = preg_replace( '/(?<![\p{L}\p{N}])\+?\d(?:[\d\s().-]{5,}\d)(?![\p{L}\p{N}])/u', '[numero]', $question );
	return sanitize_text_field( $question );
}

function inframe_local_unanswered_questions() {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT payload FROM {$wpdb->prefix}inframe_sessions WHERE expires > %d ORDER BY expires DESC LIMIT 500", time() ), ARRAY_A );
	$items = array();
	foreach ( $rows as $row ) {
		$history  = json_decode( $row['payload'], true );
		$question = '';
		foreach ( is_array( $history ) ? $history : array() as $message ) {
			if ( ! is_array( $message ) ) {
				continue;
			}
			if ( 'user' === ( $message['role'] ?? '' ) && is_string( $message['text'] ?? null ) ) {
				$question = $message['text'];
			} elseif ( 'assistant' === ( $message['role'] ?? '' ) ) {
				if ( $question && in_array( $message['diagnostic'] ?? '', array( 'retrieval_empty', 'retrieval_unavailable', 'citation_invalid', 'number_unverified', 'provider_format', 'unsupported_action' ), true ) ) {
					$visible          = inframe_local_redact_question( $question );
					$retrieval_status = in_array( $message['retrieval_status'] ?? '', array( 'selection_index_limit', 'selection_index_empty', 'selection_failed', 'selection_budget', 'selection_empty', 'query_empty' ), true ) ? $message['retrieval_status'] : '';
					$key              = hash( 'sha256', $visible . "\n" . $message['diagnostic'] . "\n" . $retrieval_status );
					if ( ! isset( $items[ $key ] ) ) {
						$items[ $key ] = array(
							'question'         => $visible,
							'diagnostic'       => $message['diagnostic'],
							'retrieval_status' => $retrieval_status,
							'count'            => 0,
						);
					}
					++$items[ $key ]['count'];
				}
				$question = '';
			}
		}
	}
	return array_slice( array_values( $items ), 0, 50 );
}

function inframe_sources( $enabled_only = false, $metadata_only = false ) {
	global $wpdb;
	$where   = $enabled_only ? ' WHERE enabled = 1' : '';
	$columns = $metadata_only ? 'id, post_id, kind, title, url, content_hash, analysis, enabled, updated_at' : '*';
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $columns and $where are fixed strings chosen above, no input.
	return $wpdb->get_results( "SELECT $columns FROM {$wpdb->prefix}inframe_sources$where ORDER BY id ASC", ARRAY_A );
}

/** Fingerprint of a source: the scan and the change hooks must compute it the same way. */
function inframe_source_hash( $title, $url, $content ) {
	return hash( 'sha256', $title . "\n" . $url . "\n" . $content );
}

function inframe_source_put( $key, $kind, $title, $url, $content, $post_id = 0 ) {
	global $wpdb;
	$table = $wpdb->prefix . 'inframe_sources';
	$old   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE source_key = %s', $table, $key ), ARRAY_A );
	$hash  = inframe_source_hash( $title, $url, $content );
	if ( $old && hash_equals( $old['content_hash'], $hash ) ) {
		return (int) $old['id'];
	}
	$row = array(
		'source_key'     => $key,
		'kind'           => $kind,
		'title'          => $title,
		'url'            => $url,
		'content'        => $content,
		'content_hash'   => $hash,
		'post_id'        => $post_id,
		'analysis'       => '',
		'analysis_error' => '',
		'updated_at'     => current_time( 'mysql', true ),
	);
	$ok  = $old ? $wpdb->update( $table, $row, array( 'id' => $old['id'] ) ) : $wpdb->insert( $table, $row );
	if ( false === $ok ) {
		return new WP_Error( 'source_write', __( 'The source could not be saved.', 'inframe' ) );
	}
	delete_option( 'inframe_kb_draft' );
	return $old ? (int) $old['id'] : (int) $wpdb->insert_id;
}

function inframe_source_is_public( $row ) {
	if ( ! $row['post_id'] ) {
		return true;
	}
	$post = get_post( $row['post_id'] );
	if ( ! $post || ! is_post_publicly_viewable( $post ) || $post->post_password ) {
		return false;
	}
	if ( 'product' === $post->post_type && function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( $post->ID );
		return 'ecommerce' === inframe_get_settings()['workflow_mode'] && $product && $product->is_visible();
	}
	return true;
}

function inframe_current_sources( $document, $with_content = false ) {
	$valid = array();
	if ( ! is_array( $document ) || ( $document['mode'] ?? '' ) !== inframe_get_settings()['workflow_mode'] ) {
		return $valid;
	}
	foreach ( inframe_sources( true, ! $with_content ) as $row ) {
		if ( isset( $document['sources'][ $row['id'] ] ) && hash_equals( $document['sources'][ $row['id'] ], $row['content_hash'] ) && inframe_source_is_public( $row ) ) {
			$valid[ $row['id'] ] = $row;
		}
	}
	return $valid;
}
