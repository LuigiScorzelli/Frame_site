<?php
/** GDPR tools for the site owner: export and erasure by visitor email, suggested privacy policy text. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const INFRAME_PRIVACY_PAGE = 50;

function inframe_privacy_register_exporter( $exporters ) {
	$exporters['inframe'] = array(
		'exporter_friendly_name' => 'inFrame',
		'callback'               => 'inframe_privacy_export',
	);
	return $exporters;
}

function inframe_privacy_register_eraser( $erasers ) {
	$erasers['inframe'] = array(
		'eraser_friendly_name' => 'inFrame',
		'callback'             => 'inframe_privacy_erase',
	);
	return $erasers;
}

/**
 * Leads whose contact email is $email, oldest first. Only the email field counts: an address quoted
 * in someone else's conversation must not expose or delete that lead (D-029). The LIKE on the JSON
 * payload narrows the rows; the exact match is checked after decoding.
 */
function inframe_privacy_leads( $email, $offset ) {
	global $wpdb;
	$email = strtolower( trim( (string) $email ) );
	if ( ! is_email( $email ) ) {
		return array();
	}
	$needle = '%' . $wpdb->esc_like( substr( wp_json_encode( array( 'email' => $email ) ), 1, -1 ) ) . '%';
	$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}inframe_leads WHERE payload LIKE %s ORDER BY id ASC", $needle ), ARRAY_A );
	$leads  = array();
	foreach ( $rows as $row ) {
		$payload = json_decode( $row['payload'], true );
		if ( is_array( $payload ) && is_string( $payload['email'] ?? null ) && strtolower( $payload['email'] ) === $email ) {
			$row['payload'] = $payload;
			$leads[]        = $row;
		}
	}
	return array_slice( $leads, $offset, INFRAME_PRIVACY_PAGE );
}

function inframe_privacy_export( $email, $page = 1 ) {
	$leads = inframe_privacy_leads( $email, ( max( 1, (int) $page ) - 1 ) * INFRAME_PRIVACY_PAGE );
	$data  = array();
	foreach ( $leads as $row ) {
		$p            = $row['payload'];
		$conversation = '';
		foreach ( (array) ( $p['conversation'] ?? array() ) as $m ) {
			if ( is_array( $m ) && is_string( $m['text'] ?? null ) ) {
				$conversation .= ( 'user' === ( $m['role'] ?? '' ) ? _x( 'Visitor', 'privacy export, conversation role', 'inframe' ) : _x( 'Assistant', 'privacy export, conversation role', 'inframe' ) ) . ': ' . $m['text'] . "\n";
			}
		}
		$values = array(
			_x( 'Request', 'privacy export field', 'inframe' )                => '#' . $row['id'],
			_x( 'Received on (UTC)', 'privacy export field', 'inframe' )      => $row['created_at'],
			_x( 'Name', 'privacy export field', 'inframe' )                   => $p['name'] ?? '',
			_x( 'Email', 'privacy export field', 'inframe' )                  => $p['email'] ?? '',
			_x( 'Phone', 'privacy export field', 'inframe' )                  => $p['phone'] ?? '',
			_x( 'Delivery to the owner', 'privacy export field', 'inframe' )  => 'accepted' === $row['delivery'] ? __( 'Email accepted by the email service', 'inframe' ) : __( 'Email not delivered yet', 'inframe' ),
			_x( 'Consent', 'privacy export field', 'inframe' )                => $p['consent_text'] ?? '',
			_x( 'Privacy policy version', 'privacy export field', 'inframe' ) => $p['consent_version'] ?? '',
			_x( 'Consent given on', 'privacy export field', 'inframe' )       => $p['consented_at'] ?? '',
			_x( 'Privacy policy', 'privacy export field', 'inframe' )         => $p['privacy_url'] ?? '',
			_x( 'Conversation', 'privacy export field', 'inframe' )           => trim( $conversation ),
		);
		$item   = array();
		foreach ( $values as $name => $value ) {
			if ( '' !== (string) $value ) {
				$item[] = array(
					'name'  => $name,
					'value' => (string) $value,
				);
			}
		}
		$data[] = array(
			'group_id'    => 'inframe-leads',
			'group_label' => __( 'Contact requests (inFrame)', 'inframe' ),
			'item_id'     => 'inframe-lead-' . $row['id'],
			'data'        => $item,
		);
	}
	return array(
		'data' => $data,
		'done' => count( $leads ) < INFRAME_PRIVACY_PAGE,
	);
}

/** Deleted rows are gone, so every page reads from the start. Undelivered leads are erased too (D-029). */
function inframe_privacy_erase( $email, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- signature required by the WordPress personal data eraser.
	$leads   = inframe_privacy_leads( $email, 0 );
	$removed = false;
	foreach ( $leads as $row ) {
		$removed = inframe_local_delete_lead( (int) $row['id'] ) || $removed;
	}
	return array(
		'items_removed'  => $removed,
		'items_retained' => false,
		'messages'       => array(),
		'done'           => count( $leads ) < INFRAME_PRIVACY_PAGE,
	);
}

/** Text proposed in Settings › Privacy; it follows the current retention and provider. */
function inframe_privacy_policy_text() {
	$days       = inframe_get_settings()['lead_retention_days'];
	$provider   = 'anthropic' === inframe_ai_settings()['provider'] ? 'Anthropic' : 'OpenAI';
	$paragraphs = array(
		/* translators: %s: name of the AI provider, e.g. Anthropic or OpenAI. */
		sprintf( __( 'This site uses inFrame, a chat assistant. The messages written in the chat are sent to the site server, which forwards them, together with the passages of the site pages used to answer, to the artificial intelligence provider chosen by the site owner (currently %s) to generate the answer. Contact details are not sent to the provider.', 'inframe' ), $provider ),
		__( 'The conversation stays on the site server for at most 24 hours, to keep the answers consistent, and in the visitor’s browser (sessionStorage) while the tab stays open. To limit abuse the site saves an encrypted fingerprint of the IP address, never the plain address, for at most one day.', 'inframe' ),
		__( 'If the visitor fills in the contact form and confirms consent, the site saves name, email and/or phone, the summary of the conversation, the text and date of the consent, and sends the request by email to the recipient set by the site owner.', 'inframe' ),
		/* translators: %s: number of days delivered contact requests are kept. */
		sprintf( __( 'Requests delivered by email are kept for %s days and then deleted automatically. Requests not delivered (for example if the site email does not work) are kept until the site owner resends or deletes them, so that a request the owner never received is not lost.', 'inframe' ), number_format_i18n( $days ) ),
		__( 'The data subject can ask for a copy or the deletion of their requests by giving the email used in the form: the site owner handles them from Tools › Export Personal Data and Tools › Erase Personal Data. Requests left with a phone number only are deleted from the plugin panel.', 'inframe' ),
	);
	return '<p>' . implode( '</p><p>', array_map( 'esc_html', $paragraphs ) ) . '</p>';
}

function inframe_register_privacy_text() {
	if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
		wp_add_privacy_policy_content( 'inFrame', inframe_privacy_policy_text() );
	}
}
