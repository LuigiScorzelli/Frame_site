<?php
/** Panel structure (P6.16, D-036): top-level menu, seven pages, tabs, shared header and redirects. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Slug => title, render callback and tabs. The first tab is the default one. */
function inframe_admin_pages() {
	return array(
		'inframe'            => array( __( 'Overview', 'inframe' ), 'inframe_page_overview', array() ),
		'inframe-setup'      => array( __( 'Guided setup', 'inframe' ), 'inframe_page_setup', array() ),
		'inframe-sources'    => array(
			__( 'Sources and documentation', 'inframe' ),
			'inframe_page_sources',
			array(
				'sources' => __( 'Sources', 'inframe' ),
				'scan'    => __( 'Selection and scan', 'inframe' ),
				'files'   => __( 'Documents and information', 'inframe' ),
				'docs'    => __( 'Documentation', 'inframe' ),
				'test'    => __( 'Source test', 'inframe' ),
			),
		),
		'inframe-leads'      => array( __( 'Requests', 'inframe' ), 'inframe_page_leads', array() ),
		'inframe-questions'  => array( __( 'Unanswered questions', 'inframe' ), 'inframe_page_questions', array() ),
		'inframe-appearance' => array(
			__( 'Appearance', 'inframe' ),
			'inframe_page_appearance',
			array(
				'widget'   => __( 'Widget', 'inframe' ),
				'welcome'  => __( 'Welcome and hours', 'inframe' ),
				'contacts' => __( 'Alternative contacts', 'inframe' ),
				'where'    => __( 'Where it appears', 'inframe' ),
			),
		),
		'inframe-settings'   => array(
			__( 'Settings', 'inframe' ),
			'inframe_page_settings',
			array(
				'business' => __( 'Business', 'inframe' ),
				'provider' => __( 'AI provider', 'inframe' ),
				'privacy'  => __( 'Privacy and retention', 'inframe' ),
				'limits'   => __( 'Limits', 'inframe' ),
				'network'  => __( 'Network', 'inframe' ),
			),
		),
	);
}

function inframe_admin_menu() {
	add_menu_page( 'inFrame', 'inFrame', 'manage_options', 'inframe', 'inframe_page_overview', 'dashicons-format-chat', 58 );
	// Only a cheap COUNT here: the unanswered questions would read the sessions on every admin page.
	$undelivered = inframe_undelivered_leads();
	foreach ( inframe_admin_pages() as $slug => $page ) {
		$label = $page[0];
		if ( 'inframe-leads' === $slug && $undelivered ) {
			$label .= ' <span class="awaiting-mod count-' . $undelivered . '"><span class="pending-count">' . $undelivered . '</span></span>';
		}
		add_submenu_page( 'inframe', $page[0] . ' ‹ inFrame', $label, 'manage_options', $slug, $page[1] );
	}
}

function inframe_admin_url( $slug, $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => $slug ), $args ), admin_url( 'admin.php' ) );
}

function inframe_admin_current_page() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
	return isset( inframe_admin_pages()[ $page ] ) ? $page : '';
}

function inframe_admin_current_tab( $slug ) {
	$tabs = inframe_admin_pages()[ $slug ][2];
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$tab = sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) );
	return isset( $tabs[ $tab ] ) ? $tab : (string) array_key_first( $tabs );
}

/** Bookmarks and tester guides use the old Settings address (up to beta.21). */
function inframe_legacy_redirect() {
	global $pagenow;
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only redirect, no state change.
	$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
	$tab  = sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) );
	// phpcs:enable
	if ( 'options-general.php' !== $pagenow || 'inframe' !== $page ) {
		return;
	}
	wp_safe_redirect( 'technical' === $tab ? inframe_admin_url( 'inframe-appearance' ) : inframe_admin_url( 'inframe' ) );
	exit;
}

function inframe_admin_assets() {
	if ( ! inframe_admin_current_page() ) {
		return;
	}
	wp_enqueue_style( 'inframe-workspace', plugins_url( 'assets/inframe-workspace.css', INFRAME_PLUGIN_FILE ), array(), INFRAME_VERSION );
	wp_enqueue_script( 'inframe-workspace', plugins_url( 'assets/inframe-workspace.js', INFRAME_PLUGIN_FILE ), array(), INFRAME_VERSION, true );
	/* translators: %s: number of sources imported so far. */
	$scan_progress = array( _n( 'Reading the site… %s source imported.', 'Reading the site… %s sources imported.', 1, 'inframe' ), _n( 'Reading the site… %s source imported.', 'Reading the site… %s sources imported.', 2, 'inframe' ) );
	/* translators: %s: number of sources imported or updated. */
	$scan_done = array( _n( 'Scan finished: %s source imported or updated.', 'Scan finished: %s sources imported or updated.', 1, 'inframe' ), _n( 'Scan finished: %s source imported or updated.', 'Scan finished: %s sources imported or updated.', 2, 'inframe' ) );
	/* translators: 1: current page number, 2: number of pages, 3: number of matching sources, 4: total number of sources. */
	$page = array( _n( 'Page %1$s of %2$s · %3$s result out of %4$s', 'Page %1$s of %2$s · %3$s results out of %4$s', 1, 'inframe' ), _n( 'Page %1$s of %2$s · %3$s result out of %4$s', 'Page %1$s of %2$s · %3$s results out of %4$s', 2, 'inframe' ) );
	/* translators: %s: number of selected sources. */
	$delete_selected = array( _n( 'Remove the %s selected source from the plugin, including any outside the visible page? The original site stays intact. Approved documentation that contains it will be withdrawn.', 'Remove the %s selected sources from the plugin, including those outside the visible page? The original site stays intact. Approved documentation that contains them will be withdrawn.', 1, 'inframe' ), _n( 'Remove the %s selected source from the plugin, including any outside the visible page? The original site stays intact. Approved documentation that contains it will be withdrawn.', 'Remove the %s selected sources from the plugin, including those outside the visible page? The original site stays intact. Approved documentation that contains them will be withdrawn.', 2, 'inframe' ) );
	wp_localize_script(
		'inframe-workspace',
		'INFRAME_WORKSPACE',
		array(
			'url'        => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'inframe_knowledge' ),
			'sourcesUrl' => inframe_admin_url( 'inframe-sources' ),
			// Texts of the script: placeholders (%s, %1$s) are replaced there; counted texts are [one, other] pairs picked by count === 1.
			// Number format of the panel language (P6.8), e.g. it-IT or en-US.
			'locale'     => str_replace( '_', '-', determine_locale() ),
			'i18n'       => array(
				/* translators: 1: model name, 2: euro per million input tokens, 3: euro per million output tokens, 4: euro per 100 questions, 5: input tokens of a typical question, 6: output tokens of a typical question. */
				'estimate'              => __( 'Estimated cost with %1$s: %2$s per million input tokens and %3$s output, about %4$s per 100 questions (typical question: %5$s input tokens and %6$s output; the exact bill is the provider’s).', 'inframe' ),
				'consentRequired'       => __( 'To test the connection, tick the box “I authorize sending to the selected provider…”.', 'inframe' ),
				'requestFailed'         => __( 'Operation failed. Reload the page and try again.', 'inframe' ),
				/* translators: %s: error message. */
				'runFailed'             => __( '%s Completed steps are kept. You can resume after fixing the problem.', 'inframe' ),
				/* translators: %s: error message. */
				'runFailedDraft'        => __( '%s The new draft was not completed. Completed steps are kept. You can resume after fixing the problem.', 'inframe' ),
				'stateError'            => __( 'To fix', 'inframe' ),
				'stateReady'            => __( 'Analyzed', 'inframe' ),
				/* translators: %s: number of selected sources. */
				'selection'             => __( '%s selected', 'inframe' ),
				/* translators: 1: number of selected sources, 2: how many of them are outside the visible page. */
				'selectionHidden'       => __( '%1$s selected (%2$s outside the visible page)', 'inframe' ),
				'page'                  => $page,
				/* translators: %s: number of sources matching the filters. */
				'selectMatching'        => __( 'Select all results (%s)', 'inframe' ),
				'selectionRange'        => __( 'Select from 1 to 1000 sources before applying an action.', 'inframe' ),
				'deleteSelectedConfirm' => $delete_selected,
				'deleteOneConfirm'      => __( 'Remove this source from the plugin? The original site stays intact. Approved documentation that contains it will be withdrawn.', 'inframe' ),
				'retrievalChecking'     => __( 'Checking the approved sources…', 'inframe' ),
				'retrievalIndexLimit'   => __( 'The index of approved facts exceeds the limit and the fallback search in the original passages found no answer. The chat uses the local result, if available.', 'inframe' ),
				'retrievalIndexEmpty'   => __( 'No valid quote is available in the index of approved facts; the fallback search found no answer either. Check the analysis and the text read.', 'inframe' ),
				'retrievalFailed'       => __( 'The AI selection failed or returned no valid references. Check the connection and the provider quota, then try again.', 'inframe' ),
				'retrievalBudget'       => __( 'The time allowed for the assisted search ran out. Try again or check the provider’s response.', 'inframe' ),
				/* translators: %s: titles of the sources found, separated by " · ". */
				'foundSources'          => __( 'Sources found: %s', 'inframe' ),
				/* translators: %s: titles of the sources found, separated by " · ". */
				'foundOverview'         => __( 'Catalog overview. Sources found: %s', 'inframe' ),
				/* translators: 1: number of usable approved sources, 2: result of the check. */
				'retrievalResult'       => __( 'Usable approved sources: %1$s. %2$s', 'inframe' ),
				'retrievalGreeting'     => __( 'Greeting recognized: the chat answers without searching for business facts.', 'inframe' ),
				'retrievalNone'         => __( 'No relevant source found. Check the text read and approve the information needed.', 'inframe' ),
				'colorOnDark'           => __( 'On this color the chat text is dark.', 'inframe' ),
				'colorSurface'          => __( 'Behind white text the chat uses a darker shade of this color.', 'inframe' ),
				'colorText'             => __( 'Links and buttons use a darker shade of this color.', 'inframe' ),
				'colorWhy'              => __( 'This keeps the chat readable for everyone.', 'inframe' ),
				'selectionChanged'      => __( 'The selection has changed: press “Save the selection and show the summary” before scanning.', 'inframe' ),
				'scanProgress'          => $scan_progress,
				'scanDone'              => $scan_done,
				/* translators: %s: list of sources not imported, each with its reason, separated by " | ". */
				'scanSkipped'           => __( 'Sources not imported: %s', 'inframe' ),
				'noSources'             => __( 'Scan the site or include at least one source.', 'inframe' ),
				/* translators: 1: number of the source being analyzed, 2: number of sources, 3: source title, 4: number of sources excluded automatically. */
				'analysisProgress'      => __( 'Analyzing sources: %1$s of %2$s — %3$s. %4$s excluded automatically. Keep this page open.', 'inframe' ),
				/* translators: 1: source title, 2: error message. */
				'analysisStopped'       => __( 'Analysis stopped on the source “%1$s”: %2$s Sources not analyzed stay included; the other analyses are kept.', 'inframe' ),
				'analysisDone'          => __( 'Analysis finished. Preparing the draft to approve…', 'inframe' ),
			),
		)
	);
}

function inframe_admin_footer( $text ) {
	/* translators: %s: plugin version, e.g. 0.2.0-beta.25. */
	return inframe_admin_current_page() ? esc_html( sprintf( __( 'inFrame · Free beta %s', 'inframe' ), INFRAME_VERSION ) ) : $text;
}

/** Page context: action forms post it back so the guided setup returns to its own step. */
function inframe_admin_context( $context = null ) {
	static $current = '';
	if ( null !== $context ) {
		$current = $context;
	}
	return $current;
}

/** Destination after an admin-post action: the guided setup step it came from, otherwise the home page of the function. */
function inframe_admin_return_url( $input, $slug, $args = array(), $anchor = '' ) {
	$parts = explode( '|', sanitize_text_field( is_string( $input['inframe_return'] ?? null ) ? $input['inframe_return'] : '' ) );
	if ( 'inframe-setup' === $parts[0] ) {
		$step = max( 1, min( 5, (int) ( $parts[2] ?? 1 ) ) );
		return inframe_admin_url( 'inframe-setup', array( 'step' => $step ) ) . $anchor;
	}
	return inframe_admin_url( $slug, $args ) . $anchor;
}

/** Shared header of every panel page: title, saved-settings and operation notices, warnings, tabs. */
function inframe_admin_open( $slug, $intro = '', $context = array() ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Access denied.', 'inframe' ) );
	}
	$page = inframe_admin_pages()[ $slug ];
	$tab  = $page[2] ? inframe_admin_current_tab( $slug ) : '';
	inframe_admin_context( implode( '|', array_merge( array( $slug, $tab ), $context ) ) );
	$notice = get_transient( 'inframe_workspace_' . get_current_user_id() );
	delete_transient( 'inframe_workspace_' . get_current_user_id() );
	echo '<div class="wrap inframe-admin">';
	echo '<h1>' . esc_html( $page[0] ) . '</h1>';
	if ( $intro ) {
		echo '<p class="inframe-intro">' . esc_html( $intro ) . '</p>';
	}
	// Pages outside Settings do not print the options.php notices by themselves.
	settings_errors();
	if ( $notice ) {
		// Announced to screen readers: the page reloads after every action.
		echo '<div class="notice ' . ( $notice['ok'] ? 'notice-success" role="status' : 'notice-error" role="alert' ) . '"><p>' . esc_html( $notice['message'] ) . '</p></div>';
	}
	if ( 'inframe-leads' !== $slug && inframe_undelivered_leads() ) {
		echo '<div class="notice notice-warning" id="inframe-undelivered-notice"><p>' . esc_html__( 'Some contact requests were not delivered by email.', 'inframe' ) . ' <a href="' . esc_url( inframe_admin_url( 'inframe-leads', array( 'status' => 'undelivered' ) ) ) . '">' . esc_html__( 'See the requests', 'inframe' ) . '</a>.</p></div>';
	}
	inframe_cost_warning();
	if ( $page[2] ) {
		/* translators: %s: name of the panel page, e.g. Settings. */
		echo '<nav class="nav-tab-wrapper wp-clearfix" aria-label="' . esc_attr( sprintf( __( 'Sections of %s', 'inframe' ), $page[0] ) ) . '">';
		foreach ( $page[2] as $key => $label ) {
			$active = $key === $tab;
			echo '<a href="' . esc_url( inframe_admin_url( $slug, array( 'tab' => $key ) ) ) . '" class="nav-tab' . ( $active ? ' nav-tab-active' : '' ) . '"' . ( $active ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}
	return $tab;
}

function inframe_admin_close() {
	echo '</div>';
}

/** Marks the space reserved for a later Phase 6 task: no sample data. */
function inframe_admin_soon( $task ) {
	/* translators: %s: task ID in the project plan, e.g. P6.4. */
	return '<span class="inframe-soon">' . esc_html( sprintf( __( 'Coming soon · %s', 'inframe' ), $task ) ) . '</span>';
}

/** Hidden marker of the page that rendered an admin-post form. */
function inframe_admin_return_field() {
	if ( inframe_admin_context() ) {
		echo '<input type="hidden" name="inframe_return" value="' . esc_attr( inframe_admin_context() ) . '" />';
	}
}

/** Monthly cap reached or close (P6.2): shown on every plugin page, since the panel keeps calling the AI. */
function inframe_cost_warning() {
	$u = inframe_usage_summary();
	if ( $u['cap'] <= 0 || $u['total'] < 0.8 * $u['cap'] ) {
		return;
	}
	$link = '<a href="' . esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'limits' ) ) ) . '">' . esc_html__( 'Settings › Limits', 'inframe' ) . '</a>';
	/* translators: 1: amount spent this month, 2: monthly cap, both formatted in euro. */
	$amount = esc_html( sprintf( __( '%1$s of %2$s', 'inframe' ), inframe_format_eur( $u['total'] ), inframe_format_eur( $u['cap'] ) ) );
	if ( inframe_cost_cap_reached( $u ) ) {
		/* translators: 1: "<amount> of <cap>", 2: link to Settings › Limits. */
		$text = __( '<strong>Spending cap reached</strong> (%1$s estimated this month): the chat no longer calls the AI and offers the contact form until next month. Panel actions keep working and add to the spending. You can raise the cap in %2$s.', 'inframe' );
		echo '<div class="notice notice-error" id="inframe-cost-warning"><p>' . wp_kses( sprintf( $text, $amount, $link ), inframe_notice_html() ) . '</p></div>';
		return;
	}
	/* translators: 1: "<amount> of <cap>", 2: link to Settings › Limits. */
	$text = __( '<strong>Spending cap almost reached</strong> (%1$s estimated this month). At the cap the chat switches to the contact form. %2$s.', 'inframe' );
	echo '<div class="notice notice-warning" id="inframe-cost-warning"><p>' . wp_kses( sprintf( $text, $amount, $link ), inframe_notice_html() ) . '</p></div>';
}

/** Markup allowed in translated panel messages: translations may move a link or a bold part, nothing else. */
function inframe_notice_html() {
	return array(
		'a'      => array( 'href' => true ),
		'strong' => array(),
		'em'     => array(),
		'code'   => array(),
	);
}
