<?php
/** Settings option, validation and the form field helpers used by the panel pages. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_defaults() {
	return array(
		'lead_email'          => '',
		'display_mode'        => 'off',
		'workflow_mode'       => 'servizi',
		'visibility'          => 'all',
		'page_ids'            => array(),
		'title'               => '',
		'company'             => '',
		'color'               => '#1f5fbf',
		'position'            => 'right',
		'welcome'             => '',
		'privacy_url'         => '',
		'fallback_phone'      => '',
		'fallback_email'      => '',
		'whatsapp'            => '',
		'suggestions'         => '',
		'launcher_label'      => '',
		'trusted_proxies'     => '',
		'lead_retention_days' => 30,
		// P6.17: welcome by page or category, guided paths, opening hours.
		'page_rules'          => array(),
		'paths'               => '',
		'show_paths'          => true,
		'hours'               => array_fill_keys( inframe_weekdays(), '' ),
		'closed_message'      => '',
	);
}

/** Days a lead accepted by the email service is kept (P3.11). Undelivered leads are not affected (D-020). */
function inframe_retention_choices() {
	return array( 7, 30, 90, 180, 365 );
}

function inframe_get_settings() {
	$saved    = get_option( 'inframe_settings', array() );
	$defaults = inframe_defaults();
	return wp_parse_args( is_array( $saved ) ? array_intersect_key( $saved, $defaults ) : array(), $defaults );
}

/** Remove the retired external-service configuration after an upgrade. */
function inframe_remove_legacy_settings() {
	$saved = get_option( 'inframe_settings', array() );
	if ( ! is_array( $saved ) || ! array_intersect( array( 'engine', 'endpoint', 'site_key' ), array_keys( $saved ) ) ) {
		return;
	}
	unset( $saved['engine'], $saved['endpoint'], $saved['site_key'] );
	update_option( 'inframe_settings', $saved, false );
}

function inframe_sanitize_settings( $input ) {
	// options.php has already unslashed the value (audit beta.25, I3): a second wp_unslash() would drop real backslashes.
	$input = is_array( $input ) ? $input : array();
	$old   = inframe_get_settings();
	// Customer and technical forms edit subsets of the same options.
	if ( ! empty( $input['_visibility_form'] ) && ! isset( $input['page_ids'] ) ) {
		$input['page_ids'] = array();
	}
	if ( ! empty( $input['_welcome_form'] ) && ! isset( $input['show_paths'] ) ) {
		$input['show_paths'] = false;
	}
	$input               = wp_parse_args( $input, $old );
	$clean               = inframe_defaults();
	$clean['lead_email'] = sanitize_email( $input['lead_email'] );

	$clean['display_mode']  = in_array( $input['display_mode'] ?? '', array( 'off', 'test', 'live' ), true ) ? $input['display_mode'] : 'off';
	$clean['workflow_mode'] = in_array( $input['workflow_mode'] ?? '', array( 'servizi', 'ecommerce' ), true ) ? $input['workflow_mode'] : 'servizi';
	$clean['visibility']    = in_array( $input['visibility'] ?? '', array( 'all', 'include', 'exclude' ), true ) ? $input['visibility'] : 'all';
	$clean['position']      = in_array( $input['position'] ?? '', array( 'left', 'right' ), true ) ? $input['position'] : 'right';
	$page_ids               = array_map( 'intval', (array) ( $input['page_ids'] ?? array() ) );
	$clean['page_ids']      = array_values(
		array_unique(
			array_filter(
				$page_ids,
				static function ( $id ) {
					return $id > 0;
				}
			)
		)
	);
	$clean['color']         = sanitize_hex_color( $input['color'] ?? '' ) ?: '#1f5fbf';

	foreach ( array( 'title', 'company', 'fallback_phone', 'launcher_label' ) as $key ) {
		$clean[ $key ] = sanitize_text_field( $input[ $key ] ?? '' );
	}
	$clean['fallback_email'] = sanitize_email( $input['fallback_email'] ?? '' );
	// P6.6: digits only, with the country code; a number of the wrong length keeps the saved one.
	$whatsapp = preg_replace( '/\D/', '', (string) ( $input['whatsapp'] ?? '' ) );
	if ( '' !== $whatsapp && ( strlen( $whatsapp ) < 8 || strlen( $whatsapp ) > 15 ) ) {
		add_settings_error( 'inframe_settings', 'inframe_whatsapp', __( 'Invalid WhatsApp number: write it with the international code, for example +39 333 1234567. The number saved before is kept.', 'inframe' ) );
		$whatsapp = $old['whatsapp'];
	}
	$clean['whatsapp']            = $whatsapp;
	$clean['privacy_url']         = esc_url_raw( $input['privacy_url'] ?? '', array( 'http', 'https' ) );
	$clean['welcome']             = sanitize_textarea_field( $input['welcome'] ?? '' );
	$lines                        = preg_split( '/[\r\n|]+/', (string) ( $input['suggestions'] ?? '' ) );
	$clean['suggestions']         = implode( '|', array_slice( array_filter( array_map( 'sanitize_text_field', $lines ) ), 0, 8 ) );
	$proxies                      = preg_split( '/[\s,]+/', (string) ( $input['trusted_proxies'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY );
	$clean['trusted_proxies']     = implode( "\n", array_slice( array_values( array_unique( array_filter( $proxies, 'inframe_is_ip_range' ) ) ), 0, 20 ) );
	$days                         = (int) ( $input['lead_retention_days'] ?? 30 );
	$clean['lead_retention_days'] = in_array( $days, inframe_retention_choices(), true ) ? $days : 30;
	$clean['page_rules']          = inframe_sanitize_page_rules( $input['page_rules'] );
	$paths                        = preg_split( '/[\r\n|]+/', (string) ( is_string( $input['paths'] ) ? $input['paths'] : '' ) );
	$clean['paths']               = implode( '|', array_slice( array_filter( array_map( 'inframe_short_text', $paths ) ), 0, 3 ) );
	$clean['show_paths']          = ! empty( $input['show_paths'] );
	$clean['closed_message']      = mb_substr( sanitize_text_field( is_string( $input['closed_message'] ) ? $input['closed_message'] : '' ), 0, 300 );
	$clean['hours']               = $old['hours'];
	$hours                        = is_array( $input['hours'] ) ? $input['hours'] : array();
	$invalid                      = false;
	foreach ( inframe_weekdays() as $day ) {
		$value = inframe_sanitize_hours( $hours[ $day ] ?? $old['hours'][ $day ] );
		if ( null === $value ) {
			$invalid = true;
			continue;
		}
		$clean['hours'][ $day ] = $value;
	}
	if ( $invalid ) {
		add_settings_error( 'inframe_settings', 'inframe_hours', __( 'Invalid opening hours: write them as 09:00-13:00, 15:00-19:00. The hours saved before are kept for those days.', 'inframe' ) );
	}

	return $clean;
}

/** A single IPv4/IPv6 address or a network in CIDR notation. */
function inframe_is_ip_range( $range ) {
	$parts = explode( '/', (string) $range, 2 );
	$ip    = filter_var( $parts[0], FILTER_VALIDATE_IP );
	if ( ! $ip ) {
		return false;
	}
	$max = false !== strpos( $ip, ':' ) ? 128 : 32;
	return ! isset( $parts[1] ) || ( ctype_digit( $parts[1] ) && (int) $parts[1] <= $max );
}

function inframe_register_settings() {
	register_setting(
		'inframe_settings',
		'inframe_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'inframe_sanitize_settings',
			'default'           => inframe_defaults(),
		)
	);
}

/**
 * Readable colours from the owner's colour (P6.7), the same calculation as the widget (`palette` in inframe-widget.js):
 * text on the colour is white or dark, whichever reads better; if neither reaches 4.5:1 the surface is darkened;
 * the colour used as text on light backgrounds gets a darker shade when needed.
 *
 * @param string $hex Colour saved in the settings.
 * @return array{c:string,surface:string,on:string,text:string}
 */
function inframe_widget_palette( $hex ) {
	$h = preg_match( '/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i', trim( (string) $hex ), $m ) ? $m[1] : '1f5fbf';
	if ( 3 === strlen( $h ) ) {
		$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
	}
	$rgb     = array_map( 'hexdec', str_split( $h, 2 ) );
	$lum     = static function ( $c ) {
		$v = array_map(
			static function ( $x ) {
				$x /= 255;
				return $x <= 0.03928 ? $x / 12.92 : pow( ( $x + 0.055 ) / 1.055, 2.4 );
			},
			$c
		);
		return 0.2126 * $v[0] + 0.7152 * $v[1] + 0.0722 * $v[2];
	};
	$ratio   = static function ( $a, $b ) use ( $lum ) {
		$x = $lum( $a );
		$y = $lum( $b );
		return ( max( $x, $y ) + 0.05 ) / ( min( $x, $y ) + 0.05 );
	};
	$darker  = static function ( $c, $against, $min ) use ( $rgb, $ratio ) {
		$t = 0;
		while ( $t < 1 && $ratio( $c, $against ) < $min ) {
			// Same steps as the JavaScript `for` loop: the first pass uses t = 0.
			$c  = array_map(
				static function ( $x ) use ( $t ) {
					return (int) round( $x * ( 1 - $t ) );
				},
				$rgb
			);
			$t += 0.04;
		}
		return $c;
	};
	$css     = static function ( $c ) {
		return vsprintf( '#%02x%02x%02x', $c );
	};
	$white   = array( 255, 255, 255 );
	$ink     = array( 29, 35, 48 );
	$surface = $rgb;
	$on      = $ratio( $rgb, $white ) >= $ratio( $rgb, $ink ) ? $white : $ink;
	if ( $ratio( $surface, $on ) < 4.6 ) {
		$surface = $darker( $rgb, $white, 4.6 );
		$on      = $white;
	}
	return array(
		'c'       => $css( $rgb ),
		'surface' => $css( $surface ),
		'on'      => $css( $on ),
		'text'    => $css( $darker( $rgb, array( 244, 246, 249 ), 4.6 ) ),
	);
}

/**
 * What the chat changes to keep the owner's colour readable (P6.7), shown below the Color field.
 *
 * @param array $p Result of inframe_widget_palette().
 * @return string Empty when nothing changes.
 */
function inframe_color_note( $p ) {
	$notes = array();
	if ( '#1d2330' === $p['on'] ) {
		$notes[] = __( 'On this color the chat text is dark.', 'inframe' );
	}
	if ( $p['surface'] !== $p['c'] ) {
		$notes[] = __( 'Behind white text the chat uses a darker shade of this color.', 'inframe' );
	}
	if ( $p['text'] !== $p['c'] ) {
		$notes[] = __( 'Links and buttons use a darker shade of this color.', 'inframe' );
	}
	return $notes ? implode( ' ', $notes ) . ' ' . __( 'This keeps the chat readable for everyone.', 'inframe' ) : '';
}

/**
 * One row of a settings table.
 *
 * @param array  $settings    Saved settings.
 * @param string $key         Setting key.
 * @param string $label       Visible label.
 * @param string $type        Input type, or textarea.
 * @param string $description Help text below the field.
 * @param string $note        P6.7: live note below the help (only the Color field uses it; an empty string still prints the element the panel updates).
 */
function inframe_field( $settings, $key, $label, $type = 'text', $description = '', $note = null ) {
	$value = $settings[ $key ];
	echo '<tr><th scope="row"><label for="inframe-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
	if ( 'textarea' === $type ) {
		$shown = 'suggestions' === $key ? str_replace( '|', "\n", $value ) : $value;
		echo '<textarea class="large-text" rows="3" id="inframe-' . esc_attr( $key ) . '" name="inframe_settings[' . esc_attr( $key ) . ']">' . esc_textarea( $shown ) . '</textarea>';
	} else {
		echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="inframe-' . esc_attr( $key ) . '" name="inframe_settings[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '" />';
	}
	if ( $description ) {
		echo '<p class="description">' . esc_html( $description ) . '</p>';
	}
	if ( null !== $note ) {
		echo '<p id="inframe-' . esc_attr( $key ) . '-note" class="description inframe-color-note" aria-live="polite">' . esc_html( $note ) . '</p>';
	}
	echo '</td></tr>';
}

function inframe_select_field( $settings, $key, $label, $choices ) {
	echo '<tr><th scope="row"><label for="inframe-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="inframe-' . esc_attr( $key ) . '" name="inframe_settings[' . esc_attr( $key ) . ']">';
	foreach ( $choices as $value => $text ) {
		echo '<option value="' . esc_attr( $value ) . '" ' . selected( $settings[ $key ], $value, false ) . '>' . esc_html( $text ) . '</option>';
	}
	echo '</select></td></tr>';
}

function inframe_regenerate_preview() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Access denied.', 'inframe' ) );
	}
	check_admin_referer( 'inframe_regenerate_preview' );
	update_option( 'inframe_preview_token', wp_generate_password( 40, false, false ), false );
	wp_safe_redirect( inframe_admin_url( 'inframe-appearance', array( 'tab' => 'where' ) ) );
	exit;
}

/** P6.17: weekday keys of the opening hours, Monday first. */
function inframe_weekdays() {
	return array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );
}

/** A short label (guided path, suggested question): one line, at most 80 characters. */
function inframe_short_text( $text ) {
	return mb_substr( sanitize_text_field( (string) $text ), 0, 80 );
}

/**
 * Opening hours of one day as "HH:MM-HH:MM, HH:MM-HH:MM": empty means closed, null means invalid.
 * Accepts 9:00, 9.00 and dashes with spaces; each range must end after it starts.
 */
function inframe_sanitize_hours( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	$ranges = array();
	foreach ( preg_split( '/\s*[,;]\s*/', $value, -1, PREG_SPLIT_NO_EMPTY ) as $range ) {
		if ( ! preg_match( '/^(\d{1,2})[:.](\d{2})\s*[-–]\s*(\d{1,2})[:.](\d{2})$/u', $range, $m ) ) {
			return null;
		}
		$from = (int) $m[1] * 60 + (int) $m[2];
		$to   = (int) $m[3] * 60 + (int) $m[4];
		if ( (int) $m[1] > 23 || (int) $m[3] > 24 || (int) $m[2] > 59 || (int) $m[4] > 59 || $to <= $from || $to > 1440 ) {
			return null;
		}
		$ranges[] = sprintf( '%02d:%02d-%02d:%02d', $m[1], $m[2], $m[3], $m[4] );
	}
	return implode( ', ', array_slice( $ranges, 0, 4 ) );
}

/** P6.17: at most 10 rules on an existing page or category (post or WooCommerce product), each with 3 questions. */
function inframe_sanitize_page_rules( $rules ) {
	$clean = array();
	foreach ( is_array( $rules ) ? $rules : array() as $rule ) {
		if ( ! is_array( $rule ) || count( $clean ) >= 10 ) {
			continue;
		}
		$target = is_string( $rule['target'] ?? null ) ? $rule['target'] : '';
		if ( ! inframe_page_rule_target_exists( $target ) ) {
			continue;
		}
		$questions = preg_split( '/[\r\n|]+/', is_string( $rule['suggestions'] ?? null ) ? $rule['suggestions'] : '' );
		$clean[]   = array(
			'target'      => $target,
			'welcome'     => mb_substr( sanitize_textarea_field( is_string( $rule['welcome'] ?? null ) ? $rule['welcome'] : '' ), 0, 500 ),
			'suggestions' => implode( '|', array_slice( array_filter( array_map( 'inframe_short_text', $questions ) ), 0, 3 ) ),
		);
	}
	return $clean;
}

/** "page:<id>" for any published page or post, "term:<taxonomy>:<id>" for a post or product category. */
function inframe_page_rule_target_exists( $target ) {
	if ( preg_match( '/^page:(\d+)$/', $target, $m ) ) {
		return 'publish' === get_post_status( (int) $m[1] );
	}
	if ( preg_match( '/^term:(category|product_cat):(\d+)$/', $target, $m ) ) {
		return taxonomy_exists( $m[1] ) && term_exists( (int) $m[2], $m[1] );
	}
	return false;
}
