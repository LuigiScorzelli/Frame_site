<?php
/** Searchable source collection; bulk changes never edit the original WordPress pages. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_source_action_fields( $id, $action ) {
	inframe_workspace_fields( 'sources' );
	echo '<input type="hidden" name="source_ids[]" value="' . esc_attr( $id ) . '" /><input type="hidden" name="source_action" value="' . esc_attr( $action ) . '" />';
}

function inframe_render_analysis_exclusions( $sources ) {
	$excluded = array_filter(
		$sources,
		static function ( $row ) {
			return ! $row['enabled'] && ! empty( $row['analysis_error'] );
		}
	);
	if ( ! $excluded ) {
		return;
	}
	/* translators: %s: number of sources excluded because the analysis reported a problem. */
	echo '<details id="inframe-analysis-exclusions" open><summary><strong>' . esc_html( sprintf( _n( '%s source excluded with warnings', '%s sources excluded with warnings', count( $excluded ), 'inframe' ), number_format_i18n( count( $excluded ) ) ) ) . '</strong></summary><p>' . esc_html__( 'They are not in the new documentation. The text stays in the source manager: fix it, include the source and build again to retry. The documentation and the prompt always need approval.', 'inframe' ) . '</p><ul>';
	foreach ( $excluded as $row ) {
		echo '<li><strong>' . esc_html( $row['title'] ) . ':</strong> ' . esc_html( $row['analysis_error'] ) . '</li>';
	}
	echo '</ul></details>';
}

function inframe_render_source_manager( $sources, $published ) {
	$types    = array(
		'page'     => __( 'Page / post', 'inframe' ),
		'product'  => __( 'Product', 'inframe' ),
		'document' => __( 'Document', 'inframe' ),
		'manual'   => __( 'Manual information', 'inframe' ),
	);
	$current  = inframe_current_sources( $published );
	$included = count(
		array_filter(
			$sources,
			static function ( $row ) {
				return (bool) $row['enabled'];
			}
		)
	);
	?>
	<section id="inframe-source-manager" tabindex="-1" aria-label="<?php esc_attr_e( 'Source management', 'inframe' ); ?>">
		<p><strong>
		<?php
		/* translators: 1: number of sources, 2: sources included in the next draft, 3: sources excluded. */
		echo esc_html( sprintf( __( '%1$s sources · %2$s included in the next draft · %3$s excluded', 'inframe' ), number_format_i18n( count( $sources ) ), number_format_i18n( $included ), number_format_i18n( count( $sources ) - $included ) ) );
		?>
		</strong></p>
		<p><?php esc_html_e( '“Exclude” keeps the source and removes it from the answers right away. “Include” puts it back in the selection. “Remove from the plugin” deletes the imported text; it does not delete pages or products from the site. A new scan brings back the removed pages and keeps the exclusions. If you remove an approved source, the documentation that contains it is withdrawn: rebuild it and approve it.', 'inframe' ); ?></p>
		<div class="inframe-source-filters" hidden>
			<label><?php esc_html_e( 'Search title or URL', 'inframe' ); ?> <input type="search" id="inframe-source-search" /></label>
			<label><?php esc_html_e( 'Type', 'inframe' ); ?> <select id="inframe-source-kind"><option value=""><?php esc_html_e( 'All types', 'inframe' ); ?></option>
			<?php
			foreach ( $types as $value => $label ) :
				?>
				<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
			<label><?php esc_html_e( 'Selection', 'inframe' ); ?> <select id="inframe-source-inclusion"><option value=""><?php esc_html_e( 'Included and excluded', 'inframe' ); ?></option><option value="1"><?php echo esc_html_x( 'Included', 'source filter', 'inframe' ); ?></option><option value="0"><?php echo esc_html_x( 'Excluded', 'source filter', 'inframe' ); ?></option></select></label>
			<label><?php esc_html_e( 'Analysis', 'inframe' ); ?> <select id="inframe-source-state"><option value=""><?php esc_html_e( 'All states', 'inframe' ); ?></option><option value="pending"><?php esc_html_e( 'To analyze', 'inframe' ); ?></option><option value="ready"><?php echo esc_html( _x( 'Analyzed', 'source filter, plural', 'inframe' ) ); ?></option><option value="error"><?php esc_html_e( 'To fix', 'inframe' ); ?></option><option value="stale"><?php esc_html_e( 'To scan again', 'inframe' ); ?></option></select></label>
		</div>
		<form id="inframe-sources-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php inframe_workspace_fields( 'sources' ); ?>
			<div class="inframe-source-toolbar">
				<label><?php esc_html_e( 'Action on the selected sources', 'inframe' ); ?> <select name="source_action" required><option value=""><?php esc_html_e( 'Choose an action', 'inframe' ); ?></option><option value="exclude"><?php esc_html_e( 'Exclude from the documentation', 'inframe' ); ?></option><option value="include"><?php esc_html_e( 'Include in the documentation', 'inframe' ); ?></option><option value="reanalyze"><?php esc_html_e( 'Analyze again', 'inframe' ); ?></option><option value="delete"><?php esc_html_e( 'Remove from the plugin', 'inframe' ); ?></option></select></label>
				<button class="button" type="submit"><?php esc_html_e( 'Apply to the selected', 'inframe' ); ?></button>
				<span id="inframe-source-selection" role="status" aria-live="polite"><?php esc_html_e( '0 selected', 'inframe' ); ?></span>
				<button type="button" class="button-link" id="inframe-source-select-matching" hidden><?php esc_html_e( 'Select all results', 'inframe' ); ?></button>
				<button type="button" class="button-link" id="inframe-source-clear" hidden><?php esc_html_e( 'Clear selection', 'inframe' ); ?></button>
			</div>
			<p id="inframe-source-feedback" role="alert" hidden></p>
		</form>
		<div class="inframe-source-table-wrap">
		<table class="widefat striped inframe-source-table">
			<caption class="screen-reader-text"><?php esc_html_e( 'Imported sources and their use in the documentation', 'inframe' ); ?></caption>
			<thead><tr><td class="check-column"><input type="checkbox" id="inframe-source-select-page" aria-label="<?php esc_attr_e( 'Select the sources on this page', 'inframe' ); ?>" /></td><th scope="col"><?php esc_html_e( 'Source and text read', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Type', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Selection and analysis', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Actions', 'inframe' ); ?></th></tr></thead>
			<tbody>
			<?php
			foreach ( $sources as $row ) :
				$analysis = json_decode( $row['analysis'], true );
				$state    = inframe_source_state( $row );
				$length   = inframe_text_length( $row['content'] );
				/* translators: %s: source title. */
				$select_label = sprintf( __( 'Select %s', 'inframe' ), $row['title'] );
				/* translators: %s: number of characters of the text read from the source. */
				$text_read = sprintf( _n( 'Text read · %s character', 'Text read · %s characters', $length, 'inframe' ), number_format_i18n( $length ) );
				?>
				<tr class="inframe-source" data-source="<?php echo esc_attr( $row['id'] ); ?>" data-title="<?php echo esc_attr( $row['title'] ); ?>" data-enabled="<?php echo esc_attr( $row['enabled'] ); ?>" data-kind="<?php echo esc_attr( $row['kind'] ); ?>" data-state="<?php echo esc_attr( $state[0] ); ?>" data-search="<?php echo esc_attr( $row['title'] . ' ' . $row['url'] ); ?>">
					<th scope="row" class="check-column"><input type="checkbox" class="inframe-source-check" name="source_ids[]" form="inframe-sources-form" value="<?php echo esc_attr( $row['id'] ); ?>" aria-label="<?php echo esc_attr( $select_label ); ?>" /></th>
					<td><strong><?php echo esc_html( $row['title'] ); ?></strong>
						<?php
						if ( $row['url'] ) :
							?>
							<p><a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $row['url'] ); ?>"><?php echo esc_html( $row['url'] ); ?></a></p><?php endif; ?>
						<details><summary><?php echo esc_html( $text_read ); ?></summary>
							<pre class="inframe-source-text"><?php echo esc_html( $row['content'] ); ?></pre>
							<?php
							if ( ! empty( $analysis['facts'] ) ) :
								?>
								<ul>
								<?php
								foreach ( $analysis['facts'] as $fact ) :
									?>
								<li><strong><?php echo esc_html( $fact['label'] ); ?>:</strong> <?php echo esc_html( $fact['quote'] ); ?></li><?php endforeach; ?></ul><?php endif; ?>
						</details>
						<?php if ( ! $row['post_id'] ) : ?>
						<details><summary><?php esc_html_e( 'Edit the source text', 'inframe' ); ?></summary>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php inframe_workspace_fields( 'source_edit' ); ?>
								<input type="hidden" name="source_id" value="<?php echo esc_attr( $row['id'] ); ?>" />
								<p><label><?php esc_html_e( 'Title', 'inframe' ); ?> <input name="title" value="<?php echo esc_attr( $row['title'] ); ?>" required maxlength="200" /></label></p>
								<p><label><?php esc_html_e( 'Extracted text or manual information', 'inframe' ); ?><textarea class="large-text" name="content" rows="6" required><?php echo esc_textarea( $row['content'] ); ?></textarea></label></p>
								<button type="submit" class="button"><?php esc_html_e( 'Save the text', 'inframe' ); ?></button>
							</form>
						</details>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $types[ $row['kind'] ] ?? $row['kind'] ); ?></td>
					<td><strong><?php echo esc_html( $row['enabled'] ? _x( 'Included', 'source status', 'inframe' ) : _x( 'Excluded', 'source status', 'inframe' ) ); ?></strong><p class="inframe-source-status"><?php echo esc_html( $state[1] ); ?></p>
						<?php
						if ( ! $row['enabled'] && ! empty( $row['exclusion_reason'] ) ) :
							?>
							<p>
							<?php
							echo esc_html(
								array(
									'scope'     => __( 'Outside the scan selection', 'inframe' ),
									'analysis'  => __( 'Excluded automatically: not usable', 'inframe' ),
									'manual'    => __( 'Excluded by the owner', 'inframe' ),
									'faq_draft' => __( 'FAQ draft to complete', 'inframe' ),
								)[ $row['exclusion_reason'] ] ?? ''
							);
							?>
							</p><?php endif; ?>
						<p class="inframe-source-error"><?php echo esc_html( $row['analysis_error'] ?? '' ); ?></p>
						<p><?php echo esc_html( isset( $current[ $row['id'] ] ) ? __( 'In use in the chat', 'inframe' ) : __( 'Not in use in the chat', 'inframe' ) ); ?></p>
					</td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php inframe_source_action_fields( $row['id'], $row['enabled'] ? 'exclude' : 'include' ); ?><button type="submit" class="button"><?php echo esc_html( $row['enabled'] ? __( 'Exclude', 'inframe' ) : __( 'Include', 'inframe' ) ); ?></button></form>
						<form class="inframe-source-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php inframe_source_action_fields( $row['id'], 'delete' ); ?><button type="submit" class="button-link-delete"><?php esc_html_e( 'Remove from the plugin', 'inframe' ); ?></button></form>
						<?php
						if ( $row['post_id'] ) :
							?>
							<p><a href="<?php echo esc_url( get_edit_post_link( $row['post_id'], 'raw' ) ); ?>"><?php esc_html_e( 'Edit in WordPress', 'inframe' ); ?></a></p><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<p id="inframe-source-empty" <?php echo $sources ? 'hidden' : ''; ?>><?php esc_html_e( 'No source matches the filters. Change the search or scan the site to add sources.', 'inframe' ); ?></p>
		<div class="inframe-source-pagination" hidden>
			<button type="button" class="button" id="inframe-source-prev"><?php esc_html_e( 'Previous', 'inframe' ); ?></button><span id="inframe-source-page" role="status" aria-live="polite"></span><button type="button" class="button" id="inframe-source-next"><?php esc_html_e( 'Next', 'inframe' ); ?></button>
			<label><?php esc_html_e( 'Sources per page', 'inframe' ); ?> <select id="inframe-source-size"><option>20</option><option>50</option><option>100</option></select></label>
		</div>
	</section>
	<?php
}
