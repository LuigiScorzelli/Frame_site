<?php
/**
 * One-click initial check (P6.1): AI key and model, test email, WP-Cron, HTTPS, privacy page and proxy settings.
 * Each check says what to do and links to the page where it is fixed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * True when wp-config.php disables WP-Cron. The override exists for the tests: the CI stack defines the constant.
 *
 * @param bool|null $override Value to use instead of the constant; null restores the constant.
 */
function inframe_cron_disabled( $override = null ) {
	static $forced = null;
	if ( func_num_args() ) {
		$forced = $override;
	}
	return null !== $forced ? (bool) $forced : ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );
}

/** Run every check, store the result (not autoloaded) and return it. */
function inframe_initial_check_run() {
	$loopback = inframe_cron_disabled() ? null : inframe_initial_check_loopback();
	$result   = array(
		'at'    => time(),
		'items' => array(
			inframe_initial_check_ai(),
			inframe_initial_check_mail(),
			inframe_initial_check_cron( $loopback ),
			inframe_initial_check_https( $loopback ),
			inframe_initial_check_privacy(),
			inframe_initial_check_network(),
		),
	);
	update_option( 'inframe_initial_check', $result, false );
	return $result;
}

/** One result row: ok, warning or error, what it means and where to fix it. */
function inframe_initial_check_item( $id, $label, $status, $message, $fix_url = '', $fix_label = '' ) {
	return array(
		'id'        => $id,
		'label'     => $label,
		'status'    => $status,
		'message'   => $message,
		'fix_url'   => $fix_url,
		'fix_label' => $fix_label,
	);
}

function inframe_initial_check_ai() {
	$label = __( 'API key and model', 'inframe' );
	$fix   = inframe_admin_url( 'inframe-settings', array( 'tab' => 'provider' ) );
	// At the cap the chat already uses the contact form: a test call would only add to the bill (P6.2).
	if ( inframe_cost_cap_reached() ) {
		return inframe_initial_check_item( 'ai', $label, 'warning', __( 'Test skipped: the monthly spending cap is reached and the chat switches to the contact form. Raise the cap or wait for next month, then run the check again.', 'inframe' ), inframe_admin_url( 'inframe-settings', array( 'tab' => 'limits' ) ), __( 'Limits', 'inframe' ) );
	}
	$s      = inframe_ai_settings();
	$result = inframe_ai_connection_test();
	if ( is_wp_error( $result ) ) {
		return inframe_initial_check_item( 'ai', $label, 'error', $result->get_error_message(), $fix, __( 'AI provider', 'inframe' ) );
	}
	$name  = 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic';
	$model = 'openai' === $s['provider'] ? $s['openai_model'] : $s['anthropic_model'];
	/* translators: 1: AI provider name (OpenAI or Anthropic), 2: model name. */
	$message = sprintf( __( '%1$s answered with the model %2$s. The test costs a few tokens, counted in this month’s costs.', 'inframe' ), $name, $model );
	return inframe_initial_check_item( 'ai', $label, 'ok', $message );
}

function inframe_initial_check_mail() {
	$sent  = inframe_send_mail( inframe_mail_recipient(), __( '[TEST] inFrame initial check', 'inframe' ), __( 'This email checks that the plugin can send notifications. It contains no customer data.', 'inframe' ) );
	$label = __( 'Request email', 'inframe' );
	if ( ! $sent['accepted'] ) {
		return inframe_initial_check_item( 'mail', $label, 'error', $sent['error'], inframe_admin_url( 'inframe-settings' ), __( 'Where to receive requests', 'inframe' ) );
	}
	/* translators: %s: email address the test email was sent to. */
	$message = sprintf( __( 'Test email accepted by the email service for %s. Check the inbox and the spam folder: the plugin cannot confirm delivery.', 'inframe' ), $sent['recipient'] );
	return inframe_initial_check_item( 'mail', $label, 'ok', $message );
}

/** The site calls its own wp-cron.php, as WordPress does after a visit, checking the certificate too. */
function inframe_initial_check_loopback() {
	return wp_remote_get(
		site_url( 'wp-cron.php' ),
		array(
			'timeout'   => 5,
			'sslverify' => true,
		)
	);
}

function inframe_initial_check_is_ssl_error( $response ) {
	return is_wp_error( $response ) && (bool) preg_match( '/SSL|certificate|cURL error (?:35|51|58|60)\b/i', $response->get_error_message() );
}

function inframe_initial_check_cron( $loopback ) {
	$label = __( 'Automatic cleanup (WP-Cron)', 'inframe' );
	$url   = site_url( 'wp-cron.php' );
	if ( ! wp_next_scheduled( 'inframe_local_cleanup' ) ) {
		return inframe_initial_check_item( 'cron', $label, 'error', __( 'The automatic cleanup is not scheduled: delivered requests are not deleted and new delivery attempts do not start. Deactivate and reactivate the plugin to schedule it again.', 'inframe' ), admin_url( 'plugins.php' ), __( 'Plugins', 'inframe' ) );
	}
	if ( inframe_cleanup_status()['late'] ) {
		/* translators: %s: URL of wp-cron.php. */
		return inframe_initial_check_item( 'cron', $label, 'error', sprintf( __( 'The automatic cleanup has not run for more than 48 hours. Ask your hosting for a real cron every 15 minutes on %s.', 'inframe' ), $url ) );
	}
	if ( inframe_cron_disabled() ) {
		/* translators: %s: URL of wp-cron.php. */
		return inframe_initial_check_item( 'cron', $label, 'warning', sprintf( __( 'wp-config.php contains DISABLE_WP_CRON: WordPress does not start the cron by itself. A real cron from your hosting is needed every 15 minutes on %s.', 'inframe' ), $url ) );
	}
	// WordPress itself calls wp-cron.php without checking the certificate: a certificate problem belongs to the HTTPS check.
	if ( ( is_wp_error( $loopback ) && ! inframe_initial_check_is_ssl_error( $loopback ) ) || ( ! is_wp_error( $loopback ) && wp_remote_retrieve_response_code( $loopback ) >= 400 ) ) {
		/* translators: %s: URL of wp-cron.php. */
		return inframe_initial_check_item( 'cron', $label, 'warning', sprintf( __( 'The site cannot call itself: WP-Cron might not start after visits. Ask your hosting for a real cron every 15 minutes on %s.', 'inframe' ), $url ) );
	}
	return inframe_initial_check_item( 'cron', $label, 'ok', __( 'The cleanup is scheduled and the site can start WP-Cron.', 'inframe' ) );
}

function inframe_initial_check_https( $loopback ) {
	$label = 'HTTPS';
	if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) || 'https' !== wp_parse_url( site_url(), PHP_URL_SCHEME ) ) {
		return inframe_initial_check_item( 'https', $label, 'error', __( 'The site address does not use https: the data left in the contact form travel unencrypted. Turn on the certificate with your hosting, then set the addresses with https in Settings › General.', 'inframe' ), admin_url( 'options-general.php' ), __( 'General settings', 'inframe' ) );
	}
	if ( inframe_initial_check_is_ssl_error( $loopback ) ) {
		return inframe_initial_check_item( 'https', $label, 'warning', __( 'The site does not accept its own certificate: it might be expired or not valid for this address. Check it with your hosting.', 'inframe' ) );
	}
	return inframe_initial_check_item( 'https', $label, 'ok', __( 'The site uses https.', 'inframe' ) );
}

function inframe_initial_check_privacy() {
	$url   = inframe_get_settings()['privacy_url'] ?: get_privacy_policy_url();
	$label = __( 'Privacy policy', 'inframe' );
	if ( ! $url ) {
		return inframe_initial_check_item( 'privacy', $label, 'error', __( 'The privacy policy is missing: the public chat stays hidden until you set the link or publish the WordPress privacy page.', 'inframe' ), inframe_admin_url( 'inframe-settings', array( 'tab' => 'privacy' ) ), __( 'Privacy and retention', 'inframe' ) );
	}
	/* translators: %s: URL of the privacy policy. */
	return inframe_initial_check_item( 'privacy', $label, 'ok', sprintf( __( 'The chat shows the link to %s.', 'inframe' ), $url ) );
}

/** True when the request in progress carries a header that a CDN or a reverse proxy adds. */
function inframe_proxy_headers_present() {
	foreach ( array( 'HTTP_X_FORWARDED_FOR', 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_FORWARDED' ) as $header ) {
		if ( ! empty( $_SERVER[ $header ] ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Behind a proxy that is not declared the plugin sees every visitor with the proxy address: the limits meant
 * for one visitor then apply to the whole site. Empty when the proxy is declared or none is detected.
 */
function inframe_proxy_warning() {
	if ( '' !== trim( inframe_get_settings()['trusted_proxies'] ) || ! inframe_proxy_headers_present() ) {
		return '';
	}
	return __( 'The site seems to be behind a CDN or a reverse proxy, but no trusted proxy is set: the plugin sees all visitors with the same address. The limits meant for one visitor then apply to all of them together, and real contact requests can be refused. Enter the addresses of your proxy in Settings › Network.', 'inframe' );
}

/** Proxy settings (audit beta.25, M3). The result is stored: it never contains an address. */
function inframe_initial_check_network() {
	$label   = __( 'Visitor addresses', 'inframe' );
	$warning = inframe_proxy_warning();
	if ( $warning ) {
		return inframe_initial_check_item( 'network', $label, 'warning', $warning, inframe_admin_url( 'inframe-settings', array( 'tab' => 'network' ) ), __( 'Network', 'inframe' ) );
	}
	$message = '' !== trim( inframe_get_settings()['trusted_proxies'] ) ? __( 'Trusted proxies are set: the limits count each visitor by the address the proxy reports.', 'inframe' ) : __( 'No proxy detected: the limits count each visitor by its own address.', 'inframe' );
	return inframe_initial_check_item( 'network', $label, 'ok', $message );
}

/** Errors and warnings of a result. */
function inframe_initial_check_counts( $result ) {
	$statuses = array_column( $result['items'] ?? array(), 'status' );
	return array(
		'error'   => count( array_keys( $statuses, 'error', true ) ),
		'warning' => count( array_keys( $statuses, 'warning', true ) ),
	);
}

function inframe_initial_check_summary( $result ) {
	$n = inframe_initial_check_counts( $result );
	if ( $n['error'] ) {
		/* translators: %s: number of problems. */
		return sprintf( _n( '%s problem to fix', '%s problems to fix', $n['error'], 'inframe' ), number_format_i18n( $n['error'] ) );
	}
	if ( $n['warning'] ) {
		/* translators: %s: number of warnings. */
		return sprintf( _n( 'No blocking problem, %s warning', 'No blocking problems, %s warnings', $n['warning'], 'inframe' ), number_format_i18n( $n['warning'] ) );
	}
	return __( 'All good', 'inframe' );
}

/** The check with its last result: Overview and last step of the guided setup. */
function inframe_section_initial_check() {
	$result = get_option( 'inframe_initial_check', array() );
	$labels = array(
		'ok'      => __( 'OK', 'inframe' ),
		'warning' => __( 'To check', 'inframe' ),
		'error'   => _x( 'To fix', 'initial check status', 'inframe' ),
	);
	echo '<div id="inframe-initial-check">';
	/* translators: %s: email address that receives the test email. */
	echo '<p>' . esc_html( sprintf( __( 'Tests the AI provider, sends a test email and checks WP-Cron, HTTPS and the privacy policy. The AI test uses a few tokens; the email goes to %s.', 'inframe' ), inframe_mail_recipient() ) ) . '</p>';
	if ( empty( $result['items'] ) ) {
		echo '<p><strong>' . esc_html__( 'Not run yet.', 'inframe' ) . '</strong></p>';
	} else {
		/* translators: Initial check date and time format, see https://www.php.net/manual/datetime.format.php */
		$when = wp_date( _x( 'M j, Y \a\t g:i a', 'initial check date format', 'inframe' ), (int) $result['at'] );
		/* translators: 1: summary of the result (e.g. "All good"), 2: date and time of the last check. */
		$text = __( '<strong>%1$s</strong> — last check on %2$s.', 'inframe' );
		echo '<p>' . wp_kses( sprintf( $text, esc_html( inframe_initial_check_summary( $result ) ), esc_html( $when ) ), inframe_notice_html() ) . '</p>';
		echo '<ul class="inframe-checks">';
		foreach ( $result['items'] as $item ) {
			echo '<li data-check="' . esc_attr( $item['id'] ) . '" data-status="' . esc_attr( $item['status'] ) . '" class="inframe-check-' . esc_attr( $item['status'] ) . '">';
			echo '<strong>' . esc_html( $item['label'] ) . '</strong> <span class="inframe-check-status">' . esc_html( $labels[ $item['status'] ] ?? $item['status'] ) . '</span><br />' . esc_html( $item['message'] );
			if ( $item['fix_url'] ) {
				echo ' <a href="' . esc_url( $item['fix_url'] ) . '">' . esc_html( $item['fix_label'] ) . '</a>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	inframe_workspace_fields( 'initial_check' );
	submit_button( __( 'Run the check', 'inframe' ), 'secondary', 'submit', false );
	echo '</form></div>';
}
