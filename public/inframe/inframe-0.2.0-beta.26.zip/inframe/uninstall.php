<?php
/** Remove only local plugin options. Remote lead data follows the service retention policy. */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/** Everything the plugin keeps in one site: tables, options, transients and scheduled events. */
$inframe_uninstall_site = static function () {
	global $wpdb;
	delete_option( 'inframe_settings' );
	delete_option( 'inframe_preview_token' );

	foreach ( array( 'inframe_discovery', 'inframe_agent_preferences', 'inframe_ai_settings', 'inframe_ai_credentials', 'inframe_local_schema', 'inframe_kb_draft', 'inframe_kb_published', 'inframe_kb_previous', 'inframe_cleanup_last_run', 'inframe_initial_check' ) as $inframe_option ) {
		delete_option( $inframe_option );
	}
	foreach ( array( 'inframe_sources', 'inframe_leads', 'inframe_counters', 'inframe_sessions', 'inframe_usage', 'inframe_feedback' ) as $inframe_table ) {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- fixed table names from the list above; dropping them is the purpose of uninstall.
		$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}$inframe_table" );
	}
	// Use the API to evict corresponding option caches as well as database rows.
	$inframe_names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_inframe_' ) . '%', $wpdb->esc_like( '_transient_timeout_inframe_' ) . '%' ) );
	foreach ( $inframe_names as $inframe_name ) {
		delete_transient( preg_replace( '/^_transient_(?:timeout_)?/', '', $inframe_name ) );
	}
	wp_clear_scheduled_hook( 'inframe_local_cleanup' );
	foreach ( _get_cron_array() as $inframe_events ) {
		foreach ( $inframe_events['inframe_local_retry'] ?? array() as $inframe_event ) {
			wp_clear_scheduled_hook( 'inframe_local_retry', $inframe_event['args'] );
		}
	}
};

// On a network every site has its own tables, requests with personal data and encrypted keys (audit beta.25, B4).
if ( is_multisite() ) {
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $inframe_site_id ) {
		switch_to_blog( $inframe_site_id );
		$inframe_uninstall_site();
		restore_current_blog();
	}
} else {
	$inframe_uninstall_site();
}
