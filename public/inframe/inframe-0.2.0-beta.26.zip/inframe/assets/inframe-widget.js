/*!
 * inFrame – widget chat (v0.1)
 * Vanilla JS, nessuna dipendenza, isolato in Shadow DOM.
 *
 * Uso:
 *   <script src="inframe-widget.js" defer
 *     data-endpoint="https://…/webhook/<webhook della chat>"
 *     data-site-key="impiantirossi-demo"
 *     data-mode="servizi"            (servizi | ecommerce)
 *     data-title="Assistente Impianti Rossi"
 *     data-company="Impianti Rossi"
 *     data-color="#0b5cad"
 *     data-privacy-url="https://…/privacy"
 *     data-fallback-phone="089 000000"
 *     data-fallback-email="info@…"
 *     data-suggestions="Fate manutenzione caldaie?|Dove lavorate?"></script>
 *     data-lang="it"                (it | en, P6.8; predefinito it)
 * oppure window.INFRAME_CONFIG = { endpoint, siteKey, mode, … } prima dello script.
 *
 * API: window.INFRAME.open() · close() · toggle() · reset() · send(testo)
 */
(function () {
  'use strict';
  if (window.INFRAME && window.INFRAME.__loaded) return;

  // ---------------------------------------------------------------- config
  var script = document.currentScript || document.querySelector('script[data-site-key]');
  var ds = (script && script.dataset) || {};
  // The WordPress plugin owns its endpoint; an old standalone embed must not override it.
  var plugin = ds.inframePlugin === 'true';
  var user = plugin ? {} : (window.INFRAME_CONFIG || {});
  var pick = function (k, d) { return user[k] != null ? user[k] : (ds[k] != null && ds[k] !== '' ? ds[k] : d); };

  var cfg = {
    endpoint: pick('endpoint', ''),
    siteKey: pick('siteKey', ''),
    mode: pick('mode', 'servizi') === 'ecommerce' ? 'ecommerce' : 'servizi',
    // P6.8: the plugin passes the site language; only Italian (default) and English exist.
    lang: pick('lang', 'it') === 'en' ? 'en' : 'it',
    title: pick('title', ''),
    company: pick('company', ''),
    color: pick('color', '#1f5fbf'),
    position: pick('position', 'right') === 'left' ? 'left' : 'right',
    welcome: pick('welcome', ''),
    privacyUrl: pick('privacyUrl', ''),
    consentText: pick('consentText', ''),
    consentVersion: pick('consentVersion', 'privacy-v1'),
    marketingConsent: String(pick('marketingConsent', 'false')) === 'true',
    fallbackPhone: pick('fallbackPhone', ''),
    fallbackEmail: pick('fallbackEmail', ''),
    // P6.6: solo cifre con il prefisso internazionale; altrimenti niente link
    whatsapp: (function (n) { n = String(n || '').replace(/\D/g, ''); return n.length >= 8 && n.length <= 15 ? n : ''; })(pick('whatsapp', '')),
    launcherLabel: pick('launcherLabel', ''),
    suggestions: pick('suggestions', ''),
    // P6.17: guided paths, opening hours ({"mon":"09:00-13:00, 15:00-19:00",…}) in the site time zone, closed message.
    paths: pick('paths', ''),
    hours: pick('hours', ''),
    timezone: pick('timezone', ''),
    closedMessage: pick('closedMessage', ''),
    // Audit beta.25, B2: preview token of the plugin's test chat, sent in a header and never in the URL.
    preview: pick('preview', ''),
    open: String(pick('open', 'false')) === 'true',
    timeoutMs: Number(pick('timeoutMs', 30000)) || 30000
  };
  var list = function (v) { return typeof v === 'string' ? v.split('|').map(function (s) { return s.trim(); }).filter(Boolean) : (v || []); };
  cfg.suggestions = list(cfg.suggestions);
  cfg.paths = list(cfg.paths).slice(0, 3);
  if (typeof cfg.hours === 'string') { try { cfg.hours = cfg.hours ? JSON.parse(cfg.hours) : null; } catch (e) { cfg.hours = null; } }
  if (!cfg.endpoint || !cfg.siteKey) { console.warn('[INFRAME] endpoint e site-key sono obbligatori'); return; }

  // ---------------------------------------------------------------- testi (P6.8: italiano e inglese)
  var L = {
    it: {
      closed: 'Ora siamo chiusi: lasciaci la tua richiesta e ti ricontattiamo appena riapriamo.',
      todayHours: 'Oggi: %s',
      closedToday: 'Oggi siamo chiusi.',
      paths: 'Come possiamo aiutarti?',
      you: 'Tu: ',
      priceOnRequest: 'prezzo su richiesta',
      assistant: 'Assistente: ',
      emergency: 'Numero per le urgenze: ',
      total: 'Totale indicativo: ',
      sources: 'Fonti:',
      page: 'pagina',
      rate: 'Valuta la risposta',
      helpful: 'Risposta utile',
      notHelpful: 'Risposta non utile',
      thanks: 'Grazie per il riscontro.',
      rateFailed: 'Non siamo riusciti a registrare il voto.',
      direct: 'Puoi contattarci direttamente: ',
      chooseOption: 'Scegli un’opzione',
      faq: 'Domande frequenti',
      contactForm: 'Modulo di contatto',
      handoffTitle: 'Ti mettiamo in contatto con il team',
      leadTitle: 'Lascia i tuoi contatti',
      summary: 'Riepilogo della richiesta:',
      name: 'Nome',
      email: 'Email',
      phone: 'Telefono',
      optional: ' (facoltativo)',
      emailOrPhone: 'Basta l’email o il telefono.',
      marketing: 'Acconsento a ricevere comunicazioni commerciali da %s. (Facoltativo)',
      submit: 'Invia la richiesta',
      later: 'Non ora',
      orDirect: 'Oppure contattaci direttamente: ',
      errEmail: 'Inserisci un indirizzo email valido.',
      errContact: 'Serve un’email o un numero di telefono valido.',
      errEmailFormat: 'L’indirizzo email non sembra corretto.',
      errPhone: 'Il numero di telefono non sembra corretto.',
      errPrivacy: 'Per inviare la richiesta serve la conferma dell’informativa.',
      typing: 'Stiamo scrivendo la risposta',
      sentPlaceholder: 'Richiesta inviata. Usa ↻ per una nuova conversazione.',
      offline: 'In questo momento non riusciamo a rispondere. Lasciaci i tuoi contatti: la richiesta arriverà al nostro team.',
      sendFailed: 'Non siamo riusciti a inviare la richiesta: il servizio non risponde. Riprova tra poco.',
      sending: 'Invio in corso…',
      wantPerson: 'Vorrei parlare con una persona del team.',
      wantContact: 'Vorrei essere ricontattato per questa richiesta.',
      checkData: 'Controlla i dati inseriti.',
      serviceDown: 'Il servizio non risponde, la richiesta non è stata inviata.',
      title: 'Assistente virtuale',
      launcher: 'Hai domande? Chiedi a noi',
      launcherAria: 'Apri la chat con l\'assistente virtuale (intelligenza artificiale)',
      subtitle: 'Risponde con i contenuti del sito',
      reset: 'Nuova conversazione',
      close: 'Chiudi',
      closeAria: 'Chiudi la chat',
      inputLabel: 'Scrivi un messaggio',
      placeholder: 'Scrivi la tua domanda…',
      send: 'Invia',
      foot: 'Risposte generate da un\'intelligenza artificiale: possono contenere imprecisioni.',
      privacy: 'Informativa privacy',
      company: 'l\'azienda',
      welcome: function (c) {
        return 'Ciao! Questo è l\'assistente virtuale di ' + c + ', un sistema di intelligenza artificiale: ' +
          'risponde usando le informazioni presenti su questo sito. Per richieste particolari possiamo metterti in contatto con una persona del nostro team.';
      },
      consent: function (c) {
        // "ad aiframe", "all'azienda", "a Impianti Rossi"
        var to = /^l'/i.test(c) ? 'al' + c : (/^a/i.test(c) ? 'ad ' : 'a ') + c;
        return 'Per ricontattarti trasmetteremo ' + to + ' il riepilogo della tua richiesta e i dati di contatto ' +
          'che ci hai indicato, usati solo per rispondere alla tua richiesta.';
      }
    },
    en: {
      closed: 'We are closed now: leave us your request and we will get back to you when we reopen.',
      todayHours: 'Today: %s',
      closedToday: 'We are closed today.',
      paths: 'How can we help?',
      you: 'You: ',
      priceOnRequest: 'price on request',
      assistant: 'Assistant: ',
      emergency: 'Emergency number: ',
      total: 'Indicative total: ',
      sources: 'Sources:',
      page: 'page',
      rate: 'Rate the answer',
      helpful: 'Helpful answer',
      notHelpful: 'Not helpful answer',
      thanks: 'Thanks for your feedback.',
      rateFailed: 'We could not record your rating.',
      direct: 'You can contact us directly: ',
      chooseOption: 'Choose an option',
      faq: 'Frequently asked questions',
      contactForm: 'Contact form',
      handoffTitle: 'We’ll put you in touch with our team',
      leadTitle: 'Leave your contact details',
      summary: 'Summary of your request:',
      name: 'Name',
      email: 'Email',
      phone: 'Phone',
      optional: ' (optional)',
      emailOrPhone: 'Your email or your phone is enough.',
      marketing: 'I agree to receive marketing communications from %s. (Optional)',
      submit: 'Send the request',
      later: 'Not now',
      orDirect: 'Or contact us directly: ',
      errEmail: 'Please enter a valid email address.',
      errContact: 'We need a valid email or phone number.',
      errEmailFormat: 'The email address does not look right.',
      errPhone: 'The phone number does not look right.',
      errPrivacy: 'To send the request, please confirm the privacy policy.',
      typing: 'We are writing the answer',
      sentPlaceholder: 'Request sent. Use ↻ to start a new conversation.',
      offline: 'We can’t answer right now. Leave us your contact details: your request will reach our team.',
      sendFailed: 'We could not send your request: the service is not responding. Please try again shortly.',
      sending: 'Sending…',
      wantPerson: 'I would like to talk to a person from your team.',
      wantContact: 'I would like to be contacted about this request.',
      checkData: 'Please check the details you entered.',
      serviceDown: 'The service is not responding: your request was not sent.',
      title: 'Virtual assistant',
      launcher: 'Questions? Ask us',
      launcherAria: 'Open the chat with the virtual assistant (artificial intelligence)',
      subtitle: 'Answers from this site\'s content',
      reset: 'New conversation',
      close: 'Close',
      closeAria: 'Close the chat',
      inputLabel: 'Write a message',
      placeholder: 'Type your question…',
      send: 'Send',
      foot: 'Answers generated by artificial intelligence: they may contain inaccuracies.',
      privacy: 'Privacy policy',
      company: 'the business',
      welcome: function (c) {
        return 'Hi! This is the virtual assistant of ' + c + ', an artificial intelligence system: ' +
          'it answers using the information on this site. For special requests we can put you in touch with a person from our team.';
      },
      consent: function (c) {
        return 'To get back to you we will send ' + c + ' a summary of your request and the contact details ' +
          'you gave us, used only to answer your request.';
      }
    }
  }[cfg.lang];
  cfg.title = cfg.title || L.title;
  cfg.launcherLabel = cfg.launcherLabel || L.launcher;
  var company = cfg.company || L.company;
  var WELCOME = cfg.welcome || L.welcome(company);
  var CONSENT = cfg.consentText || L.consent(company);

  // ---------------------------------------------------------------- stato (sessionStorage, solo per la scheda)
  var KEY = 'inframe:' + cfg.siteKey;
  var store = {
    get: function () { try { return JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e) { return null; } },
    set: function (v) { try { sessionStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* storage non disponibile */ } },
    del: function () { try { sessionStorage.removeItem(KEY); } catch (e) { /* noop */ } }
  };
  var uuid = function () {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
    });
  };
  var fresh = function () { return { sessionId: uuid(), items: [], state: 'domande', profile: {}, done: false, isOpen: false }; };
  var S = store.get() || fresh();
  var save = function () { store.set(S); };

  var utm = (function () {
    try {
      var q = new URLSearchParams(location.search);
      return { source: q.get('utm_source') || '', medium: q.get('utm_medium') || '', campaign: q.get('utm_campaign') || '' };
    } catch (e) { return {}; }
  })();

  // ---------------------------------------------------------------- utilità
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  // Solo link http(s) o percorsi dello stesso sito: niente javascript: o data:
  var safeUrl = function (u) { return /^(https?:\/\/|\/(?!\/))/i.test(String(u || '')) ? String(u) : ''; };
  // Testo del modello: escape, **grassetto**, link http(s), a capo.
  var fmt = function (text) {
    var h = esc(text);
    h = h.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    h = h.replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)])/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
    return h.replace(/\n/g, '<br>');
  };
  var telHref = function (s) { var m = String(s).match(/\+?\d[\d\s]{4,}\d/); return m ? 'tel:' + m[0].replace(/\s/g, '') : ''; };
  var euro = function (n) { return n == null ? L.priceOnRequest : Number(n).toLocaleString(cfg.lang === 'en' ? 'en-GB' : 'it-IT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }); };
  var el = function (tag, attrs, html) {
    var e = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) { if (attrs[k] != null && attrs[k] !== false) e.setAttribute(k, attrs[k] === true ? '' : attrs[k]); });
    if (html != null) e.innerHTML = html;
    return e;
  };

  // ---------------------------------------------------------------- rete
  // Audit beta.25, I2: the page address (with the preview token in test mode) and the UTM codes go only to the
  // n8n pilot, which uses them; the WordPress plugin ignores them, so it does not receive them.
  function pageContext(body) {
    if (!plugin) { body.page_url = location.href; body.utm = utm; }
    return body;
  }

  function post(body) {
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, cfg.timeoutMs) : null;
    var headers = { 'Content-Type': 'application/json' };
    if (/ngrok/.test(cfg.endpoint)) headers['ngrok-skip-browser-warning'] = '1';
    if (cfg.preview) headers['X-Inframe-Preview'] = cfg.preview;
    return fetch(cfg.endpoint, { method: 'POST', headers: headers, body: JSON.stringify(body), signal: ctrl && ctrl.signal, credentials: 'omit' })
      .then(function (res) {
        return res.text().then(function (t) {
          var data = null;
          try { data = t ? JSON.parse(t) : null; } catch (e) { data = null; }
          // n8n restituisce 200 con corpo vuoto se il workflow va in errore: è un guasto, non una risposta
          if (!data || typeof data !== 'object') throw new Error('empty_response_' + res.status);
          data.__http = res.status;
          return data;
        });
      })
      .finally(function () { if (timer) clearTimeout(timer); });
  }

  // Le due verticali hanno contratti diversi: li riportiamo a una forma unica.
  function normalize(r) {
    var n = {
      ok: r.ok !== false, status: r.status || '', reply: r.reply || '',
      sources: Array.isArray(r.sources) ? r.sources : [],
      products: [], total: null, action: null,
      emergency: r.emergency_contact || null,
      disclosure: r.show_ai_disclosure && r.ai_disclosure ? r.ai_disclosure : null,
      state: r.conversation_state || null,
      done: r.status === 'lead_captured' || r.status === 'lead_already_sent',
      errors: r.errors || r.validation_errors || [],
      // P6.9: solo il plugin WordPress manda l'identificativo di una risposta verificata; senza, niente pulsanti
      answerId: typeof r.answer_id === 'string' && /^[a-f0-9]{16}$/.test(r.answer_id) ? r.answer_id : null
    };
    if (cfg.mode === 'servizi') {
      var a = r.action;
      if (a && a.type === 'ask_field') n.action = { type: 'ask_field', field: a.field, label: a.label, options: a.options || [] };
      if (a && a.type === 'show_contact_form') {
        n.action = { type: 'contact_form', reason: a.reason || 'lead', consentText: a.consent_text, privacyUrl: a.privacy_url,
          version: a.consent_notice_version, marketing: a.marketing_consent === true, summary: a.summary || [] };
      }
    } else {
      n.products = Array.isArray(r.recommended_setup) ? r.recommended_setup : [];
      n.total = r.estimated_total_eur || null;
      if (n.products.length) n.sources = []; // i link stanno già nelle schede prodotto
      if (r.advisor_profile && typeof r.advisor_profile === 'object') S.profile = r.advisor_profile;
      if (!n.done && (r.needs_contact_capture || r.show_contact_form)) {
        n.action = { type: 'contact_form', reason: r.status === 'ai_unavailable' ? 'handoff' : 'lead',
          privacyUrl: r.privacy_url, version: r.consent_notice_version, marketing: false, summary: [], emailRequired: true };
      }
    }
    return n;
  }

  // ---------------------------------------------------------------- colori leggibili (P6.7)
  // The owner picks any colour. Text on it is white or dark, whichever reads better; if neither reaches
  // WCAG AA (4.5:1) the surface is darkened until white does. Text in the colour on light backgrounds uses a
  // darker shade when needed. The brand colour stays recognisable and nothing becomes unreadable.
  var palette = (function (hex) {
    var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex).trim());
    var h = m ? m[1] : '1f5fbf';
    if (h.length === 3) h = h.replace(/./g, '$&$&');
    var rgb = [0, 2, 4].map(function (i) { return parseInt(h.substr(i, 2), 16); });
    var lum = function (c) {
      var v = c.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
      return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
    };
    var ratio = function (a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
    var darker = function (c, against, min) {
      for (var t = 0; t < 1 && ratio(c, against) < min; t += 0.04) c = rgb.map(function (x) { return Math.round(x * (1 - t)); });
      return c;
    };
    var css = function (c) { return '#' + c.map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); };
    var white = [255, 255, 255], ink = [29, 35, 48], soft = [244, 246, 249];
    var surface = rgb, on = ratio(rgb, white) >= ratio(rgb, ink) ? white : ink;
    if (ratio(surface, on) < 4.6) { surface = darker(rgb, white, 4.6); on = white; }
    return { c: css(rgb), surface: css(surface), on: css(on), text: css(darker(rgb, soft, 4.6)) };
  })(cfg.color);

  // ---------------------------------------------------------------- stile
  var CSS = [
    ':host{all:initial}',
    '*{box-sizing:border-box}',
    '.root{--c:' + palette.c + ';--cs:' + palette.surface + ';--on:' + palette.on + ';--ct:' + palette.text + ';--ink:#1d2330;--muted:#5b6372;--line:#e3e6ec;--bg:#fff;--soft:#f4f6f9;',
    ' font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:var(--ink);',
    ' position:fixed;bottom:20px;' + cfg.position + ':20px;z-index:2147483000}',
    'button,textarea,input{font:inherit;color:inherit}',
    '.launch{display:flex;align-items:center;gap:10px;border:0;cursor:pointer;background:var(--cs);color:var(--on);',
    ' border-radius:999px;padding:12px 18px 12px 14px;box-shadow:0 6px 24px rgba(16,24,40,.25);font-weight:600}',
    '.launch:hover{filter:brightness(1.08)}',
    '.launch svg{width:24px;height:24px;flex:none}',
    '.launch .lbl{white-space:nowrap}',
    '.panel{position:absolute;bottom:0;' + cfg.position + ':0;width:380px;height:min(620px,calc(100vh - 40px));',
    ' background:var(--bg);border-radius:16px;box-shadow:0 12px 48px rgba(16,24,40,.28);display:flex;flex-direction:column;overflow:hidden}',
    '.panel[hidden],.launch[hidden]{display:none}',
    '.hd{background:var(--cs);color:var(--on);padding:14px 12px 12px 16px;display:flex;align-items:center;gap:10px}',
    '.av{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.2);display:grid;place-items:center;flex:none}',
    '.av svg{width:20px;height:20px}',
    '.ht{flex:1;min-width:0}',
    '.ht b{display:block;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.ht span{font-size:12px}',
    '.badge{display:inline-block;background:var(--on);color:var(--cs);border-radius:4px;padding:0 5px;margin-right:4px;font-weight:700;font-size:11px;letter-spacing:.3px}',
    '.ib{background:transparent;border:0;color:var(--on);width:34px;height:34px;border-radius:8px;cursor:pointer;display:grid;place-items:center}',
    '.ib:hover{background:rgba(255,255,255,.16)}',
    '.ib svg{width:18px;height:18px}',
    '.log{flex:1;overflow-y:auto;padding:16px 14px 8px;background:var(--soft);display:flex;flex-direction:column;gap:10px}',
    '.notice{background:#fff;border:1px solid var(--line);border-left:4px solid var(--c);border-radius:10px;padding:10px 12px;font-size:13.5px}',
    '.notice a{color:var(--ct)}',
    '.closed{background:#fff7e6;border:1px solid #f5d38a;border-radius:10px;padding:9px 12px;font-size:13.5px}',
    '.msg{max-width:86%;padding:9px 12px;border-radius:14px;word-wrap:break-word;overflow-wrap:anywhere}',
    '.bot{align-self:flex-start;background:#fff;border:1px solid var(--line);border-bottom-left-radius:4px}',
    '.me{align-self:flex-end;background:var(--cs);color:var(--on);border-bottom-right-radius:4px}',
    '.bot a{color:var(--ct)}',
    '.err{align-self:flex-start;background:#fff4f2;border:1px solid #f3c7bf;color:#7a2617}',
    '.err a{color:#7a2617;font-weight:600}',
    '.src{margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;font-size:12.5px}',
    '.src span{color:var(--muted)}',
    '.src a{color:var(--ct);background:var(--soft);border:1px solid var(--line);border-radius:999px;padding:2px 9px;text-decoration:none}',
    '.src a:hover{text-decoration:underline}',
    '.rate{margin-top:6px;display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--muted)}',
    '.rate .rt{border:1px solid var(--line);background:var(--bg);border-radius:999px;padding:1px 8px;cursor:pointer;font-size:14px;line-height:1.4}',
    '.rate .rt[aria-pressed="true"]{border-color:var(--ct);background:var(--soft)}',
    '.rate .rt:focus-visible{outline:2px solid var(--ct);outline-offset:2px}',
    '.rate .rt:disabled{opacity:.6;cursor:default}',
    '.emg{margin-top:8px;background:#fff7e6;border:1px solid #f5d38a;border-radius:8px;padding:7px 10px;font-size:13.5px}',
    '.emg a{color:#7a4b00;font-weight:700}',
    '.prods{display:flex;flex-direction:column;gap:6px;margin-top:8px}',
    '.prod{display:flex;justify-content:space-between;gap:10px;border:1px solid var(--line);border-radius:8px;padding:7px 10px;text-decoration:none;color:var(--ink);background:var(--soft)}',
    'a.prod:hover{border-color:var(--ct)}',
    '.prod b{font-weight:600}',
    '.prod small{display:block;color:var(--muted);font-size:11.5px}',
    '.prod .pr{white-space:nowrap;font-weight:700}',
    '.tot{font-size:13px;color:var(--muted);text-align:right}',
    '.opts{display:flex;flex-wrap:wrap;gap:6px;align-self:flex-start;max-width:92%}',
    '.opt{border:1.5px solid var(--ct);color:var(--ct);background:#fff;border-radius:999px;padding:6px 12px;cursor:pointer;font-size:14px}',
    '.opt:hover,.opt:focus-visible{background:var(--cs);color:var(--on)}',
    '.form{align-self:stretch;background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:8px}',
    '.form h3{margin:0;font-size:15px}',
    '.form ul{margin:0;padding-left:18px;font-size:13.5px;color:var(--muted)}',
    '.form label{font-size:13px;font-weight:600;display:flex;flex-direction:column;gap:3px}',
    '.form input[type=text],.form input[type=email],.form input[type=tel]{border:1px solid #c9ced8;border-radius:8px;padding:8px 10px;font-weight:400;background:#fff}',
    '.form input:focus{outline:2px solid var(--ct);outline-offset:0;border-color:var(--ct)}',
    // Audit beta.25, B1: honeypot field, out of sight and out of the accessibility tree.
    '.form .hp{position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden}',
    '.form .ck{flex-direction:row;align-items:flex-start;gap:8px;font-weight:400;font-size:12.5px;color:var(--ink)}',
    '.form .ck input{margin-top:2px;flex:none;width:16px;height:16px;accent-color:var(--ct)}',
    '.form .ck a{color:var(--ct)}',
    '.form .hint{font-size:12px;color:var(--muted);margin:0}',
    '.form .fe{color:#a32711;font-size:13px;margin:0}',
    '.row{display:flex;gap:8px}',
    '.pri{flex:1;background:var(--cs);color:var(--on);border:0;border-radius:8px;padding:10px;font-weight:700;cursor:pointer}',
    '.pri[disabled]{opacity:.6;cursor:wait}',
    '.sec{background:#fff;border:1px solid #c9ced8;border-radius:8px;padding:10px 12px;cursor:pointer}',
    '.typing{align-self:flex-start;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 14px;display:flex;gap:4px}',
    '.typing i{width:7px;height:7px;border-radius:50%;background:#9aa3b2;animation:b 1.2s infinite}',
    '.typing i:nth-of-type(2){animation-delay:.15s}.typing i:nth-of-type(3){animation-delay:.3s}',
    '@keyframes b{0%,60%,100%{transform:translateY(0);opacity:.5}30%{transform:translateY(-4px);opacity:1}}',
    '.sugg{display:flex;flex-wrap:wrap;gap:6px}',
    'form.comp{display:flex;gap:8px;align-items:flex-end;border-top:1px solid var(--line);padding:10px 10px 6px;background:#fff}',
    'textarea{flex:1;resize:none;border:1px solid #c9ced8;border-radius:10px;padding:9px 11px;max-height:120px;min-height:42px;line-height:1.4}',
    'textarea:focus{outline:2px solid var(--ct);outline-offset:0;border-color:var(--ct)}',
    '.send{width:42px;height:42px;border-radius:10px;border:0;background:var(--cs);color:var(--on);cursor:pointer;display:grid;place-items:center;flex:none}',
    '.send[disabled]{opacity:.5;cursor:not-allowed}',
    '.send svg{width:20px;height:20px}',
    '.foot{font-size:11.5px;color:var(--muted);text-align:center;padding:0 10px 8px;background:#fff}',
    '.foot a{color:var(--muted)}',
    '.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}',
    ':focus-visible{outline:2px solid var(--ct);outline-offset:2px}',
    '.hd :focus-visible{outline-color:var(--on)}',
    '@media (max-width:480px){.root{bottom:12px;' + cfg.position + ':12px}',
    ' .root.open{top:0;bottom:0;left:0;right:0}',
    ' .panel{position:fixed;inset:0;width:auto;height:100%;border-radius:0}',
    ' .launch .lbl{display:none}.launch{padding:14px}}',
    '@media (prefers-reduced-motion:reduce){.typing i{animation:none}}'
  ].join('\n');

  var ICON = {
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12z"/></svg>',
    bot: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9 17h6"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    reset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'
  };

  // ---------------------------------------------------------------- DOM
  var host = el('div', { id: 'inframe-widget', lang: cfg.lang });
  var shadow = host.attachShadow({ mode: 'open' });
  var style = el('style'); style.textContent = CSS;
  var root = el('div', { 'class': 'root' });
  // P6.7: no aria-label, so the visible label starts the accessible name and the AI mention follows it.
  var launch = el('button', { 'class': 'launch', type: 'button', 'aria-haspopup': 'dialog', 'aria-expanded': 'false' },
    ICON.chat + '<span class="lbl">' + esc(cfg.launcherLabel) + '</span>' +
    '<span class="sr">' + (cfg.launcherLabel ? ' – ' : '') + esc(L.launcherAria) + '</span>');
  var panel = el('div', { 'class': 'panel', role: 'dialog', 'aria-modal': 'false', 'aria-labelledby': 'inframe-t', hidden: true });
  panel.innerHTML =
    '<div class="hd"><div class="av">' + ICON.bot + '</div>' +
    '<div class="ht"><b id="inframe-t">' + esc(cfg.title) + '</b><span><span class="badge">AI</span>' + esc(L.subtitle) + '</span></div>' +
    '<button class="ib" type="button" data-act="reset" title="' + esc(L.reset) + '" aria-label="' + esc(L.reset) + '">' + ICON.reset + '</button>' +
    '<button class="ib" type="button" data-act="close" title="' + esc(L.close) + '" aria-label="' + esc(L.closeAria) + '">' + ICON.close + '</button></div>' +
    '<div class="log" role="log" aria-live="polite" aria-relevant="additions"></div>' +
    '<form class="comp" novalidate><label class="sr" for="inframe-in">' + esc(L.inputLabel) + '</label>' +
    '<textarea id="inframe-in" rows="1" maxlength="1000" placeholder="' + esc(L.placeholder) + '" autocomplete="off"></textarea>' +
    '<button class="send" type="submit" aria-label="' + esc(L.send) + '" disabled>' + ICON.send + '</button></form>' +
    '<div class="foot">' + esc(L.foot) +
    (safeUrl(cfg.privacyUrl) ? ' <a href="' + esc(cfg.privacyUrl) + '" target="_blank" rel="noopener">' + esc(L.privacy) + '</a>' : '') + '</div>';
  root.appendChild(launch); root.appendChild(panel);
  shadow.appendChild(style); shadow.appendChild(root);

  var log = panel.querySelector('.log');
  var form = panel.querySelector('form.comp');
  var input = panel.querySelector('textarea');
  var sendBtn = panel.querySelector('.send');
  var busy = false;

  // ---------------------------------------------------------------- rendering
  function scroll() { log.scrollTop = log.scrollHeight; }

  function renderItem(it) {
    var node;
    if (it.kind === 'notice') {
      node = el('div', { 'class': 'notice' }, fmt(it.text) +
        (safeUrl(it.privacyUrl) ? ' <a href="' + esc(it.privacyUrl) + '" target="_blank" rel="noopener">' + esc(L.privacy) + '</a>' : ''));
    } else if (it.kind === 'me') {
      node = el('div', { 'class': 'msg me' }, fmt(it.text));
      node.insertBefore(el('span', { 'class': 'sr' }, esc(L.you)), node.firstChild);
    } else if (it.kind === 'error') {
      node = el('div', { 'class': 'msg err' }, fmt(it.text) + fallbackHtml());
    } else {
      var html = '<span class="sr">' + esc(L.assistant) + '</span>' + fmt(it.text);
      if (it.emergency) {
        var tel = telHref(it.emergency);
        var num = (String(it.emergency).match(/\+?\d[\d\s]{4,}\d/) || [it.emergency])[0];
        html += '<div class="emg">' + esc(L.emergency) + (tel ? '<a href="' + tel + '">' + esc(num) + '</a>' : esc(it.emergency)) + '</div>';
      }
      if (it.products && it.products.length) {
        html += '<div class="prods">' + it.products.map(function (p) {
          var inner = '<span><b>' + esc(p.name) + '</b><small>' + esc(p.sku || '') + '</small></span><span class="pr">' + euro(p.price_eur) + '</span>';
          var u = safeUrl(p.url);
          return u ? '<a class="prod" href="' + esc(u) + '" target="_blank" rel="noopener">' + inner + '</a>' : '<div class="prod">' + inner + '</div>';
        }).join('') + (it.total ? '<div class="tot">' + esc(L.total) + '<b>' + euro(it.total) + '</b></div>' : '') + '</div>';
      }
      var src = (it.sources || []).filter(function (s) { return safeUrl(s.url); });
      if (src.length) {
        html += '<div class="src"><span>' + esc(L.sources) + '</span>' + src.map(function (s) {
          return '<a href="' + esc(s.url) + '" target="_blank" rel="noopener">' + esc(s.title || L.page) + '</a>';
        }).join('') + '</div>';
      }
      if (it.answerId) {
        html += '<div class="rate" role="group" aria-label="' + esc(L.rate) + '">' +
          '<button type="button" class="rt" data-rate="1" aria-label="' + esc(L.helpful) + '" aria-pressed="' + (it.rating === 1) + '">👍</button>' +
          '<button type="button" class="rt" data-rate="-1" aria-label="' + esc(L.notHelpful) + '" aria-pressed="' + (it.rating === -1) + '">👎</button>' +
          '<span class="rt-msg" role="status">' + (it.rating ? esc(L.thanks) : '') + '</span></div>';
      }
      node = el('div', { 'class': 'msg bot' }, html);
      if (it.answerId) node.querySelector('.rate').addEventListener('click', function (e) { var b = e.target.closest('.rt'); if (b) rate(it, node, Number(b.getAttribute('data-rate'))); });
    }
    log.appendChild(node);
    return node;
  }

  // Contatti diretti: WhatsApp (P6.6, senza testo precompilato: la conversazione non esce dal sito), telefono, email
  function directLinks() {
    var parts = [];
    if (cfg.whatsapp) parts.push('<a href="https://wa.me/' + cfg.whatsapp + '" target="_blank" rel="noopener">WhatsApp</a>');
    if (cfg.fallbackPhone) parts.push('<a href="' + telHref(cfg.fallbackPhone) + '">' + esc(cfg.fallbackPhone) + '</a>');
    if (cfg.fallbackEmail) parts.push('<a href="mailto:' + esc(cfg.fallbackEmail) + '">' + esc(cfg.fallbackEmail) + '</a>');
    return parts.join(' · ');
  }

  function fallbackHtml() {
    var links = directLinks();
    return links ? '<br>' + esc(L.direct) + links : '';
  }

  function clearInteractive() {
    Array.prototype.forEach.call(log.querySelectorAll('.opts,.form,.sugg'), function (n) { n.remove(); });
  }

  function renderOptions(action) {
    var box = el('div', { 'class': 'opts', role: 'group', 'aria-label': action.label || L.chooseOption });
    action.options.forEach(function (o) {
      var b = el('button', { 'class': 'opt', type: 'button' }, esc(o));
      b.addEventListener('click', function () { choose(o); });
      box.appendChild(b);
    });
    log.appendChild(box);
  }

  // P6.17: weekday and minutes now in the site time zone (IANA name or a fixed offset such as +01:00).
  function siteNow() {
    var now = new Date(), days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    var off = /^([+-])(\d{2}):(\d{2})$/.exec(cfg.timezone || '');
    if (off || !cfg.timezone) {
      var shift = off ? (off[1] === '-' ? -1 : 1) * (Number(off[2]) * 60 + Number(off[3])) : -now.getTimezoneOffset();
      var t = new Date(now.getTime() + shift * 60000);
      return { day: days[t.getUTCDay()], minutes: t.getUTCHours() * 60 + t.getUTCMinutes() };
    }
    try {
      var parts = {};
      new Intl.DateTimeFormat('en-US', { timeZone: cfg.timezone, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
        .formatToParts(now).forEach(function (p) { parts[p.type] = p.value; });
      return { day: String(parts.weekday).toLowerCase().slice(0, 3), minutes: Number(parts.hour) % 24 * 60 + Number(parts.minute) };
    } catch (e) { return null; }
  }

  function renderClosed() {
    if (!cfg.hours || typeof cfg.hours !== 'object') return;
    var now = siteNow();
    if (!now) return;
    var today = String(cfg.hours[now.day] || '');
    var open = today.split(',').some(function (r) {
      var m = /(\d{2}):(\d{2})-(\d{2}):(\d{2})/.exec(r);
      return m && now.minutes >= Number(m[1]) * 60 + Number(m[2]) && now.minutes < Number(m[3]) * 60 + Number(m[4]);
    });
    if (open) return;
    log.appendChild(el('div', { 'class': 'closed', role: 'status' }, esc(cfg.closedMessage || L.closed) + '<br>' +
      esc(today ? L.todayHours.replace('%s', today) : L.closedToday)));
  }

  function renderPaths() {
    if (!cfg.paths.length) return;
    var box = el('div', { 'class': 'paths opts', role: 'group', 'aria-label': L.paths });
    cfg.paths.forEach(function (s) {
      var b = el('button', { 'class': 'opt', type: 'button' }, esc(s));
      b.addEventListener('click', function () { choose(s); });
      box.appendChild(b);
    });
    log.appendChild(box);
  }

  function renderSuggestions() {
    if (!cfg.suggestions.length) return;
    var box = el('div', { 'class': 'sugg opts', role: 'group', 'aria-label': L.faq });
    cfg.suggestions.forEach(function (s) {
      var b = el('button', { 'class': 'opt', type: 'button' }, esc(s));
      b.addEventListener('click', function () { choose(s); });
      box.appendChild(b);
    });
    log.appendChild(box);
  }

  function renderForm(a) {
    var priv = safeUrl(a.privacyUrl) || safeUrl(cfg.privacyUrl);
    var emailReq = a.emailRequired === true;
    var f = el('form', { 'class': 'form', novalidate: true, 'aria-label': L.contactForm });
    f.innerHTML =
      '<h3>' + esc(a.reason === 'handoff' ? L.handoffTitle : L.leadTitle) + '</h3>' +
      (a.summary && a.summary.length ? '<p class="hint">' + esc(L.summary) + '</p><ul>' + a.summary.map(function (s) {
        return '<li>' + (s && typeof s === 'object' ? esc(s.label) + ': ' + esc(s.value) : esc(s)) + '</li>';
      }).join('') + '</ul>' : '') +
      '<label>' + esc(L.name) + '<input type="text" name="cname" autocomplete="name" maxlength="80"></label>' +
      '<label>' + esc(L.email) + '<input type="email" name="email" autocomplete="email" maxlength="200"' + (emailReq ? ' required' : '') + '></label>' +
      '<label>' + esc(L.phone) + (emailReq ? esc(L.optional) : '') + '<input type="tel" name="phone" autocomplete="tel" maxlength="20"></label>' +
      '<div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>' +
      (emailReq ? '' : '<p class="hint">' + esc(L.emailOrPhone) + '</p>') +
      '<label class="ck"><input type="checkbox" name="privacy" required><span>' + esc(a.consentText || CONSENT) +
      (priv ? ' <a href="' + esc(priv) + '" target="_blank" rel="noopener">' + esc(L.privacy) + '</a>' : '') + '</span></label>' +
      (a.marketing ? '<label class="ck"><input type="checkbox" name="mkt"><span>' + esc(L.marketing.replace('%s', company)) + '</span></label>' : '') +
      '<p class="fe" role="alert" hidden></p>' +
      '<div class="row"><button class="pri" type="submit">' + esc(L.submit) + '</button><button class="sec" type="button" data-act="later">' + esc(L.later) + '</button></div>' +
      (directLinks() ? '<p class="hint direct">' + esc(L.orDirect) + directLinks() + '</p>' : '');
    var fe = f.querySelector('.fe');
    var showErr = function (t) { fe.textContent = t; fe.hidden = !t; };
    f.addEventListener('input', function () { if (!fe.hidden) showErr(''); });
    f.addEventListener('change', function () { if (!fe.hidden) showErr(''); });
    f.querySelector('[data-act=later]').addEventListener('click', function () {
      f.remove(); S.pendingForm = null; save(); input.focus();
    });
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var q = function (n) { return f.querySelector('[name=' + n + ']'); };
      var name = q('cname').value.trim(), email = q('email').value.trim(), phone = q('phone').value.trim();
      var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
      var phoneOk = /^\+?\d{6,15}$/.test(phone.replace(/[\s.\-()/]/g, ''));
      if (emailReq && !emailOk) return showErr(L.errEmail), q('email').focus();
      if (!emailReq && !emailOk && !phoneOk) return showErr(L.errContact), q('email').focus();
      if (email && !emailOk) return showErr(L.errEmailFormat), q('email').focus();
      if (phone && !phoneOk) return showErr(L.errPhone), q('phone').focus();
      if (!q('privacy').checked) return showErr(L.errPrivacy), q('privacy').focus();
      showErr('');
      submitContact({ name: name, email: email, phone: phone, website: q('website').value, marketing: !!(q('mkt') && q('mkt').checked), reason: a.reason, version: a.version }, f);
    });
    log.appendChild(f);
    // Non spostare il cursore di chi sta già scrivendo nel modulo
    setTimeout(function () { if (!f.contains(shadow.activeElement)) f.querySelector('[name=cname]').focus(); }, 30);
  }

  function push(it) { S.items.push(it); save(); renderItem(it); scroll(); }

  function typing(on) {
    var t = log.querySelector('.typing');
    if (on && !t) { log.appendChild(el('div', { 'class': 'typing' }, '<span class="sr">' + esc(L.typing) + '</span><i aria-hidden="true"></i><i aria-hidden="true"></i><i aria-hidden="true"></i>')); scroll(); }
    if (!on && t) t.remove();
  }

  function setBusy(b) {
    busy = b;
    sendBtn.disabled = b || !input.value.trim() || S.done;
    input.disabled = S.done;
    input.placeholder = S.done ? L.sentPlaceholder : L.placeholder;
  }

  function applyResponse(n) {
    // L'avviso AI è già il primo elemento della chat: quello del server serve solo se manca
    var hasNotice = S.items.some(function (i) { return i.kind === 'notice'; });
    if (n.disclosure && !hasNotice) push({ kind: 'notice', text: n.disclosure, privacyUrl: cfg.privacyUrl });
    if (n.reply) push({ kind: 'bot', text: n.reply, sources: n.sources, emergency: n.emergency, products: n.products, total: n.total, answerId: n.answerId, rating: 0 });
    if (n.state) S.state = n.state;
    if (n.done) { S.done = true; S.pendingForm = null; }
    S.pendingOptions = null;
    if (n.action && n.action.type === 'ask_field' && n.action.options.length) { S.pendingOptions = n.action; renderOptions(n.action); }
    if (n.action && n.action.type === 'contact_form' && !S.done) { S.pendingForm = n.action; renderForm(n.action); }
    save(); scroll();
  }

  function failure(err, offerForm) {
    console.warn('[INFRAME]', err && err.message ? err.message : err);
    push({ kind: 'error', text: offerForm
      ? L.offline
      : L.sendFailed });
    // Degrado (spec. §12): se il servizio non risponde, il modulo di contatto resta disponibile
    if (offerForm && !S.done) {
      S.pendingForm = { type: 'contact_form', reason: 'handoff', version: cfg.consentVersion, emailRequired: cfg.mode === 'ecommerce' };
      renderForm(S.pendingForm); save(); scroll();
    }
  }

  // ---------------------------------------------------------------- azioni
  // P6.7: the chosen button is removed, so focus goes back to the text field (Esc and Tab keep working).
  function choose(text) { send(text); if (!S.done) input.focus(); }

  function send(text) {
    text = String(text || '').trim().slice(0, 1000);
    if (!text || busy || S.done) return;
    clearInteractive(); S.pendingOptions = null; S.pendingForm = null;
    push({ kind: 'me', text: text });
    input.value = ''; autosize(); setBusy(true); typing(true);
    var body = cfg.mode === 'servizi'
      ? pageContext({ type: 'message', site_key: cfg.siteKey, session_id: S.sessionId, message: text })
      : { site_key: cfg.siteKey, session_id: S.sessionId, message: text, advisor_profile: S.profile || {}, lead_data: {} };
    post(body).then(function (r) {
      typing(false);
      applyResponse(normalize(r));
    }).catch(function (e) { typing(false); failure(e, true); })
      .then(function () { setBusy(false); });
  }

  // P6.9: il voto non blocca la chat; vale l'ultimo, e resta segnato anche dopo il ricaricamento
  function rate(it, node, value) {
    var msg = node.querySelector('.rt-msg');
    var buttons = node.querySelectorAll('.rt');
    Array.prototype.forEach.call(buttons, function (b) { b.disabled = true; });
    post({ type: 'feedback', site_key: cfg.siteKey, session_id: S.sessionId, answer_id: it.answerId, rating: value }).then(function (r) {
      if (r.ok === false) throw new Error(r.status || 'feedback_failed');
      it.rating = value; save();
      Array.prototype.forEach.call(buttons, function (b) { b.setAttribute('aria-pressed', String(Number(b.getAttribute('data-rate')) === value)); });
      msg.textContent = L.thanks;
    }).catch(function (e) {
      console.warn('[INFRAME]', e && e.message);
      msg.textContent = L.rateFailed;
    }).then(function () { Array.prototype.forEach.call(buttons, function (b) { b.disabled = false; }); });
  }

  function submitContact(d, f) {
    if (busy) return;
    var btn = f.querySelector('.pri'); btn.disabled = true; btn.textContent = L.sending;
    setBusy(true);
    var version = d.version || cfg.consentVersion;
    var body = cfg.mode === 'servizi'
      ? pageContext({ type: 'submit_contact', site_key: cfg.siteKey, session_id: S.sessionId,
          lead_data: { contact_name: d.name, email: d.email, phone: d.phone, website: d.website || '', privacy_consent: true,
                       marketing_consent: d.marketing, consent_notice_version: version, reason: d.reason === 'handoff' ? 'handoff' : 'lead' } })
      : { site_key: cfg.siteKey, session_id: S.sessionId, advisor_profile: S.profile || {},
          message: d.reason === 'handoff' ? L.wantPerson : L.wantContact,
          lead_data: { first_name: d.name, email: d.email, phone: d.phone, privacy_consent: true, consent_notice_version: version } };
    post(body).then(function (r) {
      var n = normalize(r);
      if (!n.ok && !n.done) {
        btn.disabled = false; btn.textContent = L.submit;
        var fe = f.querySelector('.fe'); fe.textContent = n.reply || L.checkData; fe.hidden = false;
        return;
      }
      f.remove();
      if (cfg.mode === 'ecommerce' && !n.done) n.done = r.lead_captured === true || r.status === 'crm_ready';
      n.action = null;
      applyResponse(n);
    }).catch(function (e) {
      btn.disabled = false; btn.textContent = 'Riprova';
      var fe = f.querySelector('.fe');
      fe.innerHTML = L.serviceDown + fallbackHtml();
      fe.hidden = false;
      console.warn('[INFRAME]', e && e.message);
    }).then(function () { setBusy(false); });
  }

  function restore() {
    log.innerHTML = '';
    if (!S.items.length) S.items.push({ kind: 'notice', text: WELCOME, privacyUrl: cfg.privacyUrl });
    S.items.forEach(renderItem);
    if (S.items.length === 1 && !S.done) { renderClosed(); renderPaths(); renderSuggestions(); }
    if (S.pendingOptions) renderOptions(S.pendingOptions);
    if (S.pendingForm && !S.done) renderForm(S.pendingForm);
    save(); setBusy(false); scroll();
  }

  function open() {
    panel.hidden = false; launch.hidden = true; root.classList.add('open');
    launch.setAttribute('aria-expanded', 'true'); S.isOpen = true; save();
    scroll();
    if (!panel.querySelector('.form')) setTimeout(function () { input.focus(); }, 30);
  }
  function close() {
    panel.hidden = true; launch.hidden = false; root.classList.remove('open');
    launch.setAttribute('aria-expanded', 'false'); S.isOpen = false; save(); launch.focus();
  }
  function reset() { store.del(); S = fresh(); S.isOpen = true; restore(); input.focus(); }

  function autosize() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; }

  launch.addEventListener('click', open);
  panel.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-act]');
    if (!b) return;
    if (b.getAttribute('data-act') === 'close') close();
    if (b.getAttribute('data-act') === 'reset') reset();
  });
  panel.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  form.addEventListener('submit', function (e) { e.preventDefault(); send(input.value); });
  input.addEventListener('input', function () { autosize(); sendBtn.disabled = busy || !input.value.trim() || S.done; });
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(input.value); }
  });

  function mount() {
    document.body.appendChild(host);
    restore();
    if (S.isOpen || cfg.open) open();
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);

  window.INFRAME = { __loaded: true, open: open, close: close, toggle: function () { panel.hidden ? open() : close(); },
    reset: reset, send: function (t) { open(); send(t); }, config: cfg };
})();
