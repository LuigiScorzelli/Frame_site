(function () {
  'use strict';

  var cfg = window.INFRAME_PLUGIN_CONFIG;
  if (!cfg || !cfg.assetUrl || !cfg.endpoint || !cfg.siteKey) return;
  var loaded = false;
  var timer;
  var events = ['scroll', 'pointerdown', 'keydown'];

  function load() {
    if (loaded) return;
    loaded = true;
    clearTimeout(timer);
    events.forEach(function (event) { window.removeEventListener(event, load); });
    if (window.INFRAME && window.INFRAME.__loaded) return;

    var script = document.createElement('script');
    script.src = cfg.assetUrl;
    script.async = true;
    script.dataset.inframePlugin = 'true';
    var keys = ['endpoint', 'siteKey', 'mode', 'title', 'company', 'color', 'position',
      'welcome', 'privacyUrl', 'fallbackPhone', 'fallbackEmail', 'whatsapp', 'suggestions', 'launcherLabel', 'consentText', 'lang',
      'paths', 'hours', 'timezone', 'closedMessage', 'preview'];
    keys.forEach(function (key) { script.dataset[key] = cfg[key] || ''; });
    script.dataset.open = new URLSearchParams(window.location.search).get('inframe') === 'open' ? 'true' : 'false';
    document.body.appendChild(script);
  }

  events.forEach(function (event) { window.addEventListener(event, load, { passive: true }); });
  timer = window.setTimeout(load, 3000);
})();
