(function () {
  'use strict';
  // One script for every panel page (P6.16): each part starts only when its elements are on the page.
  var cfg = window.INFRAME_WORKSPACE;
  if (!cfg) return;
  var i18n = cfg.i18n || {};
  // Replaces %s and %1$s placeholders, in the same way as sprintf() in PHP.
  var format = function (template) {
    var args = Array.prototype.slice.call(arguments, 1);
    var next = 0;
    return String(template).replace(/%(?:(\d+)\$)?s/g, function (match, position) {
      var value = args[position ? position - 1 : next++];
      return value === undefined ? match : value;
    });
  };
  // Counted texts arrive from PHP as [one, other].
  var counted = function (key, count) {
    return format(i18n[key][count === 1 ? 0 : 1], count);
  };
  var page = document.querySelector('.inframe-admin');
  var progress = document.getElementById('inframe-progress');
  var scan = document.getElementById('inframe-scan');
  var generate = document.getElementById('inframe-generate');
  var generateProgress = document.getElementById('inframe-generate-progress');
  try {
    var scanResult = sessionStorage.getItem('inframe-scan-result');
    if (scanResult && progress) {
      progress.textContent = scanResult;
      sessionStorage.removeItem('inframe-scan-result');
    }
  } catch (error) { /* Discovery also works when browser storage is unavailable. */ }
  var review = document.getElementById('inframe-knowledge-review');
  if (review && window.location.hash === '#inframe-knowledge-review') {
    var showReview = function () {
      review.focus();
      review.scrollIntoView({ block: 'start' });
    };
    showReview();
    // Restored scroll positions can arrive after this script; show the draft again once the page is loaded.
    window.addEventListener('load', showReview, { once: true });
  }
  var provider = document.getElementById('inframe-provider');
  if (provider) {
    provider.addEventListener('change', function () {
      document.querySelectorAll('[data-inframe-provider]').forEach(function (row) {
        row.hidden = row.dataset.inframeProvider !== provider.value;
      });
    });
  }
  // P6.3: same calculation as inframe_model_estimate() in PHP, repeated while the owner types or picks a model.
  document.querySelectorAll('.inframe-model-info').forEach(function (info) {
    var input = document.getElementById(info.dataset.input);
    var prices = JSON.parse(info.dataset.prices || '{}');
    var rate = parseFloat(info.dataset.rate);
    var typicalIn = parseInt(info.dataset.typicalIn, 10);
    var typicalOut = parseInt(info.dataset.typicalOut, 10);
    var estimate = info.querySelector('[data-inframe-estimate]');
    var unpriced = info.querySelector('[data-inframe-unpriced]');
    var eur = function (n) {
      return n.toLocaleString(cfg.locale || 'it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
    };
    var priceOf = function (model) {
      if (prices[model]) {
        return prices[model];
      }
      var best = null;
      var length = 0;
      Object.keys(prices).forEach(function (name) {
        if (name.length > length && model.indexOf(name + '-') === 0) {
          best = prices[name];
          length = name.length;
        }
      });
      return best;
    };
    var render = function () {
      var model = input.value.trim();
      var price = model ? priceOf(model) : null;
      estimate.hidden = !price;
      unpriced.hidden = !model || !!price;
      if (price) {
        var perHundred = 100 * (typicalIn * price.in + typicalOut * price.out) / 1000000 * rate;
        estimate.textContent = format(i18n.estimate, model, eur(price.in * rate), eur(price.out * rate), eur(perHundred), typicalIn.toLocaleString(cfg.locale || 'it-IT'), typicalOut.toLocaleString(cfg.locale || 'it-IT'));
      }
    };
    input.addEventListener('input', render);
    info.querySelector('[data-inframe-use-model]').addEventListener('click', function () {
      input.value = info.dataset.economic;
      render();
      input.focus();
    });
  });
  var providerForm = document.getElementById('inframe-provider-form');
  if (providerForm) {
    var consent = providerForm.querySelector('[name="consent"]');
    var feedback = document.getElementById('inframe-provider-feedback');
    providerForm.addEventListener('submit', function (event) {
      if (event.submitter && event.submitter.name === 'test_provider' && !consent.checked) {
        event.preventDefault();
        feedback.textContent = i18n.consentRequired;
        feedback.hidden = false;
        consent.focus();
      }
    });
    consent.addEventListener('change', function () { feedback.hidden = true; });
  }

  function request(operation, values) {
    var body = new URLSearchParams(Object.assign({ action: 'inframe_knowledge', nonce: cfg.nonce, operation: operation }, values));
    return fetch(cfg.url, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (response) { return response.json(); })
      .then(function (response) {
        if (!response.success) {
          var error = new Error(response.data && response.data.message || i18n.requestFailed);
          error.code = response.data && response.data.code;
          throw error;
        }
        return response.data;
      });
  }

  // Long operations lock the page they run on, so no other form is submitted halfway.
  function run(work, status) {
    var controls = page ? Array.from(page.querySelectorAll('input, button, select, textarea')) : [];
    var states = controls.map(function (control) { return control.disabled; });
    controls.forEach(function (control) { control.disabled = true; });
    work().catch(function (error) {
      status.textContent = format(status === generateProgress ? i18n.runFailedDraft : i18n.runFailed, error.message);
      status.focus();
      status.scrollIntoView({ block: 'center' });
    }).finally(function () {
      controls.forEach(function (control, index) { control.disabled = states[index]; });
    });
  }

  var manager = document.getElementById('inframe-source-manager');
  var rows = Array.from(document.querySelectorAll('.inframe-source'));

  function sourceAnalysisResult(row, message) {
    if (!row) return;
    row.dataset.state = message ? 'error' : 'ready';
    row.querySelector('.inframe-source-status').textContent = message ? i18n.stateError : i18n.stateReady;
    row.querySelector('.inframe-source-error').textContent = message || '';
  }

  if (manager) {
    var search = document.getElementById('inframe-source-search');
    var kind = document.getElementById('inframe-source-kind');
    var inclusion = document.getElementById('inframe-source-inclusion');
    var state = document.getElementById('inframe-source-state');
    var pageSize = document.getElementById('inframe-source-size');
    var selectPage = document.getElementById('inframe-source-select-page');
    var selectMatching = document.getElementById('inframe-source-select-matching');
    var clearSelection = document.getElementById('inframe-source-clear');
    var sourcePage = 1;
    var matching = rows;
    var visibleRows = [];

    var updateSelection = function () {
      var selected = rows.filter(function (row) { return row.querySelector('.inframe-source-check').checked; });
      var hidden = selected.filter(function (row) { return row.hidden; }).length;
      document.getElementById('inframe-source-selection').textContent = hidden ? format(i18n.selectionHidden, selected.length, hidden) : format(i18n.selection, selected.length);
      var checked = visibleRows.filter(function (row) { return row.querySelector('.inframe-source-check').checked; }).length;
      selectPage.checked = visibleRows.length > 0 && checked === visibleRows.length;
      selectPage.indeterminate = checked > 0 && checked < visibleRows.length;
    };

    var filterSources = function (resetPage) {
      if (resetPage) sourcePage = 1;
      var query = search.value.toLocaleLowerCase().trim();
      matching = rows.filter(function (row) {
        return (!query || row.dataset.search.toLocaleLowerCase().includes(query)) &&
          (!kind.value || row.dataset.kind === kind.value) &&
          (!inclusion.value || row.dataset.enabled === inclusion.value) &&
          (!state.value || row.dataset.state === state.value);
      });
      var size = Number(pageSize.value);
      var pages = Math.max(1, Math.ceil(matching.length / size));
      sourcePage = Math.min(sourcePage, pages);
      visibleRows = matching.slice((sourcePage - 1) * size, sourcePage * size);
      rows.forEach(function (row) { row.hidden = !visibleRows.includes(row); });
      document.getElementById('inframe-source-empty').hidden = matching.length !== 0;
      document.getElementById('inframe-source-page').textContent = format(i18n.page[matching.length === 1 ? 0 : 1], sourcePage, pages, matching.length, rows.length);
      document.getElementById('inframe-source-prev').disabled = sourcePage === 1;
      document.getElementById('inframe-source-next').disabled = sourcePage === pages;
      selectMatching.textContent = format(i18n.selectMatching, matching.length);
      updateSelection();
    };

    manager.querySelector('.inframe-source-filters').hidden = false;
    manager.querySelector('.inframe-source-pagination').hidden = false;
    selectMatching.hidden = clearSelection.hidden = false;
    [search, kind, inclusion, state, pageSize].forEach(function (control) {
      control.addEventListener(control === search ? 'input' : 'change', function () { filterSources(true); });
    });
    document.getElementById('inframe-source-prev').addEventListener('click', function () { sourcePage--; filterSources(false); });
    document.getElementById('inframe-source-next').addEventListener('click', function () { sourcePage++; filterSources(false); });
    rows.forEach(function (row) { row.querySelector('.inframe-source-check').addEventListener('change', updateSelection); });
    selectPage.addEventListener('change', function () {
      visibleRows.forEach(function (row) { row.querySelector('.inframe-source-check').checked = selectPage.checked; });
      updateSelection();
    });
    selectMatching.addEventListener('click', function () {
      matching.forEach(function (row) { row.querySelector('.inframe-source-check').checked = true; });
      updateSelection();
    });
    clearSelection.addEventListener('click', function () {
      rows.forEach(function (row) { row.querySelector('.inframe-source-check').checked = false; });
      updateSelection();
    });
    document.getElementById('inframe-sources-form').addEventListener('submit', function (event) {
      var count = rows.filter(function (row) { return row.querySelector('.inframe-source-check').checked; }).length;
      var feedback = document.getElementById('inframe-source-feedback');
      feedback.hidden = true;
      if (!count || count > 1000) {
        event.preventDefault();
        feedback.textContent = i18n.selectionRange;
        feedback.hidden = false;
      } else if (this.elements.source_action.value === 'delete' && !window.confirm(counted('deleteSelectedConfirm', count))) {
        event.preventDefault();
      }
    });
    document.querySelectorAll('.inframe-source-delete').forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!window.confirm(i18n.deleteOneConfirm)) event.preventDefault();
      });
    });
    // "Seleziona le fonti da correggere" on the Documentation tab opens this list with the failed sources selected.
    if (new URLSearchParams(window.location.search).get('state') === 'error') {
      inclusion.value = '1';
      state.value = 'error';
      rows.forEach(function (row) { row.querySelector('.inframe-source-check').checked = row.dataset.enabled === '1' && row.dataset.state === 'error'; });
      document.querySelector('#inframe-sources-form [name="source_action"]').value = 'exclude';
      manager.focus();
    }
    // "Crea bozza di FAQ" (P6.5) lands here with ?source=<id>: show that source and open its text for editing.
    var focusSource = new URLSearchParams(window.location.search).get('source');
    var focusRow = focusSource && rows.filter(function (row) { return row.dataset.source === focusSource; })[0];
    if (focusRow) search.value = focusRow.dataset.title;
    filterSources(true);
    if (focusRow) {
      var edit = focusRow.querySelector('textarea[name="content"]');
      if (edit) {
        edit.closest('details').open = true;
        edit.focus();
      }
    }
  }

  var retrievalForm = document.getElementById('inframe-retrieval-form');
  if (retrievalForm) {
    var query = document.getElementById('inframe-retrieval-query');
    if (query.value) query.focus();
    retrievalForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var result = document.getElementById('inframe-retrieval-result');
      run(async function () {
        result.textContent = i18n.retrievalChecking;
        var data = await request('retrieval_test', { query: query.value, assisted: document.getElementById('inframe-retrieval-assisted').checked ? '1' : '' });
        var retrievalIssue = {
          selection_index_limit: i18n.retrievalIndexLimit,
          selection_index_empty: i18n.retrievalIndexEmpty,
          selection_failed: i18n.retrievalFailed,
          selection_budget: i18n.retrievalBudget
        }[data.retrieval_status];
        var found = data.titles.length ? format(data.overview ? i18n.foundOverview : i18n.foundSources, data.titles.join(' · ')) : '';
        result.textContent = format(i18n.retrievalResult, data.approved, data.greeting ? i18n.retrievalGreeting : (retrievalIssue ? retrievalIssue + (found ? ' ' + found : '') : (found || i18n.retrievalNone)));
        if (!data.greeting && data.passages && data.passages.length) {
          var list = document.createElement('ol');
          data.passages.forEach(function (passage) {
            var item = document.createElement('li');
            var details = document.createElement('details');
            var title = document.createElement('summary');
            var text = document.createElement('pre');
            title.textContent = passage.title;
            text.textContent = passage.text;
            text.style.whiteSpace = 'pre-wrap';
            details.appendChild(title);
            details.appendChild(text);
            item.appendChild(details);
            list.appendChild(item);
          });
          result.appendChild(list);
        }
      }, result);
    });
  }

  document.querySelectorAll('.inframe-discovery-search').forEach(function (input) {
    input.addEventListener('input', function () {
      var text = input.value.toLocaleLowerCase();
      input.closest('details').querySelectorAll('[data-discovery-title]').forEach(function (label) {
        label.hidden = !label.dataset.discoveryTitle.toLocaleLowerCase().includes(text);
      });
    });
  });
  var discoveryForm = document.getElementById('inframe-discovery-form');
  if (discoveryForm && scan) {
    discoveryForm.addEventListener('change', function (event) {
      if (event.target.type !== 'checkbox') return;
      scan.disabled = true;
      progress.textContent = i18n.selectionChanged;
    });
  }

  // P6.7: readable colours, the same calculation as the widget (`palette` in inframe-widget.js) and inframe_widget_palette().
  function palette(hex) {
    var h = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex).trim());
    h = h ? h[1] : '1f5fbf';
    if (h.length === 3) h = h.replace(/./g, '$&$&');
    var rgb = [0, 2, 4].map(function (i) { return parseInt(h.substr(i, 2), 16); });
    var lum = function (c) {
      var v = c.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
      return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
    };
    var ratio = function (a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
    var darker = function (c, against, min) {
      for (var t = 0; t < 1 && ratio(c, against) < min; t += 0.04) c = rgb.map(function (x) { return Math.round(x * (1 - t)); });
      return c;
    };
    var css = function (c) { return '#' + c.map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); };
    var white = [255, 255, 255], ink = [29, 35, 48];
    var surface = rgb, on = ratio(rgb, white) >= ratio(rgb, ink) ? white : ink;
    if (ratio(surface, on) < 4.6) { surface = darker(rgb, white, 4.6); on = white; }
    return { c: css(rgb), surface: css(surface), on: css(on), text: css(darker(rgb, [244, 246, 249], 4.6)) };
  }
  function colorNote(p) {
    var notes = [];
    if (p.on === '#1d2330') notes.push(i18n.colorOnDark);
    if (p.surface !== p.c) notes.push(i18n.colorSurface);
    if (p.text !== p.c) notes.push(i18n.colorText);
    return notes.length ? notes.join(' ') + ' ' + i18n.colorWhy : '';
  }

  // Aspetto › Widget: the preview follows the fields while the owner types.
  var preview = document.getElementById('inframe-preview');
  if (preview) {
    var out = function (key) { return preview.querySelector('[data-inframe-out="' + key + '"]'); };
    var live = function (key) {
      var field = document.getElementById('inframe-' + key);
      if (!field) return;
      var update = function () {
        var value = field.value.trim();
        if (key === 'color') {
          if (/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.test(value)) {
            var p = palette(value);
            preview.style.setProperty('--inframe-color', p.surface);
            preview.style.setProperty('--inframe-on', p.on);
            preview.style.setProperty('--inframe-text', p.text);
            var note = document.getElementById('inframe-color-note');
            if (note) note.textContent = colorNote(p);
          }
        } else if (key === 'position') {
          preview.dataset.position = value;
        } else if (key === 'suggestions') {
          var chips = out('suggestions');
          chips.textContent = '';
          value.split(/[\r\n|]+/).map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 8).forEach(function (text) {
            var chip = document.createElement('span');
            chip.textContent = text;
            chips.appendChild(chip);
          });
        } else {
          out(key).textContent = value || out(key).dataset.default;
        }
      };
      field.addEventListener(field.tagName === 'SELECT' ? 'change' : 'input', update);
    };
    ['title', 'color', 'position', 'welcome', 'suggestions', 'launcher_label'].forEach(live);
  }

  var inSetup = new URLSearchParams(window.location.search).get('page') === 'inframe-setup';

  if (scan) {
    scan.addEventListener('click', function () {
      run(async function () {
        var pageNumber = 1;
        var count = 0;
        var warnings = [];
        var result;
        do {
          progress.textContent = counted('scanProgress', count);
          result = await request('scan', { page: pageNumber++ });
          count += result.imported;
          warnings = warnings.concat(result.skipped);
        } while (!result.done);
        var message = counted('scanDone', count) + (warnings.length ? ' ' + format(i18n.scanSkipped, warnings.join(' | ')) : '');
        try { sessionStorage.setItem('inframe-scan-result', message); } catch (error) { /* The refreshed source list is still available. */ }
        if (inSetup) {
          window.location.reload();
        } else {
          window.location.href = cfg.sourcesUrl + '#inframe-source-manager';
        }
      }, progress);
    });
  }

  if (generate) {
    var selectErrors = document.getElementById('inframe-select-errors');
    generate.addEventListener('click', function () {
      run(async function () {
        // The source list comes from PHP: the source table is on another tab.
        var sources = JSON.parse(generate.dataset.inframeSources || '[]');
        if (!sources.length) throw new Error(i18n.noSources);
        var failures = [];
        for (var i = 0; i < sources.length; i++) {
          var title = sources[i].title;
          var row = document.querySelector('.inframe-source[data-source="' + sources[i].id + '"]');
          generateProgress.textContent = format(i18n.analysisProgress, i + 1, sources.length, title, failures.length);
          try {
            var analysis = await request('analyze', { source_id: sources[i].id });
            if (analysis.skipped) {
              failures.push({ title: title, message: analysis.message });
              sourceAnalysisResult(row, analysis.message);
            } else {
              sourceAnalysisResult(row, '');
            }
          } catch (error) {
            sourceAnalysisResult(row, error.message);
            if (selectErrors) selectErrors.hidden = false;
            throw new Error(format(i18n.analysisStopped, title, error.message));
          }
        }
        generateProgress.textContent = i18n.analysisDone;
        await request('build', {});
        // Without this the browser restores the old scroll position and hides the new draft.
        if ('scrollRestoration' in history) {
          history.scrollRestoration = 'manual';
        }
        window.location.hash = 'inframe-knowledge-review';
        window.location.reload();
      }, generateProgress);
    });
  }
})();
