(function (blocks, element, components) {
  'use strict';
  blocks.registerBlockType('inframe/chat', {
    edit: function () {
      return element.createElement(components.Placeholder, {
        icon: 'format-chat',
        label: 'inFrame',
        instructions: 'Il widget chat apparirà su questa pagina. Configuralo nel menu inFrame › Aspetto.'
      });
    },
    save: function () { return null; }
  });
})(window.wp.blocks, window.wp.element, window.wp.components);
