<?php
/** Server-side provider credentials and bounded API requests for the standalone beta. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_ai_settings() {
	return wp_parse_args(
		get_option( 'inframe_ai_settings', array() ),
		array(
			'provider'        => 'openai',
			'openai_model'    => inframe_economic_models()['openai'],
			'anthropic_model' => inframe_economic_models()['anthropic'],
			'workspace'       => '',
			'consent'         => false,
			'daily_limit'     => 100,
			'monthly_cap'     => 20,
			'usd_eur'         => 0.89,
			'prices'          => inframe_default_prices(),
		)
	);
}

function inframe_encrypt_secret( $plain ) {
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return new WP_Error( 'crypto_missing', __( 'This hosting must enable OpenSSL to store the API key.', 'inframe' ) );
	}
	$iv     = random_bytes( 12 );
	$tag    = '';
	$cipher = openssl_encrypt( $plain, 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, $iv, $tag );
	return false === $cipher ? new WP_Error( 'crypto_failed', __( 'The API key could not be stored.', 'inframe' ) ) : base64_encode( $iv . $tag . $cipher );
}

function inframe_ai_key_constant( $provider ) {
	return 'openai' === $provider ? 'INFRAME_OPENAI_API_KEY' : 'INFRAME_ANTHROPIC_API_KEY';
}

/** A key defined in wp-config.php wins over the panel: say so, never show it. */
function inframe_ai_key_notice( $provider ) {
	$constant = inframe_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		/* translators: %s: name of the wp-config.php constant that holds the key. */
		return sprintf( __( 'The key defined in wp-config.php (%s) is in use: it overrides the one entered here. To use the panel key, remove the constant from wp-config.php.', 'inframe' ), $constant );
	}
	return inframe_ai_key( $provider ) ? __( 'Key already saved. Leave empty to keep it.', 'inframe' ) : __( 'Key not entered yet.', 'inframe' );
}

function inframe_ai_key( $provider ) {
	$constant = inframe_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		return (string) constant( $constant );
	}
	$vault = get_option( 'inframe_ai_credentials', array() );
	$raw   = base64_decode( $vault[ $provider ] ?? '', true );
	if ( ! $raw || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}
	return openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) ) ?: '';
}

function inframe_ai_save( $input ) {
	$old = inframe_ai_settings();
	// Provider and limits are saved from different tabs: a field missing from the form keeps its value.
	$provider             = $input['provider'] ?? $old['provider'];
	$settings             = $old;
	$settings['provider'] = in_array( $provider, array( 'openai', 'anthropic' ), true ) ? $provider : 'openai';
	if ( isset( $input['consent'] ) || ! empty( $input['_consent_field'] ) ) {
		$settings['consent'] = ! empty( $input['consent'] );
	}
	$settings['daily_limit'] = max( 1, min( 1000, (int) ( $input['daily_limit'] ?? $old['daily_limit'] ) ) );
	$costs                   = inframe_cost_settings_input( $input );
	if ( is_wp_error( $costs ) ) {
		return $costs;
	}
	$settings              = array_merge( $settings, $costs );
	$settings['workspace'] = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $input['workspace'] ?? $old['workspace'] ) );
	foreach ( array( 'openai_model', 'anthropic_model' ) as $field ) {
		$settings[ $field ] = preg_replace( '/[^A-Za-z0-9._:-]/', '', (string) ( $input[ $field ] ?? $old[ $field ] ) );
		if ( ! $settings[ $field ] ) {
			return new WP_Error( 'model_missing', __( 'Enter the model name for both providers.', 'inframe' ) );
		}
	}
	$vault = get_option( 'inframe_ai_credentials', array() );
	foreach ( array( 'openai', 'anthropic' ) as $name ) {
		if ( ! empty( $input[ 'remove_' . $name ] ) ) {
			unset( $vault[ $name ] );
		}
		$key = trim( (string) ( $input[ $name . '_key' ] ?? '' ) );
		if ( $key ) {
			if ( strlen( $key ) > 512 || preg_match( '/\s/', $key ) ) {
				return new WP_Error( 'key_invalid', __( 'The API key contains invalid characters.', 'inframe' ) );
			}
			$encrypted = inframe_encrypt_secret( $key );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$vault[ $name ] = $encrypted;
		}
	}
	update_option( 'inframe_ai_credentials', $vault, false );
	update_option( 'inframe_ai_settings', $settings, false );
	return true;
}

/** Atomic counters bound public inference spending and flood attempts across PHP workers. */
function inframe_take_quota( $bucket, $limit, $window ) {
	global $wpdb;
	$period = (int) floor( time() / $window );
	$key    = hash( 'sha256', $bucket . ':' . $period );
	$table  = $wpdb->prefix . 'inframe_counters';
	$ok     = $wpdb->query(
		$wpdb->prepare(
			'INSERT INTO %i (bucket, hits, expires) VALUES (%s, 1, %d) ON DUPLICATE KEY UPDATE hits = hits + 1',
			$table,
			$key,
			( $period + 1 ) * $window
		)
	);
	return false !== $ok && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT hits FROM %i WHERE bucket = %s', $table, $key ) ) <= $limit;
}

/** Absolute time (microtime) by which every AI call must finish; 0 means no limit. Set by the public chat. */
function inframe_ai_deadline( $at = null ) {
	static $deadline = 0;
	if ( null !== $at ) {
		$deadline = (float) $at;
	}
	return $deadline;
}

/** True while the public chat is answering: its calls use the share of the daily limit the panel cannot take. */
function inframe_ai_for_chat( $on = null ) {
	static $chat = false;
	if ( null !== $on ) {
		$chat = (bool) $on;
	}
	return $chat;
}

function inframe_ai_request( $system, $message, $max_tokens = 1200, $pdf = null, $timeout = 25 ) {
	$s   = inframe_ai_settings();
	$key = inframe_ai_key( $s['provider'] );
	if ( ! $s['consent'] ) {
		return new WP_Error( 'ai_consent_missing', __( 'Before the test, tick the box “I authorize sending to the selected provider…” and press “Save and test the AI connection”.', 'inframe' ) );
	}
	if ( ! $key ) {
		$label = 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic';
		$vault = get_option( 'inframe_ai_credentials', array() );
		if ( ! empty( $vault[ $s['provider'] ] ) ) {
			/* translators: %s: AI provider name (OpenAI or Anthropic). */
			return new WP_Error( 'ai_key_unreadable', sprintf( __( 'The API key saved for %s cannot be read. Enter it again and press “Save and test the AI connection”.', 'inframe' ), $label ) );
		}
		/* translators: %s: AI provider name (OpenAI or Anthropic). */
		return new WP_Error( 'ai_key_missing', sprintf( __( 'No API key is saved for %s. Enter it in the field of the selected provider and press “Save and test the AI connection”.', 'inframe' ), $label ) );
	}
	$deadline = inframe_ai_deadline();
	if ( $deadline ) {
		$left = (int) floor( $deadline - microtime( true ) );
		if ( $left < 2 ) {
			return new WP_Error( 'ai_budget', __( 'Maximum answer time reached.', 'inframe' ) );
		}
		$timeout = min( $timeout, $left );
	}
	// One daily limit; calls outside the public chat may use 70% of it, so the panel never leaves the chat without answers.
	$panel_limit = max( 1, (int) floor( $s['daily_limit'] * 0.7 ) );
	if ( ! inframe_ai_for_chat() && ! inframe_take_quota( 'ai-admin', $panel_limit, DAY_IN_SECONDS ) ) {
		/* translators: 1: AI requests the panel may use per day, 2: daily limit of AI requests of the site. */
		return new WP_Error( 'ai_admin_limit', sprintf( __( 'Today the panel used its %1$s AI requests out of %2$s: the rest is reserved for the chat. Try again tomorrow or raise "AI requests per day".', 'inframe' ), number_format_i18n( $panel_limit ), number_format_i18n( $s['daily_limit'] ) ) );
	}
	if ( ! inframe_take_quota( 'ai-site', $s['daily_limit'], DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ai_daily_limit', __( 'The site daily limit of AI requests is reached.', 'inframe' ) );
	}
	if ( 'openai' === $s['provider'] ) {
		$content = array(
			array(
				'type' => 'input_text',
				'text' => $message,
			),
		);
		if ( $pdf ) {
			array_unshift(
				$content,
				array(
					'type'      => 'input_file',
					'filename'  => 'document.pdf',
					'file_data' => 'data:application/pdf;base64,' . base64_encode( $pdf ),
				)
			);
		}
		$url     = 'https://api.openai.com/v1/responses';
		$headers = array( 'Authorization' => 'Bearer ' . $key );
		$body    = array(
			'model'             => $s['openai_model'],
			'instructions'      => $system,
			'input'             => array(
				array(
					'role'    => 'user',
					'content' => $content,
				),
			),
			'store'             => false,
			'max_output_tokens' => $max_tokens,
		);
	} else {
		$content = array(
			array(
				'type' => 'text',
				'text' => $message,
			),
		);
		if ( $pdf ) {
			array_unshift(
				$content,
				array(
					'type'   => 'document',
					'source' => array(
						'type'       => 'base64',
						'media_type' => 'application/pdf',
						'data'       => base64_encode( $pdf ),
					),
				)
			);
		}
		$url     = 'https://api.anthropic.com/v1/messages';
		$headers = array(
			'x-api-key'         => $key,
			'anthropic-version' => '2023-06-01',
		);
		if ( $s['workspace'] ) {
			$headers['anthropic-workspace-id'] = $s['workspace'];
		}
		$body = array(
			'model'      => $s['anthropic_model'],
			'system'     => $system,
			'messages'   => array(
				array(
					'role'    => 'user',
					'content' => $content,
				),
			),
			'max_tokens' => $max_tokens,
		);
	}
	$headers['Content-Type'] = 'application/json';
	$seconds                 = max( 1, min( 25, (int) $timeout ) );
	$response                = wp_remote_post(
		$url,
		array(
			'headers'             => $headers,
			'body'                => wp_json_encode( $body ),
			'timeout'             => $seconds,
			'redirection'         => 0,
			'limit_response_size' => 600000,
		)
	);
	// Never return provider response bodies: they may contain secrets or sensitive input.
	if ( is_wp_error( $response ) ) {
		// A slow answer is not a connection problem: cURL error 28 and the streams transport both say "timed out".
		if ( preg_match( '/cURL error 28|timed out/i', $response->get_error_message() ) ) {
			/* translators: %s: number of seconds. */
			return new WP_Error( 'ai_timeout', sprintf( __( 'The provider did not complete the answer within %s seconds. Try again; if it happens again, reduce the text to process.', 'inframe' ), number_format_i18n( $seconds ) ) );
		}
		return new WP_Error( 'ai_network', __( 'The provider does not respond. Check the connection and try again.', 'inframe' ) );
	}
	$code = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		$constant = inframe_ai_key_constant( $s['provider'] );
		/* translators: %s: name of the wp-config.php constant that holds the key. */
		$constant_invalid = __( 'Invalid API key. It is the key defined in wp-config.php (%s), which overrides the panel key.', 'inframe' );
		/* translators: %s: AI provider name (OpenAI or Anthropic). */
		$model_missing = __( 'Model not found: check the model name for %s.', 'inframe' );
		$messages      = array(
			401 => defined( $constant ) ? sprintf( $constant_invalid, $constant ) : __( 'Invalid API key.', 'inframe' ),
			403 => __( 'The account has no access to the model or the workspace.', 'inframe' ),
			404 => sprintf( $model_missing, 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic' ),
			429 => __( 'Provider quota or limit reached.', 'inframe' ),
		);
		return new WP_Error( 'ai_http', $messages[ $code ] ?? __( 'AI request failed. Check the model, the credit and the file compatibility.', 'inframe' ), array( 'http_status' => $code ) );
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	// Every accepted call is billed, even when the answer is then rejected as incomplete (P6.2).
	inframe_usage_record( $s['provider'], $body['model'], $data['usage'] ?? null );
	$text = '';
	if ( 'openai' === $s['provider'] ) {
		if ( 'completed' !== ( $data['status'] ?? '' ) ) {
			return new WP_Error( 'ai_incomplete', __( 'Incomplete AI answer. Reduce the source or use a compatible model.', 'inframe' ) );
		}
		foreach ( $data['output'] ?? array() as $item ) {
			foreach ( $item['content'] ?? array() as $part ) {
				if ( 'output_text' === ( $part['type'] ?? '' ) ) {
					$text .= $part['text'];
				}
			}
		}
	} else {
		if ( ! in_array( $data['stop_reason'] ?? '', array( 'end_turn', 'stop_sequence' ), true ) ) {
			return new WP_Error( 'ai_incomplete', __( 'Incomplete AI answer. Reduce the source or use a compatible model.', 'inframe' ) );
		}
		foreach ( $data['content'] ?? array() as $part ) {
			if ( 'text' === ( $part['type'] ?? '' ) ) {
				$text .= $part['text'];
			}
		}
	}
	return trim( $text ) ?: new WP_Error( 'ai_empty', __( 'The provider returned no usable text.', 'inframe' ) );
}

/** The connection check must use the fields the customer has just submitted. */
function inframe_ai_save_and_test( $input ) {
	$saved = inframe_ai_save( $input );
	return is_wp_error( $saved ) ? $saved : inframe_ai_connection_test();
}

/** An accepted request proves key, model and quota: a reasoning model may spend the small budget thinking and return no text. */
function inframe_ai_connection_test() {
	$result = inframe_ai_request( 'Rispondi solo OK.', 'Prova del collegamento.', 50 );
	return is_wp_error( $result ) && in_array( $result->get_error_code(), array( 'ai_incomplete', 'ai_empty' ), true ) ? 'OK' : $result;
}

function inframe_ai_json( $text ) {
	$text = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', trim( $text ) );
	$data = json_decode( $text, true );
	return is_array( $data ) ? $data : new WP_Error( 'ai_json', __( 'Invalid AI answer. The previous draft is kept; try again.', 'inframe' ) );
}

/* ---------- Costi (P6.2) ---------- */

/** List prices in USD per million tokens, checked on the providers' pages on 11/11/2026. A key also prices the dated versions it prefixes. */
function inframe_default_prices() {
	return array(
		'gpt-4.1-mini'     => array(
			'in'  => 0.4,
			'out' => 1.6,
		),
		'claude-haiku-4-5' => array(
			'in'  => 1.0,
			'out' => 5.0,
		),
	);
}

/** Cheapest model of each provider (P6.3): the default of a first configuration and the panel's recommendation. */
function inframe_economic_models() {
	return array(
		'openai'    => 'gpt-4.1-mini',
		'anthropic' => 'claude-haiku-4-5-20251001',
	);
}

/**
 * Typical chat question for the cost estimate (P6.3), an assumption to be checked on real sites.
 * Measured in CI on 16/11: about 730 input tokens per answer with the short test sources; the code allows
 * up to about 5500 (6 passages of 1600 characters, a 6000-character agent prompt, 12 messages of history).
 */
function inframe_typical_question() {
	return array(
		'in'  => 3000,
		'out' => 300,
	);
}

/** Euro per million tokens and per 100 typical questions with a model; null when the price list has no price for it. */
function inframe_model_estimate( $model, $settings = null ) {
	$s     = $settings ?? inframe_ai_settings();
	$price = inframe_model_price( (string) $model, $s['prices'] ?: inframe_default_prices() );
	if ( null === $price ) {
		return null;
	}
	$rate = (float) $s['usd_eur'];
	$q    = inframe_typical_question();
	return array(
		'in'     => $price['in'] * $rate,
		'out'    => $price['out'] * $rate,
		'per100' => 100 * ( $q['in'] * $price['in'] + $q['out'] * $price['out'] ) / 1000000 * $rate,
	);
}

/** Provider of a price list entry, for the model suggestions: Anthropic model names start with "claude". */
function inframe_price_provider( $model ) {
	return 0 === strpos( (string) $model, 'claude' ) ? 'anthropic' : 'openai';
}

/** A number typed in the panel, with comma or dot decimals; null when it is not a number. */
function inframe_cost_number( $value ) {
	$value = str_replace( ',', '.', trim( (string) $value ) );
	return is_numeric( $value ) ? (float) $value : null;
}

/** Validate the cost fields of the Limits tab. Returns the fields to merge or a WP_Error; absent fields keep their value. */
function inframe_cost_settings_input( $input ) {
	$out = array();
	if ( isset( $input['monthly_cap'] ) ) {
		$cap = inframe_cost_number( $input['monthly_cap'] );
		if ( null === $cap || $cap < 0 || $cap > 10000 ) {
			return new WP_Error( 'cap_invalid', __( 'The monthly spending cap must be an amount between 0 and 10,000 euros (0 = no cap).', 'inframe' ) );
		}
		$out['monthly_cap'] = $cap;
	}
	if ( isset( $input['usd_eur'] ) ) {
		$rate = inframe_cost_number( $input['usd_eur'] );
		if ( null === $rate || $rate < 0.01 || $rate > 10 ) {
			return new WP_Error( 'rate_invalid', __( 'The exchange rate must say how many euros one dollar is worth, for example 0.89.', 'inframe' ) );
		}
		$out['usd_eur'] = $rate;
	}
	if ( ! empty( $input['_prices_field'] ) ) {
		$prices = array();
		foreach ( array_slice( (array) ( $input['prices'] ?? array() ), 0, 20 ) as $row ) {
			$model = preg_replace( '/[^A-Za-z0-9._:-]/', '', (string) ( $row['model'] ?? '' ) );
			if ( '' === $model && '' === trim( (string) ( $row['in'] ?? '' ) ) && '' === trim( (string) ( $row['out'] ?? '' ) ) ) {
				continue;
			}
			$in   = inframe_cost_number( $row['in'] ?? '' );
			$cost = inframe_cost_number( $row['out'] ?? '' );
			if ( '' === $model || null === $in || null === $cost || $in < 0 || $cost < 0 || $in > 1000 || $cost > 1000 ) {
				return new WP_Error( 'price_invalid', __( 'Each price list row needs the model name and two prices in dollars between 0 and 1000 per million tokens.', 'inframe' ) );
			}
			$prices[ $model ] = array(
				'in'  => $in,
				'out' => $cost,
			);
		}
		$out['prices'] = $prices;
	}
	return $out;
}

/** Price of a model: the exact name, else the longest listed name it starts with (dated versions); null when unlisted. */
function inframe_model_price( $model, $prices ) {
	if ( isset( $prices[ $model ] ) ) {
		return $prices[ $model ];
	}
	$best = null;
	$len  = 0;
	foreach ( $prices as $name => $price ) {
		if ( strlen( $name ) > $len && 0 === strpos( $model, $name . '-' ) ) {
			$best = $price;
			$len  = strlen( $name );
		}
	}
	return $best;
}

/** Record the tokens of one provider call: never questions, passages or answers. */
function inframe_usage_record( $provider, $model, $usage ) {
	global $wpdb;
	if ( ! is_array( $usage ) ) {
		return;
	}
	$input = (int) ( $usage['input_tokens'] ?? 0 );
	if ( 'anthropic' === $provider ) {
		// Anthropic reports cache writes and reads apart from input_tokens.
		$input += (int) ( $usage['cache_creation_input_tokens'] ?? 0 ) + (int) ( $usage['cache_read_input_tokens'] ?? 0 );
	}
	$chat = inframe_ai_for_chat();
	$wpdb->insert(
		$wpdb->prefix . 'inframe_usage',
		array(
			'created_at'    => current_time( 'mysql', true ),
			'scope'         => $chat ? 'chat' : 'panel',
			'conversation'  => $chat ? inframe_ai_conversation() : '',
			'provider'      => $provider,
			'model'         => substr( (string) $model, 0, 100 ),
			'input_tokens'  => max( 0, $input ),
			'output_tokens' => max( 0, (int) ( $usage['output_tokens'] ?? 0 ) ),
		)
	);
}

/** Pseudonymous conversation of the chat call in progress (hash of the session key); empty outside the chat. */
function inframe_ai_conversation( $hash = null ) {
	static $conversation = '';
	if ( null !== $hash ) {
		$conversation = (string) $hash;
	}
	return $conversation;
}

/** First instant of the current calendar month in the site time zone, as a UTC MySQL datetime. */
function inframe_month_start_utc() {
	$start = new DateTimeImmutable( 'first day of this month midnight', wp_timezone() );
	return $start->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
}

/**
 * Estimated cost of the month in euro, computed from the tokens with the current price list.
 * A model missing from the list is priced at the highest list prices and reported.
 */
function inframe_usage_summary() {
	global $wpdb;
	$s      = inframe_ai_settings();
	$prices = $s['prices'] ?: inframe_default_prices();
	$top    = array(
		'in'  => max( array_column( $prices, 'in' ) ),
		'out' => max( array_column( $prices, 'out' ) ),
	);
	$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT scope, conversation, model, SUM(input_tokens) AS input_tokens, SUM(output_tokens) AS output_tokens, COUNT(*) AS calls FROM %i WHERE created_at >= %s GROUP BY scope, conversation, model', $wpdb->prefix . 'inframe_usage', inframe_month_start_utc() ), ARRAY_A );
	$out    = array(
		'total'            => 0.0,
		'chat'             => 0.0,
		'panel'            => 0.0,
		'calls'            => 0,
		'conversations'    => 0,
		'conversation_avg' => 0.0,
		'conversation_max' => 0.0,
		'missing'          => array(),
		'cap'              => (float) $s['monthly_cap'],
	);
	$per    = array();
	foreach ( $rows ?: array() as $row ) {
		$price = inframe_model_price( $row['model'], $prices );
		if ( null === $price ) {
			$price            = $top;
			$out['missing'][] = $row['model'];
		}
		$eur            = ( $row['input_tokens'] * $price['in'] + $row['output_tokens'] * $price['out'] ) / 1000000 * (float) $s['usd_eur'];
		$scope          = 'chat' === $row['scope'] ? 'chat' : 'panel';
		$out[ $scope ] += $eur;
		$out['calls']  += (int) $row['calls'];
		if ( 'chat' === $scope && '' !== $row['conversation'] ) {
			$per[ $row['conversation'] ] = ( $per[ $row['conversation'] ] ?? 0 ) + $eur;
		}
	}
	$out['total']            = $out['chat'] + $out['panel'];
	$out['missing']          = array_values( array_unique( $out['missing'] ) );
	$out['conversations']    = count( $per );
	$out['conversation_avg'] = $per ? array_sum( $per ) / count( $per ) : 0.0;
	$out['conversation_max'] = $per ? max( $per ) : 0.0;
	return $out;
}

/** True when a monthly cap is set and the month estimate has reached it. */
function inframe_cost_cap_reached( $summary = null ) {
	$summary = $summary ?? inframe_usage_summary();
	return $summary['cap'] > 0 && $summary['total'] >= $summary['cap'];
}

function inframe_format_eur( $amount, $decimals = 2 ) {
	// The separators follow the panel language (P6.8): "1.234,50 €" in Italian, "1,234.50 €" in English. They come
	// from the plugin translation, not from WordPress core, so they are right even without the core language pack.
	return number_format( (float) $amount, $decimals, _x( '.', 'decimal separator of euro amounts', 'inframe' ), _x( ',', 'thousands separator of euro amounts', 'inframe' ) ) . ' €';
}

/** A stored amount as the panel shows it in a field: decimal separator of the panel language, no trailing zeros. */
function inframe_cost_input_value( $value ) {
	if ( '' === $value ) {
		return '';
	}
	return str_replace( '.', _x( '.', 'decimal separator of euro amounts', 'inframe' ), rtrim( rtrim( number_format( (float) $value, 6, '.', '' ), '0' ), '.' ) );
}
