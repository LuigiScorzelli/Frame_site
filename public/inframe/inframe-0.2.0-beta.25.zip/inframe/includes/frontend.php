<?php
/** Front-end visibility, shortcode/block, and lazy widget loading. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function inframe_shortcode() {
	$GLOBALS['inframe_manual_requested'] = true;
	return '<span class="inframe-chat-anchor" hidden aria-hidden="true"></span>';
}

function inframe_register_block() {
	wp_register_script(
		'inframe-block-editor',
		plugins_url( 'block/editor.js', INFRAME_PLUGIN_FILE ),
		array( 'wp-blocks', 'wp-element', 'wp-components' ),
		INFRAME_VERSION,
		true
	);
	register_block_type( __DIR__ . '/../block', array( 'render_callback' => 'inframe_shortcode' ) );
}

/** "Solo test": only administrators or whoever has the preview link. "Pubblico" does not call this check. */
function inframe_preview_allowed() {
	if ( current_user_can( 'manage_options' ) ) {
		return true;
	}
	// Il token di anteprima è solo in lettura e viene confrontato in modo costante; non modifica dati.
	$token = get_option( 'inframe_preview_token', '' );
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only token compared with hash_equals(), no state change.
	$given = isset( $_GET['inframe_preview'] ) && is_string( $_GET['inframe_preview'] )
		? sanitize_text_field( wp_unslash( $_GET['inframe_preview'] ) )
		: '';
	// phpcs:enable
	return is_string( $token ) && '' !== $token && '' !== $given && hash_equals( $token, $given );
}

function inframe_manual_on_page() {
	if ( ! empty( $GLOBALS['inframe_manual_requested'] ) ) {
		return true;
	}
	$post = get_queried_object();
	return $post instanceof WP_Post &&
		( has_shortcode( $post->post_content, 'inframe_chat' ) || has_block( 'inframe/chat', $post ) );
}

function inframe_visibility_matches( $settings ) {
	if ( 'all' === $settings['visibility'] ) {
		return true;
	}
	$id       = is_page() ? get_queried_object_id() : 0;
	$selected = $id && in_array( (int) $id, array_map( 'intval', $settings['page_ids'] ), true );
	if ( 'include' === $settings['visibility'] ) {
		return $selected;
	}
	return ! $selected;
}

/** Shared by the customer panel and the frontend so hidden chat has an explanation. */
function inframe_frontend_setup_issues( $s ) {
	$issues = array();
	$ai     = inframe_ai_settings();
	if ( ! $ai['consent'] ) {
		$issues['consent'] = __( 'In Settings › AI provider, authorize sending data to the provider and save the connection.', 'inframe' );
	}
	if ( ! inframe_ai_key( $ai['provider'] ) ) {
		$issues['key'] = __( 'In Settings › AI provider, enter and save a readable API key for the selected provider.', 'inframe' );
	}
	$published = get_option( 'inframe_kb_published', array() );
	if ( ! inframe_current_sources( $published ) ) {
		$issues['knowledge'] = empty( $published['sources'] )
			? __( 'In Sources and documentation, scan the site or add a document, rebuild the documentation and approve it. The AI connection alone does not turn on the chat.', 'inframe' )
			: __( 'The approved sources can no longer be used. Repeat the scan, rebuild and approval in Sources and documentation.', 'inframe' );
	}
	if ( 'live' === $s['display_mode'] && ! ( $s['privacy_url'] ?: get_privacy_policy_url() ) ) {
		$issues['privacy'] = __( 'In Settings › Privacy and retention, enter the link to the privacy policy, or set the privacy page in WordPress.', 'inframe' );
	}
	return $issues;
}

function inframe_enqueue_frontend() {
	if ( is_admin() || is_feed() ) {
		return;
	}
	$s = inframe_get_settings();
	if ( 'off' === $s['display_mode'] ) {
		return;
	}
	if ( inframe_frontend_setup_issues( $s ) ) {
		return;
	}
	$endpoint = rest_url( 'inframe/v1/chat' );
	if ( 'test' === $s['display_mode'] && inframe_preview_allowed() ) {
		$endpoint = add_query_arg( 'inframe_preview', get_option( 'inframe_preview_token' ), $endpoint );
	}
	if ( 'test' === $s['display_mode'] && ! inframe_preview_allowed() ) {
		return;
	}
	if ( ! inframe_manual_on_page() && ! inframe_visibility_matches( $s ) ) {
		return;
	}
	$privacy_url = $s['privacy_url'] ?: get_privacy_policy_url();

	$widget_file = __DIR__ . '/../assets/inframe-widget.js';
	$loader_file = __DIR__ . '/../assets/inframe-loader.js';
	$config      = array(
		'assetUrl'      => plugins_url( 'assets/inframe-widget.js', INFRAME_PLUGIN_FILE ) . '?ver=' . (string) filemtime( $widget_file ),
		'endpoint'      => $endpoint,
		'siteKey'       => inframe_local_site_key(),
		'mode'          => $s['workflow_mode'],
		'lang'          => inframe_widget_lang(),
		'title'         => $s['title'],
		'company'       => $s['company'],
		'color'         => $s['color'],
		'position'      => $s['position'],
		'welcome'       => $s['welcome'],
		'privacyUrl'    => $privacy_url,
		'fallbackPhone' => $s['fallback_phone'],
		'fallbackEmail' => $s['fallback_email'],
		'whatsapp'      => $s['whatsapp'],
		'suggestions'   => $s['suggestions'],
		'launcherLabel' => $s['launcher_label'],
		'consentText'   => inframe_consent_text(),
	);
	// P6.17: welcome and questions of the page or category rule, guided paths, opening hours in the site time zone.
	$rule = inframe_page_rule_for_request( $s['page_rules'] );
	if ( $rule ) {
		$config['welcome']     = $rule['welcome'] ?: $config['welcome'];
		$config['suggestions'] = $rule['suggestions'] ?: $config['suggestions'];
	}
	$config['paths']         = $s['show_paths'] ? ( $s['paths'] ?: implode( '|', inframe_default_paths( $s['workflow_mode'] ) ) ) : '';
	$config['hours']         = array_filter( $s['hours'] ) ? wp_json_encode( $s['hours'] ) : '';
	$config['timezone']      = wp_timezone_string();
	$config['closedMessage'] = $s['closed_message'];
	wp_enqueue_script(
		'inframe-loader',
		plugins_url( 'assets/inframe-loader.js', INFRAME_PLUGIN_FILE ),
		array(),
		(string) filemtime( $loader_file ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_script( 'inframe-loader', 'window.INFRAME_PLUGIN_CONFIG = ' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';', 'before' );
}

/**
 * Language of the widget (P6.8): Italian for every Italian locale, English for all the others, since the widget ships
 * only these two. On public pages determine_locale() is the site language.
 */
function inframe_widget_lang( $locale = null ) {
	return 0 === strpos( (string) ( $locale ?? determine_locale() ), 'it' ) ? 'it' : 'en';
}

/**
 * Default texts of the widget for the panel preview (P6.8). They mirror the dictionary in widget/src/inframe-widget.js,
 * which the visitor's browser uses; tests/local-integration.php checks that the two stay equal.
 */
function inframe_widget_texts( $lang, $company = '' ) {
	if ( 'en' === $lang ) {
		$company = $company ?: 'the business';
		return array(
			'title'    => 'Virtual assistant',
			'launcher' => 'Questions? Ask us',
			'subtitle' => 'Answers from this site’s content',
			'welcome'  => 'Hi! This is the virtual assistant of ' . $company . ', an artificial intelligence system: it answers using the information on this site. For special requests we can put you in touch with a person from our team.',
		);
	}
	$company = $company ?: 'l’azienda';
	return array(
		'title'    => 'Assistente virtuale',
		'launcher' => 'Hai domande? Chiedi a noi',
		'subtitle' => 'Risponde con i contenuti del sito',
		'welcome'  => 'Ciao! Questo è l’assistente virtuale di ' . $company . ', un sistema di intelligenza artificiale: risponde usando le informazioni presenti su questo sito. Per richieste particolari possiamo metterti in contatto con una persona del nostro team.',
	);
}

/**
 * P6.17: the rule for the page being viewed. A rule on the page itself wins; otherwise the rule of its category
 * (post category or WooCommerce product category), also on the category archive. First matching rule in the list.
 */
function inframe_page_rule_for_request( $rules ) {
	if ( ! $rules ) {
		return null;
	}
	$object  = get_queried_object();
	$targets = array();
	if ( $object instanceof WP_Post ) {
		$targets[] = 'page:' . $object->ID;
		foreach ( array( 'category', 'product_cat' ) as $taxonomy ) {
			$terms = taxonomy_exists( $taxonomy ) ? get_the_terms( $object, $taxonomy ) : false;
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$targets[] = 'term:' . $taxonomy . ':' . $term->term_id;
			}
		}
	} elseif ( $object instanceof WP_Term ) {
		$targets[] = 'term:' . $object->taxonomy . ':' . $object->term_id;
	}
	foreach ( $targets as $target ) {
		foreach ( $rules as $rule ) {
			if ( $rule['target'] === $target ) {
				return $rule;
			}
		}
	}
	return null;
}

/** P6.17: the three guided paths of each mode when the owner has not written their own, in the site language. */
function inframe_default_paths( $mode ) {
	if ( 'ecommerce' === $mode ) {
		return array( __( 'I am looking for a product', 'inframe' ), __( 'Shipping and returns', 'inframe' ), __( 'I would like to talk to someone', 'inframe' ) );
	}
	return array( __( 'I am looking for a service', 'inframe' ), __( 'I would like a quote', 'inframe' ), __( 'I need to book', 'inframe' ) );
}
