<?php
/** The seven panel pages (D-036). Each function has one home page; the guided setup reuses the same sections. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Sections shared by the pages and the guided setup ---------- */

function inframe_section_business( $s, $with_privacy = false ) {
	?>
	<form id="inframe-business-form" method="post" action="options.php">
		<?php settings_fields( 'inframe_settings' ); ?>
		<table class="form-table" role="presentation">
			<?php
			inframe_select_field(
				$s,
				'workflow_mode',
				__( 'What do you offer?', 'inframe' ),
				array(
					'servizi'   => __( 'Services', 'inframe' ),
					'ecommerce' => __( 'Products', 'inframe' ),
				)
			);
			inframe_field( $s, 'company', __( 'Business name', 'inframe' ), 'text', __( 'If empty, the site name is used.', 'inframe' ) );
			inframe_field( $s, 'lead_email', __( 'Where to receive requests', 'inframe' ), 'email', __( 'If empty, the WordPress administrator email is used. The actual recipient is shown in Requests.', 'inframe' ) );
			if ( $with_privacy ) {
				inframe_field( $s, 'privacy_url', __( 'Privacy policy', 'inframe' ), 'url', __( 'If empty, the WordPress privacy page is used. Without this link the public chat stays hidden.', 'inframe' ) );
			}
			?>
		</table>
		<?php submit_button( __( 'Save your choices', 'inframe' ) ); ?>
	</form>
	<?php
}

function inframe_section_mode( $s ) {
	$choices = array(
		'off'  => array( __( 'Off', 'inframe' ), __( 'Nobody sees the chat.', 'inframe' ) ),
		'test' => array( __( 'Test only', 'inframe' ), __( 'You and anyone with the preview link see it.', 'inframe' ) ),
		'live' => array( __( 'Public', 'inframe' ), __( 'All visitors see it.', 'inframe' ) ),
	);
	?>
	<form id="inframe-mode-form" method="post" action="options.php">
		<?php settings_fields( 'inframe_settings' ); ?>
		<fieldset class="inframe-mode"><legend class="screen-reader-text"><?php esc_html_e( 'Who sees the chat', 'inframe' ); ?></legend>
			<?php foreach ( $choices as $value => $choice ) : ?>
				<label class="inframe-mode-option"><input type="radio" name="inframe_settings[display_mode]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['display_mode'], $value ); ?> /> <span><strong><?php echo esc_html( $choice[0] ); ?></strong><small><?php echo esc_html( $choice[1] ); ?></small></span></label>
			<?php endforeach; ?>
		</fieldset>
		<?php submit_button( __( 'Save visibility', 'inframe' ), 'secondary', 'submit', false ); ?>
	</form>
	<?php
}

function inframe_section_open_chat( $s ) {
	$ready = ! inframe_frontend_setup_issues( $s );
	if ( 'test' === $s['display_mode'] && $ready ) {
		echo '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url(
			add_query_arg(
				array(
					'inframe_preview' => get_option( 'inframe_preview_token' ),
					'inframe'         => 'open',
				),
				home_url( '/' )
			)
		) . '">' . esc_html__( 'Open the test chat', 'inframe' ) . '</a></p>';
	} elseif ( 'live' === $s['display_mode'] && $ready ) {
		echo '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url( add_query_arg( 'inframe', 'open', home_url( '/' ) ) ) . '">' . esc_html__( 'Open the site with the chat', 'inframe' ) . '</a></p>';
	} else {
		echo '<p>' . esc_html__( 'Approve the documentation and choose “Test only” to open the test chat. When you have checked the answers and that requests arrive, you can choose “Public”.', 'inframe' ) . '</p>';
	}
}

function inframe_section_provider() {
	$ai = inframe_ai_settings();
	?>
	<p><?php esc_html_e( 'The provider charges AI usage to your account. The keys stay encrypted in the site database and are never shown in the chat. If you change the WordPress security keys, enter the API keys again.', 'inframe' ); ?></p>
	<form id="inframe-provider-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php inframe_workspace_fields( 'provider' ); ?>
		<input type="hidden" name="_consent_field" value="1" />
		<table class="form-table" role="presentation">
			<tr><th><label for="inframe-provider"><?php esc_html_e( 'Provider to use', 'inframe' ); ?></label></th><td><select id="inframe-provider" name="provider"><option value="openai" <?php selected( $ai['provider'], 'openai' ); ?>>OpenAI</option><option value="anthropic" <?php selected( $ai['provider'], 'anthropic' ); ?>>Anthropic</option></select></td></tr>
			<?php
			foreach ( array(
				'openai'    => 'OpenAI',
				'anthropic' => 'Anthropic',
			) as $provider => $label ) :
				?>
				<tr data-inframe-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="inframe-<?php echo esc_attr( $provider ); ?>-key">
					<?php
					/* translators: %s: AI provider name (OpenAI or Anthropic). */
					echo esc_html( sprintf( __( '%s API key', 'inframe' ), $label ) );
					?>
				</label></th><td>
					<input class="regular-text" id="inframe-<?php echo esc_attr( $provider ); ?>-key" type="password" name="<?php echo esc_attr( $provider ); ?>_key" value="" autocomplete="new-password" />
					<p class="description"><?php echo esc_html( inframe_ai_key_notice( $provider ) ); ?></p>
					<label><input type="checkbox" name="remove_<?php echo esc_attr( $provider ); ?>" value="1" /> <?php esc_html_e( 'Remove the saved key', 'inframe' ); ?></label>
				</td></tr>
				<tr data-inframe-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="inframe-model-<?php echo esc_attr( $provider ); ?>">
					<?php
					/* translators: %s: AI provider name (OpenAI or Anthropic). */
					echo esc_html( sprintf( __( '%s model', 'inframe' ), $label ) );
					?>
				</label></th><td><input class="regular-text" id="inframe-model-<?php echo esc_attr( $provider ); ?>" name="<?php echo esc_attr( $provider ); ?>_model" value="<?php echo esc_attr( $ai[ $provider . '_model' ] ); ?>" list="inframe-models-<?php echo esc_attr( $provider ); ?>" required /><?php inframe_model_info( $provider, $ai ); ?></td></tr>
			<?php endforeach; ?>
			<tr data-inframe-provider="anthropic" <?php echo 'anthropic' !== $ai['provider'] ? 'hidden' : ''; ?>><th><label for="inframe-workspace"><?php esc_html_e( 'Anthropic workspace', 'inframe' ); ?></label></th><td><input id="inframe-workspace" class="regular-text" name="workspace" value="<?php echo esc_attr( $ai['workspace'] ); ?>" /><p class="description"><?php esc_html_e( 'Optional; needed for some keys shared between workspaces.', 'inframe' ); ?></p></td></tr>
		</table>
		<?php
		$usage = inframe_usage_summary();
		if ( $usage['conversations'] ) :
			?>
			<p class="description">
				<?php
				/* translators: 1: average cost per AI conversation in euro, 2: URL of the monthly costs card. */
				echo wp_kses( sprintf( __( 'This month: on average %1$s per AI conversation, measured on the site (<a href="%2$s">Costs this month</a>).', 'inframe' ), esc_html( inframe_format_eur( $usage['conversation_avg'], 4 ) ), esc_url( inframe_admin_url( 'inframe' ) . '#inframe-costs' ) ), inframe_notice_html() );
				?>
			</p>
		<?php endif; ?>
		<p><label><input type="checkbox" name="consent" value="1" <?php checked( $ai['consent'] ); ?> /> <?php esc_html_e( 'I authorize sending the chosen content and the chat messages to the selected provider for analysis and answers.', 'inframe' ); ?></label></p>
		<p id="inframe-provider-feedback" role="alert" hidden></p>
		<?php submit_button( __( 'Save the connection', 'inframe' ), 'primary', 'submit', false ); ?>
		<?php submit_button( __( 'Save and test the AI connection', 'inframe' ), 'secondary', 'test_provider', false ); ?>
		<p class="description">
			<?php
			/* translators: %s: link to Settings › Limits. */
			echo wp_kses( sprintf( __( 'Saves key, model and authorization, then runs a small request on your account. The number of AI requests per day is set in %s.', 'inframe' ), '<a href="' . esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'limits' ) ) ) . '">' . esc_html__( 'Settings › Limits', 'inframe' ) . '</a>' ), inframe_notice_html() );
			?>
		</p>
	</form>
	<?php
}

/**
 * Under the model field (P6.3): the cheap model of the provider, the estimated cost of the chosen model and a warning
 * when the price list has no price for it. inframe-workspace.js repeats the same calculation while the owner types.
 */
function inframe_model_info( $provider, $ai ) {
	$economic = inframe_economic_models()[ $provider ];
	$model    = $ai[ $provider . '_model' ];
	$prices   = $ai['prices'] ?: inframe_default_prices();
	$estimate = inframe_model_estimate( $model, $ai );
	$typical  = inframe_typical_question();
	echo '<datalist id="inframe-models-' . esc_attr( $provider ) . '">';
	foreach ( array_keys( $prices ) as $name ) {
		if ( inframe_price_provider( $name ) === $provider ) {
			echo '<option value="' . esc_attr( $name ) . '">';
		}
	}
	echo '</datalist>';
	echo '<div class="inframe-model-info" id="inframe-model-info-' . esc_attr( $provider ) . '" data-input="inframe-model-' . esc_attr( $provider ) . '" data-economic="' . esc_attr( $economic ) . '" data-prices="' . esc_attr( wp_json_encode( $prices ) ) . '" data-rate="' . esc_attr( (string) (float) $ai['usd_eur'] ) . '" data-typical-in="' . esc_attr( $typical['in'] ) . '" data-typical-out="' . esc_attr( $typical['out'] ) . '">';
	/* translators: %s: name of the cheapest model of the provider. */
	echo '<p class="description">' . esc_html( sprintf( __( 'Recommended: %s, the cheapest.', 'inframe' ), $economic ) ) . ' <button type="button" class="button-link" data-inframe-use-model>' . esc_html__( 'Use the recommended model', 'inframe' ) . '</button></p>';
	echo '<p class="description" data-inframe-estimate' . ( $estimate ? '' : ' hidden' ) . '>' . esc_html( $estimate ? inframe_model_estimate_text( $model, $estimate ) : '' ) . '</p>';
	/* translators: %s: URL of Settings › Limits. */
	echo '<p class="description inframe-error" data-inframe-unpriced' . ( $estimate || '' === $model ? ' hidden' : '' ) . '>' . wp_kses( sprintf( __( 'This model is not in the price list: costs will be estimated at the highest prices. <a href="%s">Add the price in Settings › Limits</a>.', 'inframe' ), esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'limits' ) ) ) ), inframe_notice_html() ) . '</p>';
	echo '</div>';
}

function inframe_model_estimate_text( $model, $estimate ) {
	$typical = inframe_typical_question();
	return sprintf(
		/* translators: 1: model name, 2: euro per million input tokens, 3: euro per million output tokens, 4: euro per 100 questions, 5: input tokens of a typical question, 6: output tokens of a typical question. */
		__( 'Estimated cost with %1$s: %2$s per million input tokens and %3$s output, about %4$s per 100 questions (typical question: %5$s input tokens and %6$s output; the exact bill is the provider’s).', 'inframe' ),
		$model,
		inframe_format_eur( $estimate['in'] ),
		inframe_format_eur( $estimate['out'] ),
		inframe_format_eur( $estimate['per100'] ),
		number_format_i18n( $typical['in'] ),
		number_format_i18n( $typical['out'] )
	);
}

function inframe_section_scan() {
	inframe_render_discovery();
	?>
	<p><button type="button" class="button button-primary" id="inframe-scan" <?php disabled( ! is_array( get_option( 'inframe_discovery', false ) ) ); ?>><?php esc_html_e( 'Scan the site', 'inframe' ); ?></button></p>
	<p id="inframe-progress" class="inframe-progress" role="status" aria-live="polite" tabindex="-1"></p>
	<?php
}

function inframe_section_upload() {
	?>
	<form id="inframe-upload-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php inframe_workspace_fields( 'upload' ); ?>
		<p><label for="inframe-document"><?php esc_html_e( 'Additional document: TXT, MD, DOCX or PDF; up to 3 MB and 60 KB of extracted text.', 'inframe' ); ?></label></p>
		<p><input id="inframe-document" type="file" name="document" accept=".txt,.md,.docx,.pdf" required /></p>
		<?php submit_button( __( 'Add document', 'inframe' ), 'secondary', 'submit', false ); ?>
		<p class="description"><?php esc_html_e( 'PDFs are read by the selected provider, using the API, in a single request of at most 25 seconds: in tests a 10-page text PDF was already at the limit, so split longer documents into parts of a few pages. Always review the extracted text. The original files are not published in the media library. Approved information may appear in the answers to visitors: add only material fit for this use. For DOCX the body text is imported; for complex tables, images, headers or attachments prefer a PDF and check its extraction.', 'inframe' ); ?></p>
	</form>
	<?php
}

function inframe_section_manual() {
	?>
	<form id="inframe-manual-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php inframe_workspace_fields( 'manual' ); ?>
		<p><label for="inframe-manual-title"><?php esc_html_e( 'Title', 'inframe' ); ?></label><br><input id="inframe-manual-title" name="title" class="regular-text" required maxlength="200" /></p>
		<p><label for="inframe-manual-content"><?php esc_html_e( 'Information approved by the business', 'inframe' ); ?></label><br><textarea id="inframe-manual-content" name="content" class="large-text" rows="5" required></textarea></p>
		<?php submit_button( __( 'Save information', 'inframe' ), 'secondary', 'submit', false ); ?>
	</form>
	<?php
}

/** Analysis and draft: the source list comes from PHP because the source table is on another tab. */
function inframe_section_docs() {
	global $wpdb;
	$draft     = get_option( 'inframe_kb_draft', array() );
	$published = get_option( 'inframe_kb_published', array() );
	$included  = array_map(
		static function ( $row ) {
			return array(
				'id'    => (int) $row['id'],
				'title' => $row['title'],
			);
		},
		inframe_sources( true, true )
	);
	$errors    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}inframe_sources WHERE enabled = 1 AND analysis_error <> ''" );
	?>
	<p><?php esc_html_e( 'Select only correct information. The rebuild analyzes one source at a time and prepares a draft with references and verifiable quotes. Changes to a page immediately withdraw its old version from the chat: repeat scan, rebuild and approval to update it.', 'inframe' ); ?></p>
	<?php inframe_render_analysis_exclusions( inframe_sources() ); ?>
	<p><strong>
		<?php
		/* translators: %s: number of sources. */
		echo esc_html( sprintf( _n( '%s source included in the next draft.', '%s sources included in the next draft.', count( $included ), 'inframe' ), number_format_i18n( count( $included ) ) ) );
		?>
	</strong> <a href="<?php echo esc_url( inframe_admin_url( 'inframe-sources' ) ); ?>"><?php esc_html_e( 'Review the sources', 'inframe' ); ?></a></p>
	<p><button type="button" class="button button-primary" id="inframe-generate" data-inframe-sources="<?php echo esc_attr( wp_json_encode( $included ) ); ?>"><?php esc_html_e( 'Rebuild the documentation', 'inframe' ); ?></button></p>
	<div id="inframe-generate-progress" class="inframe-progress" role="status" aria-live="polite" tabindex="-1"></div>
	<p><a class="button" id="inframe-select-errors" href="<?php echo esc_url( inframe_admin_url( 'inframe-sources', array( 'state' => 'error' ) ) . '#inframe-source-manager' ); ?>" <?php echo $errors ? '' : 'hidden'; ?>><?php esc_html_e( 'Select the sources to fix', 'inframe' ); ?></a></p>
	<p class="description"><?php esc_html_e( 'The analysis uses all included sources, even those hidden by the filters. Sources with no useful content or with unusable analysis answers are excluded automatically and kept with the reason. The analysis continues and opens the draft with the useful sources. If no source is usable, no empty draft is created. Connection, credential or quota errors need a new attempt, without discarding the sources.', 'inframe' ); ?></p>
	<?php if ( ! empty( $draft['markdown'] ) ) : ?>
		<section id="inframe-knowledge-review" tabindex="-1" aria-labelledby="inframe-review-title">
			<h2 id="inframe-review-title"><?php esc_html_e( 'Draft to approve', 'inframe' ); ?></h2>
			<p><?php esc_html_e( 'The draft is ready. Check the text below, then select the confirmation box and press “Approve the documentation”. Until you approve, this information is not published for the chat.', 'inframe' ); ?></p>
			<textarea class="large-text code" rows="14" readonly aria-label="<?php esc_attr_e( 'Documentation draft', 'inframe' ); ?>"><?php echo esc_textarea( $draft['markdown'] ); ?></textarea>
			<?php inframe_render_agent_editor( $draft ); ?>
		</section>
	<?php endif; ?>
	<?php
	if ( empty( $draft['markdown'] ) && ! empty( $published['markdown'] ) ) {
		inframe_render_agent_editor( $published, false ); }
	?>
	<?php if ( ! empty( $published['markdown'] ) ) : ?>
		<h2><?php esc_html_e( 'Approved documentation', 'inframe' ); ?></h2>
		<p>
			<?php
			/* translators: 1: approval date and time as stored (UTC), 2: sources usable now, 3: sources in the approved documentation. */
			echo esc_html( sprintf( __( 'Documentation approved: %1$s. Sources usable now: %2$s/%3$s.', 'inframe' ), $published['created_at'], number_format_i18n( count( inframe_current_sources( $published ) ) ), number_format_i18n( count( $published['sources'] ) ) ) );
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php inframe_workspace_fields( 'download' ); ?><?php submit_button( __( 'Download the documentation (.md)', 'inframe' ), 'secondary', 'submit', false ); ?></form>
	<?php endif; ?>
	<?php if ( get_option( 'inframe_kb_previous' ) ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php inframe_workspace_fields( 'restore' ); ?><?php submit_button( __( 'Restore the previous documentation', 'inframe' ), 'secondary', 'submit', false ); ?></form>
	<?php endif; ?>
	<?php
}

function inframe_section_mail_test() {
	$recipient = '<span id="inframe-mail-recipient">' . esc_html( inframe_mail_recipient() ) . '</span>';
	$allowed   = array_merge( inframe_notice_html(), array( 'span' => array( 'id' => true ) ) );
	if ( inframe_get_settings()['lead_email'] ) {
		/* translators: 1: recipient email address, 2: link to Settings › Business. */
		$line = sprintf( __( '<strong>Actual recipient: %1$s</strong> — address chosen in %2$s.', 'inframe' ), $recipient, '<a href="' . esc_url( inframe_admin_url( 'inframe-settings' ) ) . '">' . esc_html__( 'Settings › Business', 'inframe' ) . '</a>' );
	} else {
		/* translators: %s: recipient email address. */
		$line = sprintf( __( '<strong>Actual recipient: %s</strong> — administrator email in the WordPress general settings.', 'inframe' ), $recipient );
	}
	echo '<p>' . wp_kses( $line, $allowed ) . '</p>';
	echo '<p>' . esc_html__( 'If the request appears here, it has been recorded. If the email does not arrive, check the recipient, the spam folder and the site’s mail configuration. The test uses the same system as the notifications. After fixing the mail you can resend a recorded request.', 'inframe' ) . '</p>';
	echo '<form id="inframe-mail-test" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	inframe_workspace_fields( 'mail_test' );
	submit_button( __( 'Send a test email', 'inframe' ), 'secondary', 'submit', false );
	echo '</form>';
}

/* ---------- Panoramica ---------- */

function inframe_page_overview() {
	global $wpdb;
	$s = inframe_get_settings();
	inframe_admin_open( 'inframe', __( 'The state of the chat and what needs your attention.', 'inframe' ) );
	inframe_cron_warning();
	$draft     = get_option( 'inframe_kb_draft', array() );
	$published = get_option( 'inframe_kb_published', array() );
	$recent    = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}inframe_leads ORDER BY id DESC LIMIT 3", ARRAY_A );
	$month     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}inframe_leads WHERE created_at >= %s", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) );
	?>
	<div class="inframe-grid">
		<section class="inframe-card inframe-card-wide" aria-labelledby="inframe-state-title">
			<h2 id="inframe-state-title"><?php esc_html_e( 'Chat status', 'inframe' ); ?></h2>
			<?php inframe_workspace_readiness( $s ); ?>
			<?php if ( ! $s['privacy_url'] && ! get_privacy_policy_url() ) : ?>
				<p class="inframe-error"><?php esc_html_e( 'The privacy policy is missing: the public chat stays hidden.', 'inframe' ); ?> <a href="<?php echo esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'privacy' ) ) ); ?>"><?php esc_html_e( 'Set the link', 'inframe' ); ?></a>.</p>
			<?php endif; ?>
			<?php inframe_section_mode( $s ); ?>
			<?php inframe_section_open_chat( $s ); ?>
			<p><a href="<?php echo esc_url( inframe_admin_url( 'inframe-appearance', array( 'tab' => 'where' ) ) ); ?>"><?php esc_html_e( 'Where the chat appears', 'inframe' ); ?></a></p>
		</section>
		<section class="inframe-card" id="inframe-check-card" aria-labelledby="inframe-check-title">
			<h2 id="inframe-check-title"><?php esc_html_e( 'Initial check', 'inframe' ); ?></h2>
			<?php inframe_section_initial_check(); ?>
		</section>
		<section class="inframe-card" id="inframe-costs" aria-labelledby="inframe-cost-title">
			<h2 id="inframe-cost-title"><?php esc_html_e( 'Costs this month', 'inframe' ); ?></h2>
			<?php inframe_section_costs(); ?>
		</section>
		<section class="inframe-card" aria-labelledby="inframe-kb-title">
			<h2 id="inframe-kb-title"><?php esc_html_e( 'Documentation', 'inframe' ); ?></h2>
			<?php if ( ! empty( $draft['markdown'] ) ) : ?>
				<p><strong><?php esc_html_e( 'A draft is waiting for your approval.', 'inframe' ); ?></strong></p>
			<?php endif; ?>
			<?php if ( ! empty( $published['markdown'] ) ) : ?>
				<?php inframe_owner_credit( $published ); ?>
				<ul class="inframe-stats">
					<li>
						<?php
						/* translators: 1: approved sources in use, 2: approved sources in total. */
						echo wp_kses( sprintf( __( '<strong>%1$s of %2$s</strong> approved sources in use', 'inframe' ), number_format_i18n( count( inframe_current_sources( $published ) ) ), number_format_i18n( count( $published['sources'] ) ) ), inframe_notice_html() );
						?>
					</li>
					<li>
						<?php
						/* translators: %s: approval date, in the site date format of the language (e.g. 17/11/2026). */
						echo wp_kses( sprintf( __( 'Approved on <strong>%s</strong>', 'inframe' ), esc_html( wp_date( _x( 'M j, Y', 'approval date format', 'inframe' ), strtotime( $published['created_at'] ) ) ) ), inframe_notice_html() );
						?>
					</li>
				</ul>
			<?php else : ?>
				<p><?php esc_html_e( 'No approved documentation yet.', 'inframe' ); ?></p>
			<?php endif; ?>
			<p><a class="button" href="<?php echo esc_url( inframe_admin_url( 'inframe-sources', array( 'tab' => 'docs' ) ) ); ?>"><?php esc_html_e( 'Sources and documentation', 'inframe' ); ?></a></p>
		</section>
		<section class="inframe-card" aria-labelledby="inframe-month-title">
			<h2 id="inframe-month-title"><?php esc_html_e( 'Last 30 days', 'inframe' ); ?></h2>
			<ul class="inframe-stats">
				<li>
					<?php
					/* translators: %s: number of contact requests. */
					echo wp_kses( sprintf( _n( '<strong>%s</strong> contact request', '<strong>%s</strong> contact requests', $month, 'inframe' ), number_format_i18n( $month ) ), inframe_notice_html() );
					?>
				</li>
				<?php $votes = inframe_feedback_summary(); ?>
				<li>
					<?php
					/* translators: 1: rated answers, 2: rated helpful, 3: rated not helpful. */
					echo wp_kses( sprintf( _n( '<strong>%1$s</strong> answer rated by visitors (helpful: %2$s, not helpful: %3$s)', '<strong>%1$s</strong> answers rated by visitors (helpful: %2$s, not helpful: %3$s)', $votes['total'], 'inframe' ), number_format_i18n( $votes['total'] ), number_format_i18n( $votes['up'] ), number_format_i18n( $votes['down'] ) ), inframe_notice_html() );
					?>
				</li>
			</ul>
			<p><a class="button" href="<?php echo esc_url( inframe_admin_url( 'inframe-questions' ) ); ?>"><?php esc_html_e( 'Unanswered questions', 'inframe' ); ?></a></p>
		</section>
		<section class="inframe-card inframe-card-wide" aria-labelledby="inframe-recent-title">
			<h2 id="inframe-recent-title"><?php esc_html_e( 'Latest requests', 'inframe' ); ?></h2>
			<?php if ( ! $recent ) : ?>
				<p><?php esc_html_e( 'No requests received yet.', 'inframe' ); ?></p>
			<?php else : ?>
				<div class="inframe-scroll" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Latest requests', 'inframe' ); ?>">
				<table class="widefat striped">
					<thead><tr><th scope="col"><?php esc_html_e( 'Date (UTC)', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Name', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Email to the owner', 'inframe' ); ?></th></tr></thead>
					<tbody>
					<?php
					foreach ( $recent as $row ) :
						$p = json_decode( $row['payload'], true );
						?>
						<tr><td><?php echo esc_html( $row['created_at'] ); ?></td><td><?php echo esc_html( $p['name'] ?? '' ); ?></td><td><?php echo 'accepted' === $row['delivery'] ? '<span class="inframe-pill inframe-pill-ok">' . esc_html__( 'Accepted', 'inframe' ) . '</span>' : '<span class="inframe-pill inframe-pill-warn">' . esc_html__( 'Not delivered', 'inframe' ) . '</span>'; ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</div>
			<?php endif; ?>
			<p><a href="<?php echo esc_url( inframe_admin_url( 'inframe-leads' ) ); ?>"><?php esc_html_e( 'All requests →', 'inframe' ); ?></a></p>
		</section>
	</div>
	<?php
	inframe_admin_close();
}

/**
 * P6.17: the credit goes to the owner. "You approved 12 sources: the chat can now answer about “A”, “B”, “C” and 9 more."
 * Names up to three approved sources in use, by title.
 */
function inframe_owner_credit( $published ) {
	$titles = array();
	foreach ( inframe_current_sources( $published ) as $row ) {
		$titles[] = '“' . $row['title'] . '”';
	}
	$count = count( $titles );
	if ( ! $count ) {
		return;
	}
	$named = implode( ', ', array_slice( $titles, 0, 3 ) );
	if ( $count > 3 ) {
		/* translators: 1: number of approved sources, 2: three source titles in quotes, separated by commas, 3: number of the other sources. */
		$text = sprintf( __( 'You approved %1$s sources: the chat can now answer about %2$s and %3$s more.', 'inframe' ), number_format_i18n( $count ), $named, number_format_i18n( $count - 3 ) );
	} else {
		/* translators: 1: number of approved sources, 2: their titles in quotes, separated by commas. */
		$text = sprintf( _n( 'You approved %1$s source: the chat can now answer about %2$s.', 'You approved %1$s sources: the chat can now answer about %2$s.', $count, 'inframe' ), number_format_i18n( $count ), $named );
	}
	echo '<p class="inframe-credit">' . esc_html( $text ) . '</p>';
}

/** Month estimate from the recorded tokens (P6.2). The exact amount is on the provider's invoice. */
function inframe_section_costs() {
	$u      = inframe_usage_summary();
	$limits = inframe_admin_url( 'inframe-settings', array( 'tab' => 'limits' ) );
	?>
	<ul class="inframe-stats">
		<li>
			<?php
			if ( $u['cap'] > 0 ) {
				/* translators: 1: estimated spending this month in euro, 2: monthly cap in euro. */
				echo wp_kses( sprintf( __( '<strong>%1$s</strong> estimated since the start of the month out of a cap of %2$s', 'inframe' ), esc_html( inframe_format_eur( $u['total'] ) ), esc_html( inframe_format_eur( $u['cap'] ) ) ), inframe_notice_html() );
			} else {
				/* translators: %s: estimated spending this month in euro. */
				echo wp_kses( sprintf( __( '<strong>%s</strong> estimated since the start of the month', 'inframe' ), esc_html( inframe_format_eur( $u['total'] ) ) ), inframe_notice_html() );
			}
			?>
		</li>
		<li>
			<?php
			/* translators: 1: chat cost in euro, 2: panel cost in euro, 3: number of AI calls. */
			echo wp_kses( sprintf( _n( 'Chat <strong>%1$s</strong> · panel <strong>%2$s</strong> (%3$s AI call)', 'Chat <strong>%1$s</strong> · panel <strong>%2$s</strong> (%3$s AI calls)', (int) $u['calls'], 'inframe' ), esc_html( inframe_format_eur( $u['chat'] ) ), esc_html( inframe_format_eur( $u['panel'] ) ), number_format_i18n( $u['calls'] ) ), inframe_notice_html() );
			?>
		</li>
		<li>
			<?php
			/* translators: 1: number of AI conversations, 2: average cost per conversation in euro, 3: highest cost of a conversation in euro. */
			echo wp_kses( sprintf( _n( '<strong>%1$s</strong> AI conversation · on average <strong>%2$s</strong>, at most <strong>%3$s</strong>', '<strong>%1$s</strong> AI conversations · on average <strong>%2$s</strong>, at most <strong>%3$s</strong>', (int) $u['conversations'], 'inframe' ), number_format_i18n( $u['conversations'] ), esc_html( inframe_format_eur( $u['conversation_avg'], 4 ) ), esc_html( inframe_format_eur( $u['conversation_max'], 4 ) ) ), inframe_notice_html() );
			?>
		</li>
	</ul>
	<?php if ( $u['cap'] <= 0 ) : ?>
		<p>
			<?php
			/* translators: %s: URL of Settings › Limits. */
			echo wp_kses( sprintf( __( 'No monthly spending cap: the chat answers as long as the AI requests per day allow. <a href="%s">Set a cap</a>.', 'inframe' ), esc_url( $limits ) ), inframe_notice_html() );
			?>
		</p>
	<?php endif; ?>
	<?php if ( $u['missing'] ) : ?>
		<p class="inframe-error">
			<?php
			/* translators: 1: comma-separated list of model names, 2: URL of Settings › Limits. */
			echo wp_kses( sprintf( __( 'The price of %1$s is missing: the estimate uses the highest prices in the list. <a href="%2$s">Complete the price list</a>.', 'inframe' ), esc_html( implode( ', ', $u['missing'] ) ), esc_url( $limits ) ), inframe_notice_html() );
			?>
		</p>
	<?php endif; ?>
	<p class="description"><?php esc_html_e( 'Estimate calculated from the recorded tokens with the price list in Settings › Limits: the exact amount is on the provider’s bill. Calls that timed out are not counted. The month follows the site time zone.', 'inframe' ); ?></p>
	<?php
}

/* ---------- Configurazione guidata ---------- */

function inframe_setup_steps() {
	$s         = inframe_get_settings();
	$ai        = inframe_ai_settings();
	$published = get_option( 'inframe_kb_published', array() );
	return array(
		1 => array( __( 'Business', 'inframe' ), '' !== $s['company'] || '' !== $s['lead_email'] ),
		2 => array( __( 'AI connection', 'inframe' ), $ai['consent'] && inframe_ai_key( $ai['provider'] ) ),
		3 => array( __( 'Content', 'inframe' ), (bool) inframe_sources( false, true ) ),
		4 => array( __( 'Documentation', 'inframe' ), ! empty( $published['markdown'] ) ),
		5 => array( __( 'Test and publication', 'inframe' ), 'off' !== $s['display_mode'] ),
	);
}

function inframe_page_setup() {
	$step  = max( 1, min( 5, absint( $_GET['step'] ?? 1 ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$steps = inframe_setup_steps();
	$s     = inframe_get_settings();
	inframe_admin_open( 'inframe-setup', __( 'Five steps for the first installation. You can repeat it whenever you want: every choice can also be changed from its own page.', 'inframe' ), array( (string) $step ) );
	echo '<ol class="inframe-steps" aria-label="' . esc_attr__( 'Setup steps', 'inframe' ) . '">';
	foreach ( $steps as $n => $info ) {
		$class = $n === $step ? 'current' : ( $info[1] ? 'done' : '' );
		echo '<li class="' . esc_attr( $class ) . '"><a href="' . esc_url( inframe_admin_url( 'inframe-setup', array( 'step' => $n ) ) ) . '"' . ( $n === $step ? ' aria-current="step"' : '' ) . '><span class="inframe-step-n">' . esc_html( $n ) . '</span> ' . esc_html( $info[0] ) . ( $info[1] ? '<span class="screen-reader-text"> ' . esc_html__( '(done)', 'inframe' ) . '</span>' : '' ) . '</a></li>';
	}
	echo '</ol><div class="inframe-wizard">';
	/* translators: 1: step number, 2: step name. */
	echo '<h2>' . esc_html( sprintf( __( '%1$s. %2$s', 'inframe' ), number_format_i18n( $step ), $steps[ $step ][0] ) ) . '</h2>';
	switch ( $step ) {
		case 1:
			inframe_section_business( $s, true );
			/* translators: 1: link to Settings › Business, 2: link to Privacy and retention. */
			echo '<p class="description">' . wp_kses( sprintf( __( 'You can also change this in %1$s and %2$s.', 'inframe' ), '<a href="' . esc_url( inframe_admin_url( 'inframe-settings' ) ) . '">' . esc_html__( 'Settings › Business', 'inframe' ) . '</a>', '<a href="' . esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'privacy' ) ) ) . '">' . esc_html__( 'Privacy and retention', 'inframe' ) . '</a>' ), inframe_notice_html() ) . '</p>';
			break;
		case 2:
			inframe_section_provider();
			break;
		case 3:
			inframe_section_scan();
			echo '<h3>' . esc_html__( 'Do you want to add a document?', 'inframe' ) . '</h3>';
			inframe_section_upload();
			/* translators: %s: link to Sources and documentation. */
			echo '<p class="description">' . wp_kses( sprintf( __( 'Manual information and source management in %s.', 'inframe' ), '<a href="' . esc_url( inframe_admin_url( 'inframe-sources' ) ) . '">' . esc_html__( 'Sources and documentation', 'inframe' ) . '</a>' ), inframe_notice_html() ) . '</p>';
			break;
		case 4:
			inframe_section_docs();
			break;
		default:
			echo '<ol class="inframe-todo"><li>' . esc_html__( 'Run the initial check: test the AI provider, send a test email and check the site.', 'inframe' );
			inframe_section_initial_check();
			echo '</li><li>' . esc_html__( 'Open the test chat and ask a few questions as a customer would.', 'inframe' );
			inframe_section_open_chat( $s );
			echo '</li><li>' . esc_html__( 'When you are satisfied, choose who can see the chat:', 'inframe' );
			inframe_section_mode( $s );
			echo '</li></ol>';
	}
	echo '<div class="inframe-wizard-nav">';
	if ( $step > 1 ) {
		echo '<a class="button" href="' . esc_url( inframe_admin_url( 'inframe-setup', array( 'step' => $step - 1 ) ) ) . '">' . esc_html__( '← Back', 'inframe' ) . '</a>';
	}
	echo $step < 5
		? '<a class="button button-primary" href="' . esc_url( inframe_admin_url( 'inframe-setup', array( 'step' => $step + 1 ) ) ) . '">' . esc_html__( 'Next →', 'inframe' ) . '</a>'
		: '<a class="button button-primary" href="' . esc_url( inframe_admin_url( 'inframe' ) ) . '">' . esc_html__( 'Go to the overview', 'inframe' ) . '</a>';
	echo '</div></div>';
	inframe_admin_close();
}

/* ---------- Fonti e documentazione ---------- */

function inframe_page_sources() {
	$tab = inframe_admin_open( 'inframe-sources', __( 'What the assistant knows and where it gets it from. Nothing reaches visitors without your approval.', 'inframe' ) );
	switch ( $tab ) {
		case 'scan':
			inframe_section_scan();
			break;
		case 'files':
			echo '<div class="inframe-columns"><section class="inframe-card"><h2>' . esc_html__( 'Add a document', 'inframe' ) . '</h2>';
			inframe_section_upload();
			echo '</section><section class="inframe-card"><h2>' . esc_html__( 'Add or correct a piece of information', 'inframe' ) . '</h2>';
			inframe_section_manual();
			echo '</section></div>';
			break;
		case 'docs':
			echo '<h2>' . esc_html__( 'Changes to approve again', 'inframe' ) . ' ' . wp_kses_post( inframe_admin_soon( 'P6.4' ) ) . '</h2>';
			inframe_section_docs();
			break;
		case 'test':
			inframe_section_retrieval_test();
			break;
		default:
			$sources = inframe_sources();
			echo '<p id="inframe-progress" class="inframe-progress" role="status" aria-live="polite" tabindex="-1"></p>';
			inframe_render_analysis_exclusions( $sources );
			inframe_render_source_manager( $sources, get_option( 'inframe_kb_published', array() ) );
			/* translators: %s: URL of the Documentation tab. */
			echo '<p>' . wp_kses( sprintf( __( 'After changing the sources, <a href="%s">rebuild and approve the documentation</a>.', 'inframe' ), esc_url( inframe_admin_url( 'inframe-sources', array( 'tab' => 'docs' ) ) ) ), inframe_notice_html() ) . '</p>';
	}
	inframe_admin_close();
}

function inframe_section_retrieval_test() {
	// Prefilled by "Prova nelle fonti" with a POST, so the question text never lands in access logs.
	// It only fills the field: the check itself is an Ajax call with its own nonce.
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	$question = sanitize_textarea_field( is_string( $_POST['inframe_question'] ?? null ) ? wp_unslash( $_POST['inframe_question'] ) : '' );
	?>
	<section id="inframe-retrieval-check" aria-labelledby="inframe-retrieval-title">
		<h2 id="inframe-retrieval-title"><?php esc_html_e( 'Check which sources a question finds', 'inframe' ); ?></h2>
		<p><?php esc_html_e( 'The local check shows the chosen passages without calling the AI. When the local search is empty or weak, the chat can select approved facts; if these are not enough, it also checks the original passages and searches with alternative terms. You can test the same path: in difficult cases it can use up to six AI search requests and it does not check the final answer. This test uses the question on its own: in the chat a follow-up question such as “And how much does it cost?” can refer to the source cited before or ask for a clarification.', 'inframe' ); ?></p>
		<form id="inframe-retrieval-form" class="inframe-inline-form">
			<label for="inframe-retrieval-query"><?php esc_html_e( 'Test question', 'inframe' ); ?></label>
			<input id="inframe-retrieval-query" class="regular-text" required maxlength="1000" placeholder="<?php esc_attr_e( 'What are your products?', 'inframe' ); ?>" value="<?php echo esc_attr( $question ); ?>" />
			<label><input id="inframe-retrieval-assisted" type="checkbox" /> <?php esc_html_e( 'Also test the AI search in the approved sources', 'inframe' ); ?></label>
			<button type="submit" class="button"><?php echo esc_html( _x( 'Check the sources', 'source test button', 'inframe' ) ); ?></button>
		</form>
		<div id="inframe-retrieval-result" tabindex="-1" role="status" aria-live="polite"></div>
	</section>
	<?php
}

/* ---------- Richieste ---------- */

function inframe_page_leads() {
	$filter = 'undelivered' === sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ) ? 'undelivered' : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	inframe_admin_open( 'inframe-leads', __( 'The contact details left by visitors in the chat.', 'inframe' ) );
	inframe_workspace_leads( $filter );
	$days = (int) inframe_get_settings()['lead_retention_days'];
	$last = inframe_cleanup_status()['last'];
	?>
	<div class="inframe-columns">
		<section class="inframe-card" aria-labelledby="inframe-recipient-title">
			<h2 id="inframe-recipient-title"><?php esc_html_e( 'Where requests go', 'inframe' ); ?></h2>
			<?php inframe_section_mail_test(); ?>
		</section>
		<section class="inframe-card" id="inframe-retention-summary" aria-labelledby="inframe-retention-title">
			<h2 id="inframe-retention-title"><?php esc_html_e( 'How long we keep them', 'inframe' ); ?></h2>
			<p>
				<?php
				/* translators: %s: number of days. */
				echo esc_html( sprintf( _n( 'Requests accepted by the email service are kept for %s day; the scheduled deletion depends on WP-Cron running. Undelivered ones stay until you resend or delete them. “Accepted by the email service” does not guarantee delivery to the inbox.', 'Requests accepted by the email service are kept for %s days; the scheduled deletion depends on WP-Cron running. Undelivered ones stay until you resend or delete them. “Accepted by the email service” does not guarantee delivery to the inbox.', $days, 'inframe' ), number_format_i18n( $days ) ) );
				?>
			</p>
			<p id="inframe-cleanup-last">
				<?php
				/* translators: %s: date and time of the last automatic cleanup, or "not run yet". */
				echo esc_html( sprintf( __( 'Last automatic cleanup: %s.', 'inframe' ), $last ? wp_date( _x( 'F j, Y, g:i a', 'last cleanup date format', 'inframe' ), $last ) : __( 'not run yet', 'inframe' ) ) );
				?>
			</p>
			<p>
				<?php
				/* translators: 1: URL of the privacy settings tab, 2: URL of the WordPress Export Personal Data tool, 3: URL of the WordPress Erase Personal Data tool. */
				echo wp_kses( sprintf( __( '<a href="%1$s">Change the retention</a> · Requests from a visitor for a copy or deletion of their data: <a href="%2$s">Tools › Export Personal Data</a> and <a href="%3$s">Erase Personal Data</a>.', 'inframe' ), esc_url( inframe_admin_url( 'inframe-settings', array( 'tab' => 'privacy' ) ) ), esc_url( admin_url( 'export-personal-data.php' ) ), esc_url( admin_url( 'erase-personal-data.php' ) ) ), inframe_notice_html() );
				?>
			</p>
		</section>
	</div>
	<?php
	inframe_admin_close();
}

/* ---------- Domande senza risposta ---------- */

function inframe_page_questions() {
	inframe_admin_open( 'inframe-questions', __( 'Questions the chat could not answer in the sessions of the last day. They tell you what is missing from the sources.', 'inframe' ) );
	inframe_workspace_unanswered_questions();
	inframe_workspace_unhelpful_answers();
	echo '<p>' . esc_html__( 'FAQ draft from a question', 'inframe' ) . ' ' . wp_kses_post( inframe_admin_soon( 'P6.5' ) ) . '</p>';
	inframe_admin_close();
}

/* ---------- Aspetto ---------- */

function inframe_page_appearance() {
	$tab = inframe_admin_open( 'inframe-appearance', __( 'How the chat looks and where it appears.', 'inframe' ) );
	$s   = inframe_get_settings();
	if ( 'widget' === $tab ) {
		echo '<div class="inframe-look"><div class="inframe-look-form">';
	}
	echo '<form id="inframe-appearance-form" method="post" action="options.php">';
	settings_fields( 'inframe_settings' );
	if ( 'where' === $tab ) {
		$pages = get_pages( array( 'sort_column' => 'post_title' ) );
		echo '<input type="hidden" name="inframe_settings[_visibility_form]" value="1" />';
		echo '<table class="form-table" role="presentation">';
		inframe_select_field(
			$s,
			'visibility',
			__( 'Pages', 'inframe' ),
			array(
				'all'     => __( 'The whole site', 'inframe' ),
				'include' => __( 'Only selected pages', 'inframe' ),
				'exclude' => __( 'The whole site, except the selected pages', 'inframe' ),
			)
		);
		?>
		<tr><th scope="row"><label for="inframe-page-ids"><?php esc_html_e( 'Select pages', 'inframe' ); ?></label></th><td>
			<select id="inframe-page-ids" name="inframe_settings[page_ids][]" multiple size="8" class="inframe-page-ids">
				<?php
				foreach ( $pages as $page ) :
					/* translators: %s: page ID. */
					$page_label = $page->post_title ?: sprintf( __( '(no title) #%s', 'inframe' ), $page->ID );
					?>
					<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( in_array( (int) $page->ID, $s['page_ids'], true ) ); ?>><?php echo esc_html( $page_label ); ?></option>
				<?php endforeach; ?>
			</select><p class="description"><?php esc_html_e( 'Shift/Ctrl for multiple selections. The shortcode and the block show the widget even outside these rules.', 'inframe' ); ?></p>
		</td></tr>
		<?php
		echo '</table>';
	} elseif ( 'welcome' === $tab ) {
		inframe_section_welcome( $s );
	} elseif ( 'contacts' === $tab ) {
		echo '<p>' . esc_html__( 'Shown below the contact form and when the chat cannot answer.', 'inframe' ) . '</p><table class="form-table" role="presentation">';
		inframe_field( $s, 'fallback_phone', __( 'Fallback phone', 'inframe' ) );
		inframe_field( $s, 'fallback_email', __( 'Fallback email', 'inframe' ), 'email' );
		inframe_field( $s, 'whatsapp', __( 'WhatsApp number', 'inframe' ), 'tel', __( 'Optional, with the international prefix, for example +39 333 1234567. The visitor opens WhatsApp with this number; the chat conversation is not sent.', 'inframe' ) );
		echo '</table>';
	} else {
		echo '<table class="form-table" role="presentation">';
		inframe_field( $s, 'title', __( 'Chat title', 'inframe' ) );
		inframe_field( $s, 'color', __( 'Color', 'inframe' ), 'text', __( 'Hexadecimal color, for example #0b4f8a. Any color works: the chat adapts text and shades so they stay readable.', 'inframe' ), inframe_color_note( inframe_widget_palette( $s['color'] ) ) );
		inframe_select_field(
			$s,
			'position',
			__( 'Position', 'inframe' ),
			array(
				'right' => __( 'Right', 'inframe' ),
				'left'  => __( 'Left', 'inframe' ),
			)
		);
		inframe_field( $s, 'welcome', __( 'Welcome', 'inframe' ), 'textarea', __( 'The notice that this is an AI assistant always stays visible.', 'inframe' ) );
		inframe_field( $s, 'suggestions', __( 'Suggested questions', 'inframe' ), 'textarea', __( 'One question per line, up to 8.', 'inframe' ) );
		inframe_field( $s, 'launcher_label', __( 'Chat button text', 'inframe' ) );
		echo '</table>';
	}
	submit_button( __( 'Save changes', 'inframe' ) );
	echo '</form>';
	if ( 'widget' === $tab ) {
		echo '</div>';
		inframe_widget_preview( $s );
		echo '</div>';
	}
	if ( 'where' === $tab ) {
		$preview = add_query_arg( 'inframe_preview', get_option( 'inframe_preview_token', '' ), home_url( '/' ) );
		?>
		<h2><?php esc_html_e( 'Block and shortcode', 'inframe' ); ?></h2>
		<p>
			<?php
			/* translators: %s: the shortcode, e.g. [inframe_chat]. */
			echo wp_kses( sprintf( __( 'Insert %s in a page or add the “inFrame” block to show the chat even outside these rules.', 'inframe' ), '<code>[inframe_chat]</code>' ), inframe_notice_html() );
			?>
		</p>
		<h2><?php esc_html_e( 'Preview link', 'inframe' ); ?></h2>
		<p><?php esc_html_e( 'In test mode the chat is visible only to administrators and to anyone with this link:', 'inframe' ); ?> <a href="<?php echo esc_url( $preview ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $preview ); ?></a></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm(<?php echo esc_attr( wp_json_encode( __( 'Regenerate the link? The old one will stop working.', 'inframe' ) ) ); ?>);">
			<input type="hidden" name="action" value="inframe_regenerate_preview" />
			<?php wp_nonce_field( 'inframe_regenerate_preview' ); ?>
			<?php submit_button( __( 'Regenerate preview link', 'inframe' ), 'secondary', 'submit', false ); ?>
		</form>
		<p>
			<?php
			/* translators: %s: link to the Overview page. */
			echo wp_kses( sprintf( __( 'Who sees the chat (off, test only, public) is chosen in %s.', 'inframe' ), '<a href="' . esc_url( inframe_admin_url( 'inframe' ) ) . '">' . esc_html__( 'Overview', 'inframe' ) . '</a>' ), inframe_notice_html() );
			?>
		</p>
		<?php
	}
	inframe_admin_close();
}

/** P6.17: guided paths, welcome and questions by page or category, opening hours and the out-of-hours message. */
function inframe_section_welcome( $s ) {
	$defaults = inframe_default_paths( $s['workflow_mode'] );
	$targets  = array();
	foreach ( get_pages( array( 'sort_column' => 'post_title' ) ) as $page ) {
		/* translators: %s: page ID. */
		$targets[ __( 'Pages', 'inframe' ) ][ 'page:' . $page->ID ] = $page->post_title ?: sprintf( __( '(no title) #%s', 'inframe' ), $page->ID );
	}
	foreach ( array(
		'category'    => __( 'Post categories', 'inframe' ),
		'product_cat' => __( 'Product categories', 'inframe' ),
	) as $taxonomy => $group ) {
		$terms = taxonomy_exists( $taxonomy ) ? get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		) : array();
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$targets[ $group ][ 'term:' . $taxonomy . ':' . $term->term_id ] = $term->name;
		}
	}
	$days = array(
		'mon' => __( 'Monday', 'inframe' ),
		'tue' => __( 'Tuesday', 'inframe' ),
		'wed' => __( 'Wednesday', 'inframe' ),
		'thu' => __( 'Thursday', 'inframe' ),
		'fri' => __( 'Friday', 'inframe' ),
		'sat' => __( 'Saturday', 'inframe' ),
		'sun' => __( 'Sunday', 'inframe' ),
	);
	echo '<input type="hidden" name="inframe_settings[_welcome_form]" value="1" />';
	?>
	<h2><?php esc_html_e( 'Guided paths', 'inframe' ); ?></h2>
	<p><?php esc_html_e( 'Three buttons under the welcome: one click sends the text as the first question. They help visitors start without knowing what to write.', 'inframe' ); ?></p>
	<table class="form-table" role="presentation">
		<tr><th scope="row"><?php esc_html_e( 'Show', 'inframe' ); ?></th><td><label><input type="checkbox" name="inframe_settings[show_paths]" value="1" <?php checked( $s['show_paths'] ); ?> /> <?php esc_html_e( 'Show the guided paths', 'inframe' ); ?></label></td></tr>
		<tr><th scope="row"><label for="inframe-paths"><?php esc_html_e( 'Paths', 'inframe' ); ?></label></th><td>
			<textarea class="large-text" rows="3" id="inframe-paths" name="inframe_settings[paths]" placeholder="<?php echo esc_attr( implode( "\n", $defaults ) ); ?>"><?php echo esc_textarea( str_replace( '|', "\n", $s['paths'] ) ); ?></textarea>
			<p class="description">
			<?php
			/* translators: %s: the three default paths, separated by " · ". */
			echo esc_html( sprintf( __( 'Up to 3, one per line. Empty: %s.', 'inframe' ), implode( ' · ', $defaults ) ) );
			?>
			</p>
		</td></tr>
	</table>
	<h2><?php esc_html_e( 'Welcome by page or category', 'inframe' ); ?></h2>
	<p><?php esc_html_e( 'On a page, or on the posts and products of a category, the chat can greet with its own welcome and three questions. A rule on a page wins over one on its category; elsewhere the welcome of the Widget tab stays.', 'inframe' ); ?></p>
	<table class="widefat striped inframe-rules">
		<thead><tr><th scope="col"><?php esc_html_e( 'Page or category', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Welcome', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Questions (up to 3, one per line)', 'inframe' ); ?></th></tr></thead>
		<tbody>
		<?php
		for ( $i = 0; $i < 10; $i++ ) :
			$rule = $s['page_rules'][ $i ] ?? array(
				'target'      => '',
				'welcome'     => '',
				'suggestions' => '',
			);
			/* translators: %s: rule number, 1 to 10. */
			$rule_label = sprintf( __( 'Rule %s', 'inframe' ), $i + 1 );
			?>
			<tr>
				<td><select name="inframe_settings[page_rules][<?php echo esc_attr( $i ); ?>][target]" aria-label="<?php echo esc_attr( $rule_label ); ?>" id="inframe-rule-<?php echo esc_attr( $i ); ?>">
					<option value=""><?php esc_html_e( '— No rule —', 'inframe' ); ?></option>
					<?php foreach ( $targets as $group => $options ) : ?>
						<optgroup label="<?php echo esc_attr( $group ); ?>">
						<?php foreach ( $options as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $rule['target'], $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
						</optgroup>
					<?php endforeach; ?>
				</select></td>
				<td><textarea class="large-text" rows="2" name="inframe_settings[page_rules][<?php echo esc_attr( $i ); ?>][welcome]" aria-label="<?php echo esc_attr( $rule_label . ' · ' . __( 'Welcome', 'inframe' ) ); ?>"><?php echo esc_textarea( $rule['welcome'] ); ?></textarea></td>
				<td><textarea class="large-text" rows="2" name="inframe_settings[page_rules][<?php echo esc_attr( $i ); ?>][suggestions]" aria-label="<?php echo esc_attr( $rule_label . ' · ' . __( 'Questions', 'inframe' ) ); ?>"><?php echo esc_textarea( str_replace( '|', "\n", $rule['suggestions'] ) ); ?></textarea></td>
			</tr>
		<?php endfor; ?>
		</tbody>
	</table>
	<h2><?php esc_html_e( 'Opening hours', 'inframe' ); ?></h2>
	<p><?php esc_html_e( 'Outside these hours the chat keeps answering from your sources and adds the message below, with the hours of the day. Leave every day empty to turn it off.', 'inframe' ); ?></p>
	<table class="form-table" role="presentation">
		<?php foreach ( $days as $day => $label ) : ?>
			<tr><th scope="row"><label for="inframe-hours-<?php echo esc_attr( $day ); ?>"><?php echo esc_html( $label ); ?></label></th><td><input class="regular-text" type="text" id="inframe-hours-<?php echo esc_attr( $day ); ?>" name="inframe_settings[hours][<?php echo esc_attr( $day ); ?>]" value="<?php echo esc_attr( $s['hours'][ $day ] ); ?>" placeholder="09:00-13:00, 15:00-19:00" /></td></tr>
		<?php endforeach; ?>
		<tr><th scope="row"><label for="inframe-closed_message"><?php esc_html_e( 'Out-of-hours message', 'inframe' ); ?></label></th><td>
			<input class="large-text" type="text" id="inframe-closed_message" name="inframe_settings[closed_message]" value="<?php echo esc_attr( $s['closed_message'] ); ?>" placeholder="<?php esc_attr_e( 'We are closed now: leave us your request and we will get back to you when we reopen.', 'inframe' ); ?>" />
			<p class="description">
			<?php
			/* translators: %s: the time zone of the site, e.g. Europe/Rome. */
			echo esc_html( sprintf( __( 'Empty: the default message, in the site language. Hours follow the site time zone (%s, in Settings › General).', 'inframe' ), wp_timezone_string() ) );
			?>
			</p>
		</td></tr>
	</table>
	<?php
}

/** Static preview of the widget, updated while typing; empty fields show the widget's own defaults. */
function inframe_widget_preview( $s ) {
	// The widget speaks the site language, not the administrator's (P6.8): its own texts, as the visitors see them.
	$texts   = inframe_widget_texts( inframe_widget_lang( get_locale() ), $s['company'] );
	$welcome = $texts['welcome'];
	?>
	<aside class="inframe-preview" aria-labelledby="inframe-preview-label">
		<p class="inframe-preview-label" id="inframe-preview-label"><?php esc_html_e( 'Preview', 'inframe' ); ?></p>
		<div class="inframe-preview-site" id="inframe-preview" data-position="<?php echo esc_attr( $s['position'] ); ?>" <?php $inframe_palette = inframe_widget_palette( $s['color'] ); ?>style="--inframe-color:<?php echo esc_attr( $inframe_palette['surface'] ); ?>;--inframe-on:<?php echo esc_attr( $inframe_palette['on'] ); ?>;--inframe-text:<?php echo esc_attr( $inframe_palette['text'] ); ?>" aria-hidden="true">
			<div class="inframe-preview-chat">
				<div class="inframe-preview-head"><span data-inframe-out="title" data-default="<?php echo esc_attr( $texts['title'] ); ?>"><?php echo esc_html( $s['title'] ?: $texts['title'] ); ?></span><small><?php echo esc_html( $texts['subtitle'] ); ?></small></div>
				<div class="inframe-preview-body">
					<p class="inframe-bubble" data-inframe-out="welcome" data-default="<?php echo esc_attr( $welcome ); ?>"><?php echo esc_html( $s['welcome'] ?: $welcome ); ?></p>
					<div class="inframe-chips" data-inframe-out="suggestions">
					<?php
					foreach ( array_filter( explode( '|', $s['suggestions'] ) ) as $suggestion ) :
						?>
						<span><?php echo esc_html( $suggestion ); ?></span><?php endforeach; ?></div>
				</div>
			</div>
			<span class="inframe-preview-launcher" data-inframe-out="launcher_label" data-default="<?php echo esc_attr( $texts['launcher'] ); ?>"><?php echo esc_html( $s['launcher_label'] ?: $texts['launcher'] ); ?></span>
		</div>
		<p class="description"><?php esc_html_e( 'Approximate: the final look and texts are shown with “Open the test chat”.', 'inframe' ); ?></p>
	</aside>
	<?php
}

/* ---------- Impostazioni ---------- */

function inframe_page_settings() {
	$tab = inframe_admin_open( 'inframe-settings' );
	$s   = inframe_get_settings();
	switch ( $tab ) {
		case 'provider':
			inframe_section_provider();
			break;
		case 'privacy':
			inframe_cron_warning();
			$last = inframe_cleanup_status()['last'];
			?>
			<form id="inframe-privacy-form" method="post" action="options.php">
				<?php settings_fields( 'inframe_settings' ); ?>
				<table class="form-table" role="presentation">
					<?php inframe_field( $s, 'privacy_url', __( 'Privacy policy', 'inframe' ), 'url', __( 'If empty, the WordPress privacy page is used. Without this link the public chat stays hidden.', 'inframe' ) ); ?>
					<tr><th scope="row"><label for="inframe-lead_retention_days"><?php esc_html_e( 'Keep delivered requests for', 'inframe' ); ?></label></th><td>
						<select id="inframe-lead_retention_days" name="inframe_settings[lead_retention_days]">
							<?php
							foreach ( inframe_retention_choices() as $choice ) :
								/* translators: %s: number of days. */
								$choice_label = sprintf( _n( '%s day', '%s days', $choice, 'inframe' ), number_format_i18n( $choice ) );
								?>
								<option value="<?php echo esc_attr( $choice ); ?>" <?php selected( (int) $s['lead_retention_days'], $choice ); ?>><?php echo esc_html( $choice_label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php
							/* translators: %s: date and time of the last automatic cleanup, or "not run yet". */
							echo esc_html( sprintf( __( 'Applies only to requests accepted by the email service: undelivered ones stay until you resend or delete them. The scheduled deletion depends on WP-Cron. Last automatic cleanup: %s.', 'inframe' ), $last ? wp_date( _x( 'F j, Y, g:i a', 'last cleanup date format', 'inframe' ), $last ) : __( 'not run yet', 'inframe' ) ) );
							?>
						</p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Visitor requests', 'inframe' ); ?></th><td><p>
						<?php
						/* translators: 1: URL of the WordPress Export Personal Data tool, 2: URL of the WordPress Erase Personal Data tool, 3: URL of the WordPress privacy policy guide. */
						echo wp_kses( sprintf( __( 'Copy or deletion of a visitor’s data: <a href="%1$s">Tools › Export Personal Data</a> and <a href="%2$s">Tools › Erase Personal Data</a>, with the email used in the form. <a href="%3$s">Suggested text for the privacy policy</a>.', 'inframe' ), esc_url( admin_url( 'export-personal-data.php' ) ), esc_url( admin_url( 'erase-personal-data.php' ) ), esc_url( admin_url( 'options-privacy.php?tab=policyguide' ) ) ), inframe_notice_html() );
						?>
					</p></td></tr>
				</table>
				<?php submit_button( __( 'Save changes', 'inframe' ) ); ?>
			</form>
			<?php
			break;
		case 'limits':
			$ai = inframe_ai_settings();
			?>
			<form id="inframe-limits-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php inframe_workspace_fields( 'limits' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="inframe-daily-limit"><?php esc_html_e( 'AI requests per day', 'inframe' ); ?></label></th><td><input id="inframe-daily-limit" class="small-text" type="number" min="1" max="1000" name="daily_limit" value="<?php echo esc_attr( $ai['daily_limit'] ); ?>" required /><p class="description"><?php esc_html_e( 'Includes analysis, PDF reading, tests and chat. The panel can use at most 70 percent of them: the rest is reserved for the chat. Also set spending limits in your provider account.', 'inframe' ); ?></p></td></tr>
					<tr><th scope="row"><label for="inframe-monthly-cap"><?php esc_html_e( 'Monthly spending cap (€)', 'inframe' ); ?></label></th><td><input id="inframe-monthly-cap" class="small-text" type="text" inputmode="decimal" name="monthly_cap" value="<?php echo esc_attr( inframe_cost_input_value( $ai['monthly_cap'] ) ); ?>" required /><p class="description"><?php esc_html_e( 'When the month estimate reaches it, the chat stops calling the AI and offers the contact form until next month; the panel keeps working and reports it. 0 = no cap. A question already in progress can exceed it by a few cents.', 'inframe' ); ?></p></td></tr>
					<tr><th scope="row"><label for="inframe-usd-eur"><?php esc_html_e( 'Dollar → euro exchange rate', 'inframe' ); ?></label></th><td><input id="inframe-usd-eur" class="small-text" type="text" inputmode="decimal" name="usd_eur" value="<?php echo esc_attr( inframe_cost_input_value( $ai['usd_eur'] ) ); ?>" required /><p class="description"><?php esc_html_e( 'How many euros one dollar is worth. Providers bill in dollars; the plugin does not download the exchange rate from the internet.', 'inframe' ); ?></p></td></tr>
				</table>
				<h2><?php esc_html_e( 'Price list', 'inframe' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Prices in dollars per million tokens, as published by OpenAI and Anthropic. A name also applies to the dated versions that start with it (claude-haiku-4-5 applies to claude-haiku-4-5-20251001). Empty a row to remove it.', 'inframe' ); ?></p>
				<input type="hidden" name="_prices_field" value="1" />
				<table class="widefat striped inframe-prices">
					<thead><tr><th scope="col"><?php esc_html_e( 'Model', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Input $ / 1M tokens', 'inframe' ); ?></th><th scope="col"><?php esc_html_e( 'Output $ / 1M tokens', 'inframe' ); ?></th></tr></thead>
					<tbody>
					<?php
					$inframe_rows     = $ai['prices'];
					$inframe_rows[''] = array(
						'in'  => '',
						'out' => '',
					);
					$inframe_i        = 0;
					foreach ( $inframe_rows as $inframe_model => $inframe_price ) :
						?>
						<tr>
							<td><input type="text" aria-label="<?php esc_attr_e( 'Model', 'inframe' ); ?>" name="prices[<?php echo esc_attr( $inframe_i ); ?>][model]" value="<?php echo esc_attr( $inframe_model ); ?>" /></td>
							<td><input class="small-text" type="text" inputmode="decimal" aria-label="<?php esc_attr_e( 'Input price', 'inframe' ); ?>" name="prices[<?php echo esc_attr( $inframe_i ); ?>][in]" value="<?php echo esc_attr( inframe_cost_input_value( $inframe_price['in'] ) ); ?>" /></td>
							<td><input class="small-text" type="text" inputmode="decimal" aria-label="<?php esc_attr_e( 'Output price', 'inframe' ); ?>" name="prices[<?php echo esc_attr( $inframe_i ); ?>][out]" value="<?php echo esc_attr( inframe_cost_input_value( $inframe_price['out'] ) ); ?>" /></td>
						</tr>
						<?php
						++$inframe_i;
					endforeach;
					?>
					</tbody>
				</table>
				<p class="description">
					<?php
					/* translators: 1: OpenAI model in use, 2: Anthropic model in use. */
					echo esc_html( sprintf( __( 'Models in use: %1$s (OpenAI), %2$s (Anthropic). Starting prices checked on 11/11/2026: check them on the provider pages.', 'inframe' ), $ai['openai_model'], $ai['anthropic_model'] ) );
					?>
				</p>
				<?php submit_button( __( 'Save limits', 'inframe' ) ); ?>
			</form>
			<?php
			break;
		case 'network':
			echo '<form id="inframe-network-form" method="post" action="options.php">';
			settings_fields( 'inframe_settings' );
			echo '<table class="form-table" role="presentation">';
			inframe_field( $s, 'trusted_proxies', __( 'Trusted proxies', 'inframe' ), 'textarea', __( 'Only if the site is behind Cloudflare, a CDN or a reverse proxy: addresses or networks (e.g. 203.0.113.5 or 10.0.0.0/8), one per line. For requests coming from these addresses the per-visitor limits use the IP given in X-Forwarded-For. Leave empty if you do not know what your hosting uses.', 'inframe' ) );
			echo '</table>';
			submit_button( __( 'Save changes', 'inframe' ) );
			echo '</form>';
			break;
		default:
			inframe_section_business( $s );
	}
	inframe_admin_close();
}
