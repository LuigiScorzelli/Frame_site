<?php
/**
 * Updates from the private endpoint on aiframe.it (D-024, D-027).
 * WordPress shows them in Dashboard > Updates like any other plugin update; the package is the tag ZIP (D-009).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const INFRAME_UPDATE_URL   = 'https://aiframe.it/inframe/update.json';
const INFRAME_UPDATE_HOSTS = array( 'aiframe.it', 'www.aiframe.it' );

// The hooks live here, not in the main file: the WordPress.org build drops this file and its require_once (P6.10).
add_filter( 'update_plugins_aiframe.it', 'inframe_update_check', 10, 3 );
add_filter( 'plugins_api', 'inframe_update_details', 10, 3 );
add_filter( 'upgrader_pre_download', 'inframe_update_download', 10, 2 );

/**
 * Latest version announced on aiframe.it, or null when the file is missing, slow or invalid.
 * Answers are cached: 6 hours when valid, 1 hour after a failure. "Check again" in Dashboard > Updates bypasses the cache.
 */
function inframe_update_info() {
	$forced = doing_action( 'load-update-core.php' ) && ! empty( $_GET['force-check'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only refresh, like WordPress core.
	$cached = get_transient( 'inframe_update_info' );
	if ( ! $forced && is_array( $cached ) && array_key_exists( 'info', $cached ) ) {
		return $cached['info'];
	}
	// Nothing about the site is sent: no query string, no cookies, and a fixed user agent instead of WordPress' default with the site address.
	$response = wp_safe_remote_get(
		INFRAME_UPDATE_URL,
		array(
			'timeout'             => 5,
			'redirection'         => 2,
			'limit_response_size' => 65536,
			'user-agent'          => 'inFrame-Updater',
			'headers'             => array( 'Accept' => 'application/json' ),
		)
	);
	$info     = inframe_update_parse( $response );
	set_transient( 'inframe_update_info', array( 'info' => $info ), $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $info;
}

/** Validates the update file. Any missing or unexpected field rejects the whole answer. */
function inframe_update_parse( $response ) {
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) ) {
		return null;
	}
	$text    = static function ( $key ) use ( $data ) {
		return isset( $data[ $key ] ) && is_string( $data[ $key ] ) ? $data[ $key ] : '';
	};
	$version = $text( 'version' );
	$package = $text( 'package' );
	$sha256  = strtolower( $text( 'sha256' ) );
	if ( ! preg_match( '/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?$/', $version ) || ! preg_match( '/^[a-f0-9]{64}$/', $sha256 ) || ! inframe_update_is_own_package( $package ) ) {
		return null;
	}
	$info = array(
		'version'   => $version,
		'package'   => $package,
		'sha256'    => $sha256,
		'released'  => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $text( 'released' ) ) ? $text( 'released' ) : '',
		'changelog' => mb_substr( $text( 'changelog' ), 0, 5000 ),
	);
	foreach ( array( 'requires', 'requires_php', 'tested' ) as $key ) {
		$value = $text( $key );
		if ( '' !== $value && ! preg_match( '/^\d+(?:\.\d+){0,2}$/', $value ) ) {
			return null;
		}
		$info[ $key ] = $value;
	}
	return $info;
}

/** Only HTTPS ZIP files in /inframe/ on aiframe.it can be offered or verified. */
function inframe_update_is_own_package( $url ) {
	$parts = wp_parse_url( (string) $url );
	return is_array( $parts ) && 'https' === ( $parts['scheme'] ?? '' ) && in_array( $parts['host'] ?? '', INFRAME_UPDATE_HOSTS, true ) && empty( $parts['port'] ) && empty( $parts['query'] ) && preg_match( '~^/inframe/[0-9A-Za-z._-]+\.zip$~', $parts['path'] ?? '' );
}

/** Filter update_plugins_aiframe.it: WordPress compares the version and offers the update only when it is newer. */
function inframe_update_check( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( INFRAME_PLUGIN_FILE ) !== $plugin_file ) {
		return $update;
	}
	$info = inframe_update_info();
	if ( ! $info ) {
		return $update;
	}
	// WordPress compares "tested" with the full version: like WordPress.org, "7.1" covers every 7.1.x release.
	$tested     = $info['tested'];
	$wp_version = wp_get_wp_version();
	if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $wp_version, $tested . '.' ) ) {
		$tested = $wp_version;
	}
	return array(
		'slug'         => 'inframe',
		'version'      => $info['version'],
		'url'          => 'https://aiframe.it/inframe/',
		'package'      => $info['package'],
		'requires'     => $info['requires'],
		'requires_php' => $info['requires_php'],
		'tested'       => $tested,
	);
}

/** "View details" in the plugin list. Without the update file this is an error, never another plugin with the same slug on WordPress.org. */
function inframe_update_details( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || 'inframe' !== ( $args->slug ?? '' ) ) {
		return $result;
	}
	$info = inframe_update_info();
	if ( ! $info ) {
		return new WP_Error( 'inframe_update_unavailable', __( 'The update information is not available. Try again later.', 'inframe' ) );
	}
	return (object) array(
		'name'          => 'inFrame',
		'slug'          => 'inframe',
		'version'       => $info['version'],
		'author'        => 'FR>ME',
		'homepage'      => 'https://aiframe.it/',
		'requires'      => $info['requires'],
		'requires_php'  => $info['requires_php'],
		'tested'        => $info['tested'],
		'last_updated'  => $info['released'],
		'download_link' => $info['package'],
		'sections'      => array( 'changelog' => wpautop( esc_html( $info['changelog'] ) ) ),
	);
}

/** Downloads a package from aiframe.it only if it is the announced one, and installs it only if its SHA-256 matches. */
function inframe_update_download( $reply, $package ) {
	if ( false !== $reply || ! is_string( $package ) || ! inframe_update_is_own_package( $package ) ) {
		return $reply;
	}
	$info = inframe_update_info();
	if ( ! $info || $info['package'] !== $package ) {
		return new WP_Error( 'inframe_update_unknown', __( 'The package does not match the latest announced version. Check for updates again.', 'inframe' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$file = download_url( $package, 300 );
	if ( is_wp_error( $file ) ) {
		return $file;
	}
	if ( ! hash_equals( $info['sha256'], (string) hash_file( 'sha256', $file ) ) ) {
		wp_delete_file( $file );
		return new WP_Error( 'inframe_update_hash', __( 'The downloaded package does not match the announced one: update cancelled, the installed plugin has not changed.', 'inframe' ) );
	}
	return $file;
}
