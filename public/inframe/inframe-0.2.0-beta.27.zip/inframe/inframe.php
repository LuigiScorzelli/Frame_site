<?php
/**
 * Plugin Name: inFrame – AI Assistant & Lead Capture for your site
 * Description: AI assistant for your site with your OpenAI or Anthropic key: it answers only from the content you approve and collects contact requests with consent.
 * Version: 0.2.0-beta.27
 * Requires at least: 7.0
 * Requires PHP: 8.3
 * Author: FR>ME
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: inframe
 * Domain Path: /languages
 * Update URI: https://aiframe.it/inframe/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'INFRAME_VERSION', '0.2.0-beta.27' );
define( 'INFRAME_PLUGIN_FILE', __FILE__ );

require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/frontend.php';
require_once __DIR__ . '/includes/ai-provider.php';
require_once __DIR__ . '/includes/local-storage.php';
require_once __DIR__ . '/includes/knowledge.php';
require_once __DIR__ . '/includes/discovery.php';
require_once __DIR__ . '/includes/agent.php';
require_once __DIR__ . '/includes/local-chat.php';
require_once __DIR__ . '/includes/source-manager.php';
require_once __DIR__ . '/includes/workspace.php';
require_once __DIR__ . '/includes/initial-check.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/admin-pages.php';
require_once __DIR__ . '/includes/updater.php';
require_once __DIR__ . '/includes/privacy.php';

/** Create a private preview token once, without loading it on every request. */
function inframe_activate() {
	inframe_local_install();
	if ( ! get_option( 'inframe_preview_token' ) ) {
		add_option( 'inframe_preview_token', wp_generate_password( 40, false, false ), '', false );
	}
}
register_activation_hook( __FILE__, 'inframe_activate' );

add_action( 'admin_init', 'inframe_register_settings' );
add_action( 'admin_init', 'inframe_local_maybe_install' );
add_action( 'init', 'inframe_remove_legacy_settings', 0 );
add_action( 'admin_menu', 'inframe_admin_menu' );
add_action( 'admin_init', 'inframe_legacy_redirect', 0 );
add_action( 'admin_enqueue_scripts', 'inframe_admin_assets' );
add_filter( 'admin_footer_text', 'inframe_admin_footer' );
add_action( 'admin_post_inframe_regenerate_preview', 'inframe_regenerate_preview' );
add_action( 'admin_init', 'inframe_register_privacy_text' );
add_filter( 'wp_privacy_personal_data_exporters', 'inframe_privacy_register_exporter' );
add_filter( 'wp_privacy_personal_data_erasers', 'inframe_privacy_register_eraser' );
add_action( 'admin_post_inframe_workspace', 'inframe_workspace_action' );
add_action( 'wp_ajax_inframe_knowledge', 'inframe_knowledge_ajax' );
add_action( 'rest_api_init', 'inframe_local_register_routes' );
add_action( 'save_post', 'inframe_post_changed', 100 );
add_action( 'before_delete_post', 'inframe_post_deleted' );
// WooCommerce fires save_post before writing price and stock: check again once the product is fully saved.
add_action( 'woocommerce_update_product', 'inframe_post_changed' );
add_action( 'woocommerce_update_product_variation', 'inframe_post_changed' );
add_action( 'updated_post_meta', 'inframe_product_meta_changed', 10, 3 );
add_action( 'added_post_meta', 'inframe_product_meta_changed', 10, 3 );
add_action( 'deleted_post_meta', 'inframe_product_meta_changed', 10, 3 );
add_action( 'set_object_terms', 'inframe_terms_changed', 10, 4 );
add_action( 'edited_term', 'inframe_term_changed', 10, 3 );
add_action( 'deleted_term', 'inframe_term_changed', 10, 5 );
add_action( 'inframe_local_cleanup', 'inframe_local_cleanup' );
add_action( 'inframe_local_retry', 'inframe_local_deliver' );

function inframe_deactivate() {
	wp_clear_scheduled_hook( 'inframe_local_cleanup' );
	// Parameterized retry events are cleared individually.
	foreach ( _get_cron_array() as $events ) {
		foreach ( $events['inframe_local_retry'] ?? array() as $event ) {
			wp_clear_scheduled_hook( 'inframe_local_retry', $event['args'] );
		}
	}
}
register_deactivation_hook( __FILE__, 'inframe_deactivate' );

add_action( 'init', 'inframe_register_block' );
add_shortcode( 'inframe_chat', 'inframe_shortcode' );
add_action( 'wp_footer', 'inframe_enqueue_frontend', 1 );
add_action( 'template_redirect', 'inframe_preview_redirect', 0 );
