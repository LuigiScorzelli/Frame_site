<?php
/** Remove only local plugin options. Remote lead data follows the service retention policy. */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wpla_settings' );
delete_option( 'wpla_preview_token' );

global $wpdb;
foreach ( array( 'wpla_discovery', 'wpla_agent_preferences', 'wpla_ai_settings', 'wpla_ai_credentials', 'wpla_local_schema', 'wpla_kb_draft', 'wpla_kb_published', 'wpla_kb_previous' ) as $option ) {
	delete_option( $option );
}
foreach ( array( 'wpla_sources', 'wpla_leads', 'wpla_counters', 'wpla_sessions' ) as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}$table" );
}
// Use the API to evict corresponding option caches as well as database rows.
$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_wpla_' ) . '%', $wpdb->esc_like( '_transient_timeout_wpla_' ) . '%' ) );
foreach ( $names as $name ) {
	delete_transient( preg_replace( '/^_transient_(?:timeout_)?/', '', $name ) );
}
wp_clear_scheduled_hook( 'wpla_local_cleanup' );
foreach ( _get_cron_array() as $events ) {
	foreach ( $events['wpla_local_retry'] ?? array() as $event ) {
		wp_clear_scheduled_hook( 'wpla_local_retry', $event['args'] );
	}
}
