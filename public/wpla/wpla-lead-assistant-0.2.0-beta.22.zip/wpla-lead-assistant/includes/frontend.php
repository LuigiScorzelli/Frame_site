<?php
/** Front-end visibility, shortcode/block, and lazy widget loading. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_shortcode() {
	$GLOBALS['wpla_manual_requested'] = true;
	return '<span class="wpla-chat-anchor" hidden aria-hidden="true"></span>';
}

function wpla_register_block() {
	wp_register_script(
		'wpla-block-editor',
		plugins_url( 'block/editor.js', WPLA_PLUGIN_FILE ),
		array( 'wp-blocks', 'wp-element', 'wp-components' ),
		WPLA_VERSION,
		true
	);
	register_block_type( __DIR__ . '/../block', array( 'render_callback' => 'wpla_shortcode' ) );
}

/** "Solo test": only administrators or whoever has the preview link. "Pubblico" does not call this check. */
function wpla_preview_allowed() {
	if ( current_user_can( 'manage_options' ) ) {
		return true;
	}
	// Il token di anteprima è solo in lettura e viene confrontato in modo costante; non modifica dati.
	$token = get_option( 'wpla_preview_token', '' );
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only token compared with hash_equals(), no state change.
	$given = isset( $_GET['wpla_preview'] ) && is_string( $_GET['wpla_preview'] )
		? sanitize_text_field( wp_unslash( $_GET['wpla_preview'] ) )
		: '';
	// phpcs:enable
	return is_string( $token ) && '' !== $token && '' !== $given && hash_equals( $token, $given );
}

function wpla_manual_on_page() {
	if ( ! empty( $GLOBALS['wpla_manual_requested'] ) ) {
		return true;
	}
	$post = get_queried_object();
	return $post instanceof WP_Post &&
		( has_shortcode( $post->post_content, 'wpla_chat' ) || has_block( 'wpla/chat', $post ) );
}

function wpla_visibility_matches( $settings ) {
	if ( 'all' === $settings['visibility'] ) {
		return true;
	}
	$id       = is_page() ? get_queried_object_id() : 0;
	$selected = $id && in_array( (int) $id, array_map( 'intval', $settings['page_ids'] ), true );
	if ( 'include' === $settings['visibility'] ) {
		return $selected;
	}
	return ! $selected;
}

/** Shared by the customer panel and the frontend so hidden chat has an explanation. */
function wpla_frontend_setup_issues( $s ) {
	$issues = array();
	$ai     = wpla_ai_settings();
	if ( ! $ai['consent'] ) {
		$issues['consent'] = 'In Impostazioni › Provider AI autorizza l’invio al provider e salva il collegamento.';
	}
	if ( ! wpla_ai_key( $ai['provider'] ) ) {
		$issues['key'] = 'In Impostazioni › Provider AI inserisci e salva una chiave API leggibile per il provider selezionato.';
	}
	$published = get_option( 'wpla_kb_published', array() );
	if ( ! wpla_current_sources( $published ) ) {
		$issues['knowledge'] = empty( $published['sources'] )
			? 'In Fonti e documentazione scansiona il sito o aggiungi un documento, ricrea la documentazione e approvala. Il solo collegamento AI non attiva la chat.'
			: 'Le fonti approvate non sono più utilizzabili. Ripeti scansione, ricostruzione e approvazione in Fonti e documentazione.';
	}
	if ( 'live' === $s['display_mode'] && ! ( $s['privacy_url'] ?: get_privacy_policy_url() ) ) {
		$issues['privacy'] = 'In Impostazioni › Privacy e conservazione inserisci il link all’informativa privacy, oppure configura la pagina privacy in WordPress.';
	}
	return $issues;
}

function wpla_enqueue_frontend() {
	if ( is_admin() || is_feed() ) {
		return;
	}
	$s = wpla_get_settings();
	if ( 'off' === $s['display_mode'] ) {
		return;
	}
	if ( wpla_frontend_setup_issues( $s ) ) {
		return;
	}
	$endpoint = rest_url( 'wpla/v1/chat' );
	if ( 'test' === $s['display_mode'] && wpla_preview_allowed() ) {
		$endpoint = add_query_arg( 'wpla_preview', get_option( 'wpla_preview_token' ), $endpoint );
	}
	if ( 'test' === $s['display_mode'] && ! wpla_preview_allowed() ) {
		return;
	}
	if ( ! wpla_manual_on_page() && ! wpla_visibility_matches( $s ) ) {
		return;
	}
	$privacy_url = $s['privacy_url'] ?: get_privacy_policy_url();

	$widget_file = __DIR__ . '/../assets/wpla-widget.js';
	$loader_file = __DIR__ . '/../assets/wpla-loader.js';
	$config      = array(
		'assetUrl'      => plugins_url( 'assets/wpla-widget.js', WPLA_PLUGIN_FILE ) . '?ver=' . (string) filemtime( $widget_file ),
		'endpoint'      => $endpoint,
		'siteKey'       => wpla_local_site_key(),
		'mode'          => $s['workflow_mode'],
		'title'         => $s['title'],
		'company'       => $s['company'],
		'color'         => $s['color'],
		'position'      => $s['position'],
		'welcome'       => $s['welcome'],
		'privacyUrl'    => $privacy_url,
		'fallbackPhone' => $s['fallback_phone'],
		'fallbackEmail' => $s['fallback_email'],
		'suggestions'   => $s['suggestions'],
		'launcherLabel' => $s['launcher_label'],
		'consentText'   => wpla_consent_text(),
	);
	wp_enqueue_script(
		'wpla-loader',
		plugins_url( 'assets/wpla-loader.js', WPLA_PLUGIN_FILE ),
		array(),
		(string) filemtime( $loader_file ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_script( 'wpla-loader', 'window.WPLA_PLUGIN_CONFIG = ' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';', 'before' );
}
