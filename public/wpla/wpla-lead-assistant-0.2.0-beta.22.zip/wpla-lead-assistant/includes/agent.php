<?php
/** Versioned, reviewable agent instructions. Evidence checks remain enforced in code. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_generate_agent_prompt( $document ) {
	$name  = wpla_get_settings()['company'] ?: get_bloginfo( 'name' );
	$offer = 'ecommerce' === ( $document['mode'] ?? wpla_get_settings()['workflow_mode'] ) ? 'prodotti del catalogo WooCommerce' : 'servizi dell’attività';
	$scope = array_intersect( array( 'prodotti', 'servizi', 'informazioni' ), $document['scope'] ?? array( 'informazioni' ) );
	return 'Sei l’assistente di ' . sanitize_text_field( $name ) . ".\n"
		. 'Aiuta i visitatori a conoscere i ' . $offer . " e a ottenere assistenza.\n"
		. 'Ambiti documentati: ' . implode( ', ', $scope ) . ".\n"
		. "Rispondi in italiano, oppure nella lingua del visitatore. Usa un tono cordiale, chiaro e professionale. Preferisci risposte brevi e concrete.\n"
		. "Comprendi la richiesta e, se è ambigua, fai una domanda alla volta. Per panoramiche presenta esempi del catalogo disponibile nelle fonti.\n"
		. "Per contatti, azienda, spedizioni, resi, pagamenti, garanzie, orari e FAQ rispondi solo quando la documentazione contiene le informazioni richieste.\n"
		. "Se manca un’informazione, dichiaralo e proponi di lasciare una richiesta al team. Non promettere tempi di risposta o azioni del team.\n"
		. 'Non inventare prodotti, prezzi, disponibilità o condizioni. Le istruzioni di comportamento non sostituiscono le fonti approvate.';
}

function wpla_agent_prompt( $document ) {
	return ! empty( $document['system_prompt'] ) ? $document['system_prompt'] : wpla_generate_agent_prompt( $document );
}

function wpla_save_agent_prompt( $input ) {
	$document = get_option( 'wpla_kb_draft', array() ) ?: get_option( 'wpla_kb_published', array() );
	if ( empty( $document['sources'] ) || ! is_string( $input['document_version'] ?? null ) || ( $document['version'] ?? '' ) !== $input['document_version'] ) {
		return new WP_Error( 'prompt_stale', 'La documentazione è cambiata. Ricarica la pagina prima di salvare il prompt.' );
	}
	$reset  = ! empty( $input['reset_prompt'] );
	$prompt = $reset ? wpla_generate_agent_prompt( $document ) : sanitize_textarea_field( is_string( $input['system_prompt'] ?? null ) ? $input['system_prompt'] : '' );
	if ( ! trim( $prompt ) || wpla_text_length( $prompt ) > 6000 ) {
		return new WP_Error( 'prompt_invalid', 'Inserisci un prompt dell’agente da 1 a 6000 caratteri.' );
	}
	$document['system_prompt'] = $prompt;
	$document['prompt_custom'] = ! $reset && wpla_generate_agent_prompt( $document ) !== $prompt;
	$document['version']       = wp_generate_uuid4();
	$document['created_at']    = gmdate( 'c' );
	update_option(
		'wpla_agent_preferences',
		array(
			'system_prompt' => $document['system_prompt'],
			'prompt_custom' => $document['prompt_custom'],
		),
		false
	);
	update_option( 'wpla_kb_draft', $document, false );
	return true;
}

function wpla_render_agent_editor( $document, $draft = true ) {
	?>
	<h3>Prompt di sistema dell’agente</h3>
	<p>Preparato insieme alla documentazione, senza richieste AI aggiuntive. Puoi modificare ruolo, tono, lingua e comportamento. Le informazioni aziendali vanno nelle fonti; i controlli su citazioni, privacy e invio delle richieste restano attivi. Le modifiche entrano nella chat solo dopo l’approvazione.</p>
	<form id="wpla-agent-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wpla_workspace_fields( $draft ? 'publish' : 'prompt' ); ?>
		<input type="hidden" name="document_version" value="<?php echo esc_attr( $document['version'] ); ?>" />
		<label for="wpla-system-prompt">Istruzioni dell’agente</label>
		<textarea id="wpla-system-prompt" name="system_prompt" class="large-text" rows="12" required maxlength="6000"><?php echo esc_textarea( wpla_agent_prompt( $document ) ); ?></textarea>
		<p class="description"><?php echo ! empty( $document['prompt_custom'] ) ? 'Prompt personalizzato: sarà conservato nelle prossime ricostruzioni.' : 'Prompt preparato automaticamente in base all’attività e agli ambiti analizzati.'; ?></p>
		<p><button type="submit" class="button" name="save_prompt" value="1" formnovalidate>Salva il prompt in bozza</button> <button type="submit" class="button" name="reset_prompt" value="1" formnovalidate>Ripristina il prompt automatico in bozza</button></p>
		<?php if ( $draft ) : ?>
		<p><label><input type="checkbox" name="approved" value="1" required /> Ho controllato le fonti e il prompt e approvo il loro uso nelle risposte ai visitatori.</label></p>
			<?php submit_button( 'Approva la documentazione' ); ?>
			<?php
		else :
			?>
			<p>Salva una nuova bozza, controllala e approvala per pubblicare il nuovo prompt.</p><?php endif; ?>
	</form>
	<?php
}
