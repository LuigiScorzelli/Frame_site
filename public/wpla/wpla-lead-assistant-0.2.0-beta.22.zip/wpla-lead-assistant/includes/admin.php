<?php
/** Panel structure (P6.16, D-036): top-level menu, seven pages, tabs, shared header and redirects. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Slug => title, render callback and tabs. The first tab is the default one. */
function wpla_admin_pages() {
	return array(
		'wpla'            => array( 'Panoramica', 'wpla_page_overview', array() ),
		'wpla-setup'      => array( 'Configurazione guidata', 'wpla_page_setup', array() ),
		'wpla-sources'    => array(
			'Fonti e documentazione',
			'wpla_page_sources',
			array(
				'sources' => 'Fonti',
				'scan'    => 'Selezione e scansione',
				'files'   => 'Documenti e informazioni',
				'docs'    => 'Documentazione',
				'test'    => 'Prova delle fonti',
			),
		),
		'wpla-leads'      => array( 'Richieste', 'wpla_page_leads', array() ),
		'wpla-questions'  => array( 'Domande senza risposta', 'wpla_page_questions', array() ),
		'wpla-appearance' => array(
			'Aspetto',
			'wpla_page_appearance',
			array(
				'widget'   => 'Widget',
				'contacts' => 'Contatti alternativi',
				'where'    => 'Dove compare',
			),
		),
		'wpla-settings'   => array(
			'Impostazioni',
			'wpla_page_settings',
			array(
				'business' => 'Attività',
				'provider' => 'Provider AI',
				'privacy'  => 'Privacy e conservazione',
				'limits'   => 'Limiti',
				'network'  => 'Rete',
			),
		),
	);
}

function wpla_admin_menu() {
	add_menu_page( 'Lead Assistant', 'Lead Assistant', 'manage_options', 'wpla', 'wpla_page_overview', 'dashicons-format-chat', 58 );
	// Only a cheap COUNT here: the unanswered questions would read the sessions on every admin page.
	$undelivered = wpla_undelivered_leads();
	foreach ( wpla_admin_pages() as $slug => $page ) {
		$label = $page[0];
		if ( 'wpla-leads' === $slug && $undelivered ) {
			$label .= ' <span class="awaiting-mod count-' . $undelivered . '"><span class="pending-count">' . $undelivered . '</span></span>';
		}
		add_submenu_page( 'wpla', $page[0] . ' ‹ Lead Assistant', $label, 'manage_options', $slug, $page[1] );
	}
}

function wpla_admin_url( $slug, $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => $slug ), $args ), admin_url( 'admin.php' ) );
}

function wpla_admin_current_page() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
	return isset( wpla_admin_pages()[ $page ] ) ? $page : '';
}

function wpla_admin_current_tab( $slug ) {
	$tabs = wpla_admin_pages()[ $slug ][2];
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$tab = sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) );
	return isset( $tabs[ $tab ] ) ? $tab : (string) array_key_first( $tabs );
}

/** Bookmarks and tester guides use the old Settings address (up to beta.21). */
function wpla_legacy_redirect() {
	global $pagenow;
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only redirect, no state change.
	$page = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
	$tab  = sanitize_key( wp_unslash( $_GET['tab'] ?? '' ) );
	// phpcs:enable
	if ( 'options-general.php' !== $pagenow || 'wpla' !== $page ) {
		return;
	}
	wp_safe_redirect( 'technical' === $tab ? wpla_admin_url( 'wpla-appearance' ) : wpla_admin_url( 'wpla' ) );
	exit;
}

function wpla_admin_assets() {
	if ( ! wpla_admin_current_page() ) {
		return;
	}
	wp_enqueue_style( 'wpla-workspace', plugins_url( 'assets/wpla-workspace.css', WPLA_PLUGIN_FILE ), array(), WPLA_VERSION );
	wp_enqueue_script( 'wpla-workspace', plugins_url( 'assets/wpla-workspace.js', WPLA_PLUGIN_FILE ), array(), WPLA_VERSION, true );
	wp_localize_script(
		'wpla-workspace',
		'WPLA_WORKSPACE',
		array(
			'url'        => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'wpla_knowledge' ),
			'sourcesUrl' => wpla_admin_url( 'wpla-sources' ),
		)
	);
}

function wpla_admin_footer( $text ) {
	return wpla_admin_current_page() ? 'WP Lead Assistant · Beta gratuita ' . esc_html( WPLA_VERSION ) : $text;
}

/** Page context: action forms post it back so the guided setup returns to its own step. */
function wpla_admin_context( $context = null ) {
	static $current = '';
	if ( null !== $context ) {
		$current = $context;
	}
	return $current;
}

/** Destination after an admin-post action: the guided setup step it came from, otherwise the home page of the function. */
function wpla_admin_return_url( $input, $slug, $args = array(), $anchor = '' ) {
	$parts = explode( '|', sanitize_text_field( is_string( $input['wpla_return'] ?? null ) ? $input['wpla_return'] : '' ) );
	if ( 'wpla-setup' === $parts[0] ) {
		$step = max( 1, min( 5, (int) ( $parts[2] ?? 1 ) ) );
		return wpla_admin_url( 'wpla-setup', array( 'step' => $step ) ) . $anchor;
	}
	return wpla_admin_url( $slug, $args ) . $anchor;
}

/** Shared header of every panel page: title, saved-settings and operation notices, warnings, tabs. */
function wpla_admin_open( $slug, $intro = '', $context = array() ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accesso negato.', 'wpla-lead-assistant' ) );
	}
	$page = wpla_admin_pages()[ $slug ];
	$tab  = $page[2] ? wpla_admin_current_tab( $slug ) : '';
	wpla_admin_context( implode( '|', array_merge( array( $slug, $tab ), $context ) ) );
	$notice = get_transient( 'wpla_workspace_' . get_current_user_id() );
	delete_transient( 'wpla_workspace_' . get_current_user_id() );
	echo '<div class="wrap wpla-admin">';
	echo '<h1>' . esc_html( $page[0] ) . '</h1>';
	if ( $intro ) {
		echo '<p class="wpla-intro">' . esc_html( $intro ) . '</p>';
	}
	// Pages outside Settings do not print the options.php notices by themselves.
	settings_errors();
	if ( $notice ) {
		// Announced to screen readers: the page reloads after every action.
		echo '<div class="notice ' . ( $notice['ok'] ? 'notice-success" role="status' : 'notice-error" role="alert' ) . '"><p>' . esc_html( $notice['message'] ) . '</p></div>';
	}
	if ( 'wpla-leads' !== $slug && wpla_undelivered_leads() ) {
		echo '<div class="notice notice-warning" id="wpla-undelivered-notice"><p>Ci sono richieste di contatto non consegnate per email. <a href="' . esc_url( wpla_admin_url( 'wpla-leads', array( 'status' => 'undelivered' ) ) ) . '">Vedi le richieste</a>.</p></div>';
	}
	if ( $page[2] ) {
		echo '<nav class="nav-tab-wrapper wp-clearfix" aria-label="Sezioni di ' . esc_attr( $page[0] ) . '">';
		foreach ( $page[2] as $key => $label ) {
			$active = $key === $tab;
			echo '<a href="' . esc_url( wpla_admin_url( $slug, array( 'tab' => $key ) ) ) . '" class="nav-tab' . ( $active ? ' nav-tab-active' : '' ) . '"' . ( $active ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}
	return $tab;
}

function wpla_admin_close() {
	echo '</div>';
}

/** Marks the space reserved for a later Phase 6 task: no sample data. */
function wpla_admin_soon( $task ) {
	return '<span class="wpla-soon">In arrivo · ' . esc_html( $task ) . '</span>';
}

/** Hidden marker of the page that rendered an admin-post form. */
function wpla_admin_return_field() {
	if ( wpla_admin_context() ) {
		echo '<input type="hidden" name="wpla_return" value="' . esc_attr( wpla_admin_context() ) . '" />';
	}
}
