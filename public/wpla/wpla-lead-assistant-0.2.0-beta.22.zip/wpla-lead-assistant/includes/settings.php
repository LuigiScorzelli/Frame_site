<?php
/** Settings option, validation and the form field helpers used by the panel pages. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_defaults() {
	return array(
		'lead_email'          => '',
		'display_mode'        => 'off',
		'workflow_mode'       => 'servizi',
		'visibility'          => 'all',
		'page_ids'            => array(),
		'title'               => '',
		'company'             => '',
		'color'               => '#1f5fbf',
		'position'            => 'right',
		'welcome'             => '',
		'privacy_url'         => '',
		'fallback_phone'      => '',
		'fallback_email'      => '',
		'suggestions'         => '',
		'launcher_label'      => '',
		'trusted_proxies'     => '',
		'lead_retention_days' => 30,
	);
}

/** Days a lead accepted by the email service is kept (P3.11). Undelivered leads are not affected (D-020). */
function wpla_retention_choices() {
	return array( 7, 30, 90, 180, 365 );
}

function wpla_get_settings() {
	$saved    = get_option( 'wpla_settings', array() );
	$defaults = wpla_defaults();
	return wp_parse_args( is_array( $saved ) ? array_intersect_key( $saved, $defaults ) : array(), $defaults );
}

/** Remove the retired external-service configuration after an upgrade. */
function wpla_remove_legacy_settings() {
	$saved = get_option( 'wpla_settings', array() );
	if ( ! is_array( $saved ) || ! array_intersect( array( 'engine', 'endpoint', 'site_key' ), array_keys( $saved ) ) ) {
		return;
	}
	unset( $saved['engine'], $saved['endpoint'], $saved['site_key'] );
	update_option( 'wpla_settings', $saved, false );
}

function wpla_sanitize_settings( $input ) {
	$input = is_array( $input ) ? wp_unslash( $input ) : array();
	$old   = wpla_get_settings();
	// Customer and technical forms edit subsets of the same options.
	if ( ! empty( $input['_visibility_form'] ) && ! isset( $input['page_ids'] ) ) {
		$input['page_ids'] = array();
	}
	$input               = wp_parse_args( $input, $old );
	$clean               = wpla_defaults();
	$clean['lead_email'] = sanitize_email( $input['lead_email'] );

	$clean['display_mode']  = in_array( $input['display_mode'] ?? '', array( 'off', 'test', 'live' ), true ) ? $input['display_mode'] : 'off';
	$clean['workflow_mode'] = in_array( $input['workflow_mode'] ?? '', array( 'servizi', 'ecommerce' ), true ) ? $input['workflow_mode'] : 'servizi';
	$clean['visibility']    = in_array( $input['visibility'] ?? '', array( 'all', 'include', 'exclude' ), true ) ? $input['visibility'] : 'all';
	$clean['position']      = in_array( $input['position'] ?? '', array( 'left', 'right' ), true ) ? $input['position'] : 'right';
	$page_ids               = array_map( 'intval', (array) ( $input['page_ids'] ?? array() ) );
	$clean['page_ids']      = array_values(
		array_unique(
			array_filter(
				$page_ids,
				static function ( $id ) {
					return $id > 0;
				}
			)
		)
	);
	$clean['color']         = sanitize_hex_color( $input['color'] ?? '' ) ?: '#1f5fbf';

	foreach ( array( 'title', 'company', 'fallback_phone', 'launcher_label' ) as $key ) {
		$clean[ $key ] = sanitize_text_field( $input[ $key ] ?? '' );
	}
	$clean['fallback_email']      = sanitize_email( $input['fallback_email'] ?? '' );
	$clean['privacy_url']         = esc_url_raw( $input['privacy_url'] ?? '', array( 'http', 'https' ) );
	$clean['welcome']             = sanitize_textarea_field( $input['welcome'] ?? '' );
	$lines                        = preg_split( '/[\r\n|]+/', (string) ( $input['suggestions'] ?? '' ) );
	$clean['suggestions']         = implode( '|', array_slice( array_filter( array_map( 'sanitize_text_field', $lines ) ), 0, 8 ) );
	$proxies                      = preg_split( '/[\s,]+/', (string) ( $input['trusted_proxies'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY );
	$clean['trusted_proxies']     = implode( "\n", array_slice( array_values( array_unique( array_filter( $proxies, 'wpla_is_ip_range' ) ) ), 0, 20 ) );
	$days                         = (int) ( $input['lead_retention_days'] ?? 30 );
	$clean['lead_retention_days'] = in_array( $days, wpla_retention_choices(), true ) ? $days : 30;

	return $clean;
}

/** A single IPv4/IPv6 address or a network in CIDR notation. */
function wpla_is_ip_range( $range ) {
	$parts = explode( '/', (string) $range, 2 );
	$ip    = filter_var( $parts[0], FILTER_VALIDATE_IP );
	if ( ! $ip ) {
		return false;
	}
	$max = false !== strpos( $ip, ':' ) ? 128 : 32;
	return ! isset( $parts[1] ) || ( ctype_digit( $parts[1] ) && (int) $parts[1] <= $max );
}

function wpla_register_settings() {
	register_setting(
		'wpla_settings',
		'wpla_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'wpla_sanitize_settings',
			'default'           => wpla_defaults(),
		)
	);
}

function wpla_field( $settings, $key, $label, $type = 'text', $description = '' ) {
	$value = $settings[ $key ];
	echo '<tr><th scope="row"><label for="wpla-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
	if ( 'textarea' === $type ) {
		$shown = 'suggestions' === $key ? str_replace( '|', "\n", $value ) : $value;
		echo '<textarea class="large-text" rows="3" id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']">' . esc_textarea( $shown ) . '</textarea>';
	} else {
		echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '" />';
	}
	if ( $description ) {
		echo '<p class="description">' . esc_html( $description ) . '</p>';
	}
	echo '</td></tr>';
}

function wpla_select_field( $settings, $key, $label, $choices ) {
	echo '<tr><th scope="row"><label for="wpla-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']">';
	foreach ( $choices as $value => $text ) {
		echo '<option value="' . esc_attr( $value ) . '" ' . selected( $settings[ $key ], $value, false ) . '>' . esc_html( $text ) . '</option>';
	}
	echo '</select></td></tr>';
}

function wpla_regenerate_preview() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accesso negato.', 'wpla-lead-assistant' ) );
	}
	check_admin_referer( 'wpla_regenerate_preview' );
	update_option( 'wpla_preview_token', wp_generate_password( 40, false, false ), false );
	wp_safe_redirect( wpla_admin_url( 'wpla-appearance', array( 'tab' => 'where' ) ) );
	exit;
}
