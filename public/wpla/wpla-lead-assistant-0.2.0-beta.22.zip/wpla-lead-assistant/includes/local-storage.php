<?php
/** Private knowledge, leads and counters. No uploaded document is exposed in the media library. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_local_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}wpla_sources (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		source_key varchar(191) NOT NULL,
		post_id bigint(20) unsigned NOT NULL DEFAULT 0,
		kind varchar(20) NOT NULL,
		title text NOT NULL,
		url text NOT NULL,
		content longtext NOT NULL,
		content_hash varchar(64) NOT NULL,
		analysis longtext NOT NULL,
		analysis_error text NOT NULL,
		enabled tinyint(1) NOT NULL DEFAULT 1,
		exclusion_reason varchar(20) NOT NULL DEFAULT '',
		updated_at datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY source_key (source_key),
		KEY post_id (post_id)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}wpla_leads (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		session_hash varchar(64) NOT NULL,
		payload longtext NOT NULL,
		delivery varchar(20) NOT NULL DEFAULT 'pending',
		created_at datetime NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY session_hash (session_hash)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}wpla_counters (
		bucket varchar(64) NOT NULL,
		hits bigint(20) unsigned NOT NULL DEFAULT 0,
		expires bigint(20) unsigned NOT NULL,
		PRIMARY KEY  (bucket),
		KEY expires (expires)
	) $charset;"
	);
	dbDelta(
		"CREATE TABLE {$wpdb->prefix}wpla_sessions (
		session_hash varchar(64) NOT NULL,
		payload longtext NOT NULL,
		expires bigint(20) unsigned NOT NULL,
		PRIMARY KEY  (session_hash),
		KEY expires (expires)
	) $charset;"
	);
	update_option( 'wpla_local_schema', '4', false );
	if ( ! wp_next_scheduled( 'wpla_local_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpla_local_cleanup' );
	}
}

function wpla_local_maybe_install() {
	if ( '4' !== get_option( 'wpla_local_schema' ) ) {
		wpla_local_install();
	}
	if ( ! wp_next_scheduled( 'wpla_local_cleanup' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpla_local_cleanup' );
	}
}

function wpla_local_cleanup() {
	global $wpdb;
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}wpla_counters WHERE expires < %d", time() ) );
	$ok = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}wpla_sessions WHERE expires < %d", time() ) ) && $ok;
	// Undelivered leads stay until the owner resends or deletes them: the owner may never have seen them.
	$days = (int) wpla_get_settings()['lead_retention_days'];
	$ok   = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}wpla_leads WHERE delivery = 'accepted' AND created_at < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) ) && $ok;
	if ( $ok ) {
		update_option( 'wpla_cleanup_last_run', time(), false );
	}
}

/** Late when the event is missing, or 48 hours have passed since the last successful run (or, before the first one, since it was due). */
function wpla_cleanup_status() {
	$next      = wp_next_scheduled( 'wpla_local_cleanup' );
	$last      = (int) get_option( 'wpla_cleanup_last_run', 0 );
	$reference = $last ?: (int) $next;
	return array(
		'last' => $last,
		'late' => ! $next || $reference < time() - 2 * DAY_IN_SECONDS,
	);
}

/** Delete one lead and the retries scheduled for it. Used by the panel and by the privacy eraser. */
function wpla_local_delete_lead( $id ) {
	global $wpdb;
	$deleted = (bool) $wpdb->delete( $wpdb->prefix . 'wpla_leads', array( 'id' => $id ) );
	wp_clear_scheduled_hook( 'wpla_local_retry', array( $id ) );
	return $deleted;
}

/** Keep visitor history out of object caches so retention and uninstall are deterministic. */
function wpla_local_history( $key ) {
	global $wpdb;
	$json = $wpdb->get_var( $wpdb->prepare( "SELECT payload FROM {$wpdb->prefix}wpla_sessions WHERE session_hash = %s AND expires > %d", $key, time() ) );
	return $json ? ( json_decode( $json, true ) ?: array() ) : array();
}

function wpla_local_save_history( $key, $history ) {
	global $wpdb;
	return $wpdb->replace(
		$wpdb->prefix . 'wpla_sessions',
		array(
			'session_hash' => $key,
			'payload'      => wp_json_encode( array_slice( $history, -12 ) ),
			'expires'      => time() + DAY_IN_SECONDS,
		)
	);
}

function wpla_local_delete_history( $key ) {
	global $wpdb;
	$wpdb->delete( $wpdb->prefix . 'wpla_sessions', array( 'session_hash' => $key ) );
}

/** Use the existing one-day sessions to surface real unanswered questions to admins. */
function wpla_local_redact_question( $question ) {
	$question = preg_replace( '~https?://\S+~iu', '[link]', $question );
	$question = preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu', '[email]', $question );
	$question = preg_replace( '/(?<![\p{L}\p{N}])\+?\d(?:[\d\s().-]{5,}\d)(?![\p{L}\p{N}])/u', '[numero]', $question );
	return sanitize_text_field( $question );
}

function wpla_local_unanswered_questions() {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT payload FROM {$wpdb->prefix}wpla_sessions WHERE expires > %d ORDER BY expires DESC LIMIT 500", time() ), ARRAY_A );
	$items = array();
	foreach ( $rows as $row ) {
		$history  = json_decode( $row['payload'], true );
		$question = '';
		foreach ( is_array( $history ) ? $history : array() as $message ) {
			if ( ! is_array( $message ) ) {
				continue;
			}
			if ( 'user' === ( $message['role'] ?? '' ) && is_string( $message['text'] ?? null ) ) {
				$question = $message['text'];
			} elseif ( 'assistant' === ( $message['role'] ?? '' ) ) {
				if ( $question && in_array( $message['diagnostic'] ?? '', array( 'retrieval_empty', 'retrieval_unavailable', 'citation_invalid', 'number_unverified', 'provider_format', 'unsupported_action' ), true ) ) {
					$visible          = wpla_local_redact_question( $question );
					$retrieval_status = in_array( $message['retrieval_status'] ?? '', array( 'selection_index_limit', 'selection_index_empty', 'selection_failed', 'selection_budget', 'selection_empty', 'query_empty' ), true ) ? $message['retrieval_status'] : '';
					$key              = hash( 'sha256', $visible . "\n" . $message['diagnostic'] . "\n" . $retrieval_status );
					if ( ! isset( $items[ $key ] ) ) {
						$items[ $key ] = array(
							'question'         => $visible,
							'diagnostic'       => $message['diagnostic'],
							'retrieval_status' => $retrieval_status,
							'count'            => 0,
						);
					}
					++$items[ $key ]['count'];
				}
				$question = '';
			}
		}
	}
	return array_slice( array_values( $items ), 0, 50 );
}

function wpla_sources( $enabled_only = false, $metadata_only = false ) {
	global $wpdb;
	$where   = $enabled_only ? ' WHERE enabled = 1' : '';
	$columns = $metadata_only ? 'id, post_id, kind, title, url, content_hash, analysis, enabled, updated_at' : '*';
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $columns and $where are fixed strings chosen above, no input.
	return $wpdb->get_results( "SELECT $columns FROM {$wpdb->prefix}wpla_sources$where ORDER BY id ASC", ARRAY_A );
}

/** Fingerprint of a source: the scan and the change hooks must compute it the same way. */
function wpla_source_hash( $title, $url, $content ) {
	return hash( 'sha256', $title . "\n" . $url . "\n" . $content );
}

function wpla_source_put( $key, $kind, $title, $url, $content, $post_id = 0 ) {
	global $wpdb;
	$table = $wpdb->prefix . 'wpla_sources';
	$old   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE source_key = %s', $table, $key ), ARRAY_A );
	$hash  = wpla_source_hash( $title, $url, $content );
	if ( $old && hash_equals( $old['content_hash'], $hash ) ) {
		return (int) $old['id'];
	}
	$row = array(
		'source_key'     => $key,
		'kind'           => $kind,
		'title'          => $title,
		'url'            => $url,
		'content'        => $content,
		'content_hash'   => $hash,
		'post_id'        => $post_id,
		'analysis'       => '',
		'analysis_error' => '',
		'updated_at'     => current_time( 'mysql', true ),
	);
	$ok  = $old ? $wpdb->update( $table, $row, array( 'id' => $old['id'] ) ) : $wpdb->insert( $table, $row );
	if ( false === $ok ) {
		return new WP_Error( 'source_write', 'Impossibile salvare la fonte.' );
	}
	delete_option( 'wpla_kb_draft' );
	return $old ? (int) $old['id'] : (int) $wpdb->insert_id;
}

function wpla_source_is_public( $row ) {
	if ( ! $row['post_id'] ) {
		return true;
	}
	$post = get_post( $row['post_id'] );
	if ( ! $post || ! is_post_publicly_viewable( $post ) || $post->post_password ) {
		return false;
	}
	if ( 'product' === $post->post_type && function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( $post->ID );
		return 'ecommerce' === wpla_get_settings()['workflow_mode'] && $product && $product->is_visible();
	}
	return true;
}

function wpla_current_sources( $document, $with_content = false ) {
	$valid = array();
	if ( ! is_array( $document ) || ( $document['mode'] ?? '' ) !== wpla_get_settings()['workflow_mode'] ) {
		return $valid;
	}
	foreach ( wpla_sources( true, ! $with_content ) as $row ) {
		if ( isset( $document['sources'][ $row['id'] ] ) && hash_equals( $document['sources'][ $row['id'] ], $row['content_hash'] ) && wpla_source_is_public( $row ) ) {
			$valid[ $row['id'] ] = $row;
		}
	}
	return $valid;
}
