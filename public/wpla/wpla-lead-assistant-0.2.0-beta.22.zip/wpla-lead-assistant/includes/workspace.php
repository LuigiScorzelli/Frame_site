<?php
/** Panel actions (admin-post and Ajax) and the lead and question lists shown by the panel pages. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_workspace_unanswered_questions() {
	$questions = wpla_local_unanswered_questions();
	echo '<section id="wpla-unanswered-questions">';
	echo '<p>Mostra fino a 50 domande distinte ancora presenti nelle sessioni conservate per un giorno; quelle inviate come lead o già scadute non compaiono. Email, link e numeri lunghi vengono mascherati. Il testo può comunque contenere dati personali: usalo solo per correggere le fonti e la chat.</p>';
	echo '<p><strong>' . esc_html( count( $questions ) . ' domande senza risposta nelle sessioni temporanee' ) . '</strong></p>';
	if ( ! $questions ) {
		echo '<p>Nessuna domanda senza risposta registrata nelle sessioni disponibili.</p>';
	} else {
		$test = wpla_admin_url( 'wpla-sources', array( 'tab' => 'test' ) );
		echo '<ol>';
		foreach ( $questions as $item ) {
			echo '<li><strong>' . esc_html( $item['question'] ) . '</strong> — <code>' . esc_html( $item['diagnostic'] ) . '</code>';
			if ( $item['retrieval_status'] ) {
				echo ' (<code>' . esc_html( $item['retrieval_status'] ) . '</code>)';
			}
			if ( $item['count'] > 1 ) {
				echo ' (' . esc_html( $item['count'] ) . ' volte)';
			}
			// POST, not a query string: the question may contain personal data and must not reach access logs.
			echo ' <form class="wpla-inline" method="post" action="' . esc_url( $test ) . '"><input type="hidden" name="wpla_question" value="' . esc_attr( $item['question'] ) . '" /><button type="submit" class="button-link" data-wpla-retry-question="' . esc_attr( $item['question'] ) . '">Prova nelle fonti</button></form></li>';
		}
		echo '</ol>';
	}
	echo '</section>';
}

function wpla_workspace_readiness( $s ) {
	$issues  = wpla_frontend_setup_issues( $s );
	$blocked = 'off' === $s['display_mode'] || $issues;
	?>
	<div id="wpla-readiness" class="notice inline <?php echo $blocked ? 'notice-warning' : 'notice-success'; ?>" role="status">
		<p><strong><?php echo $blocked ? 'La chat è nascosta.' : ( 'live' === $s['display_mode'] ? 'La chat è pronta per il pubblico.' : 'La chat è pronta per la prova riservata.' ); ?></strong></p>
		<?php
		if ( 'off' === $s['display_mode'] ) :
			?>
			<p>Qui sotto scegli “Solo prova” o “Pubblica” e premi “Salva la visibilità”.</p><?php endif; ?>
		<?php
		if ( $issues ) :
			?>
			<ul>
			<?php
			foreach ( $issues as $issue ) :
				?>
			<li><?php echo esc_html( $issue ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		<?php
		if ( 'all' !== $s['visibility'] ) :
			?>
			<p>È attivo un filtro sulle pagine. Controlla <a href="<?php echo esc_url( wpla_admin_url( 'wpla-appearance', array( 'tab' => 'where' ) ) ); ?>">Aspetto › Dove compare</a>: la chat compare solo dove consentito, oppure nelle pagine con il suo blocco o shortcode.</p><?php endif; ?>
		<?php if ( ! $blocked ) : ?>
			<p><?php echo 'test' === $s['display_mode'] ? 'I visitatori non la vedono: usa “Apri la chat di prova” qui sotto.' : 'Apri una pagina del sito e attendi circa 3 secondi. Se non compare, svuota la cache del sito e dell’eventuale CDN e ricarica la pagina.'; ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function wpla_workspace_fields( $operation ) {
	echo '<input type="hidden" name="action" value="wpla_workspace" /><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '" />';
	wp_nonce_field( 'wpla_workspace' );
	wpla_admin_return_field();
}

function wpla_workspace_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Accesso negato.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'wpla_workspace' );
	global $wpdb;
	$input     = wp_unslash( $_POST );
	$operation = sanitize_key( $input['operation'] ?? '' );
	$result    = true;
	$message   = 'Operazione completata.';
	switch ( $operation ) {
		case 'provider':
			$test_now = ! empty( $input['test_provider'] );
			$result   = $test_now ? wpla_ai_save_and_test( $input ) : wpla_ai_save( $input );
			$message  = $test_now ? 'Collegamento salvato. Il provider ha risposto correttamente.' : 'Collegamento salvato. Ora puoi provarlo.';
			$provider = wpla_ai_settings()['provider'];
			if ( defined( wpla_ai_key_constant( $provider ) ) ) {
				$message .= ' ' . wpla_ai_key_notice( $provider );
			}
			break;
		case 'limits':
			$result  = wpla_ai_save( array( 'daily_limit' => $input['daily_limit'] ?? '' ) );
			$message = 'Limiti salvati.';
			break;
		case 'test_provider':
			$result  = wpla_ai_connection_test();
			$message = 'Il provider ha risposto correttamente.';
			break;
		case 'discovery':
			$result  = wpla_save_discovery( $input );
			$message = 'Selezione salvata. Controlla il riepilogo, poi premi “Scansiona il sito”.';
			break;
		case 'upload':
			$result  = wpla_import_file( $_FILES['document'] ?? array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated by wpla_import_file(): is_uploaded_file(), size, type; the text is sanitized.
			$message = 'Testo importato. Controllalo nelle fonti prima di approvarlo.';
			break;
		case 'manual':
			$title   = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result  = $title && $content && strlen( $content ) <= 60000 ? wpla_source_put( 'manual:' . hash( 'sha256', wpla_text_lower( $title ) ), 'manual', $title, '', $content ) : new WP_Error( 'manual_invalid', 'Inserisci titolo e testo, entro 60 KB.' );
			break;
		case 'sources':
			$action  = sanitize_key( $input['source_action'] ?? '' );
			$result  = wpla_manage_sources( $action, $input['source_ids'] ?? array() );
			$message = is_wp_error( $result ) ? '' : $result . ' fonti aggiornate. Ricrea e approva la documentazione per pubblicare la nuova selezione.';
			if ( 'delete' === $action && ! is_wp_error( $result ) ) {
				$message .= ' Rimosse soltanto dal plugin. Le pagine torneranno con una nuova scansione; i documenti possono essere ricaricati.';
			}
			break;
		case 'source_edit':
			$id      = absint( $input['source_id'] ?? 0 );
			$row     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpla_sources WHERE id = %d AND post_id = 0", $id ), ARRAY_A );
			$title   = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result  = $row && $title && $content && strlen( $content ) <= 60000 ? wpla_source_put( $row['source_key'], $row['kind'], $title, '', $content ) : new WP_Error( 'source_edit_invalid', 'Fonte non modificabile o testo non valido. Inserisci titolo e contenuto entro 60 KB. Le pagine si modificano nell’editor WordPress.' );
			$message = 'Testo aggiornato. Ricrea e approva la documentazione.';
			break;
		case 'prompt':
		case 'publish':
			$save_only = 'prompt' === $operation || ! empty( $input['save_prompt'] ) || ! empty( $input['reset_prompt'] );
			if ( ! $save_only && empty( $input['approved'] ) ) {
				$result = new WP_Error( 'approval_missing', 'Conferma di aver controllato la documentazione e il prompt.' );
				break;
			}
			$result = isset( $input['document_version'] ) ? wpla_save_agent_prompt( $input ) : true;
			if ( ! is_wp_error( $result ) && ! $save_only ) {
				$result = wpla_publish_document();
			}
			$message = $save_only ? 'Prompt salvato in bozza. Controlla e approva per usarlo nella chat.' : 'Documentazione approvata. Prompt approvato. La visibilità della chat si sceglie in Panoramica.';
			break;
		case 'restore':
			$previous = get_option( 'wpla_kb_previous', array() );
			if ( empty( $previous['sources'] ) || count( wpla_current_sources( $previous ) ) !== count( $previous['sources'] ) ) {
				$result = new WP_Error( 'restore_stale', 'Le fonti della versione precedente sono cambiate. Ricrea la documentazione.' );
			} else {
				update_option( 'wpla_kb_previous', get_option( 'wpla_kb_published' ), false );
				update_option( 'wpla_kb_published', $previous, false );
				update_option(
					'wpla_agent_preferences',
					array(
						'system_prompt' => wpla_agent_prompt( $previous ),
						'prompt_custom' => ! empty( $previous['prompt_custom'] ),
					),
					false
				);
				delete_option( 'wpla_kb_draft' );
			}
			break;
		case 'download':
			$doc = get_option( 'wpla_kb_published', array() );
			nocache_headers();
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="documentazione-assistente.md"' );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/markdown attachment, not HTML; the content is the approved documentation.
			echo ( $doc['markdown'] ?? '' ) . ( $doc ? "\n# Prompt di sistema dell’agente\n\n" . wpla_agent_prompt( $doc ) . "\n" : '' );
			exit;
		case 'mail_test':
			$sent    = wpla_send_mail( wpla_mail_recipient(), '[TEST] Verifica email WP Lead Assistant', 'Questa email verifica l’invio delle notifiche del plugin. Non contiene dati di clienti.' );
			$result  = $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] );
			$message = 'Email di prova accettata dal servizio email per ' . $sent['recipient'] . '. Controlla la casella e lo spam: la consegna non è confermata dal plugin.';
			break;
		case 'resend_lead':
			$id = absint( $input['lead_id'] ?? 0 );
			$wpdb->update( $wpdb->prefix . 'wpla_leads', array( 'delivery' => 'pending' ), array( 'id' => $id ) );
			// The administrator explicitly requested another notification, even if previously accepted.
			$sent    = wpla_local_deliver( $id );
			$result  = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			$message = 'Nuovo invio accettato dal servizio email per ' . ( is_wp_error( $sent ) ? '' : $sent['recipient'] ) . '. Controlla la casella di destinazione.';
			break;
		case 'delete_lead':
			$id      = absint( $input['lead_id'] ?? 0 );
			$result  = wpla_local_delete_lead( $id ) ? true : new WP_Error( 'lead_missing', 'Richiesta non trovata.' );
			$message = 'Richiesta #' . $id . ' eliminata.';
			break;
		case 'retry_lead':
			$sent    = wpla_local_deliver( absint( $input['lead_id'] ?? 0 ) );
			$result  = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			$message = 'Tentativo accettato dal servizio email. Controlla lo stato e la casella di destinazione.';
			break;
		default:
			$result = new WP_Error( 'operation_invalid', 'Operazione non valida.' );
	}
	set_transient(
		'wpla_workspace_' . get_current_user_id(),
		array(
			'ok'      => ! is_wp_error( $result ),
			'message' => is_wp_error( $result ) ? $result->get_error_message() : $message,
		),
		MINUTE_IN_SECONDS
	);
	wp_safe_redirect( wpla_workspace_destination( $operation, $input ) );
	exit;
}

/** Home page of each operation (P6.16); the guided setup returns to its own step. */
function wpla_workspace_destination( $operation, $input ) {
	$map    = array(
		'provider'      => array( 'wpla-settings', array( 'tab' => 'provider' ), '' ),
		'test_provider' => array( 'wpla-settings', array( 'tab' => 'provider' ), '' ),
		'limits'        => array( 'wpla-settings', array( 'tab' => 'limits' ), '' ),
		'discovery'     => array( 'wpla-sources', array( 'tab' => 'scan' ), '#wpla-discovery-form' ),
		'upload'        => array( 'wpla-sources', array(), '#wpla-source-manager' ),
		'manual'        => array( 'wpla-sources', array(), '#wpla-source-manager' ),
		'sources'       => array( 'wpla-sources', array(), '#wpla-source-manager' ),
		'source_edit'   => array( 'wpla-sources', array(), '#wpla-source-manager' ),
		'prompt'        => array( 'wpla-sources', array( 'tab' => 'docs' ), '#wpla-knowledge-review' ),
		'publish'       => array( 'wpla-sources', array( 'tab' => 'docs' ), '#wpla-knowledge-review' ),
		'restore'       => array( 'wpla-sources', array( 'tab' => 'docs' ), '' ),
		'mail_test'     => array( 'wpla-leads', array(), '#wpla-leads' ),
		'resend_lead'   => array( 'wpla-leads', array(), '#wpla-leads' ),
		'retry_lead'    => array( 'wpla-leads', array(), '#wpla-leads' ),
		'delete_lead'   => array( 'wpla-leads', array(), '#wpla-leads' ),
	);
	$target = $map[ $operation ] ?? array( 'wpla', array(), '' );
	return wpla_admin_return_url( $input, $target[0], $target[1], $target[2] );
}

function wpla_knowledge_ajax() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Accesso negato.' ), 403 );
	}
	check_ajax_referer( 'wpla_knowledge', 'nonce' );
	$operation = sanitize_key( $_POST['operation'] ?? '' );
	if ( 'scan' === $operation ) {
		$result = wpla_scan_batch( absint( $_POST['page'] ?? 1 ) );
	} elseif ( 'analyze' === $operation ) {
		$result = wpla_analyze_for_document( absint( $_POST['source_id'] ?? 0 ) );
	} elseif ( 'retrieval_test' === $operation ) {
		$query = sanitize_textarea_field( is_string( $_POST['query'] ?? null ) ? wp_unslash( $_POST['query'] ) : '' );
		if ( ! trim( $query ) || wpla_text_length( $query ) > 1000 ) {
			$result = new WP_Error( 'query_invalid', 'Scrivi una domanda entro 1000 caratteri.' );
		} else {
			$sources          = wpla_current_sources( get_option( 'wpla_kb_published', array() ), true );
			$chunks           = wpla_retrieve( $query, $sources );
			$retrieval_status = 'lexical';
			if ( ! empty( $_POST['assisted'] ) ) {
				$chunks = wpla_retrieve_assisted( $query, $sources, $chunks, $retrieval_status );
			}
			$result = array(
				'approved'         => count( $sources ),
				'retrieval_status' => $retrieval_status,
				'titles'           => array_values( array_unique( array_column( $chunks, 'title' ) ) ),
				'passages'         => array_map(
					static function ( $chunk ) {
						return array(
							'title' => $chunk['title'],
							'text'  => $chunk['text'],
						);
					},
					$chunks
				),
				'greeting'         => wpla_local_is_greeting( $query ),
				'overview'         => wpla_retrieval_is_overview( $query ),
			);
		}
	} elseif ( 'build' === $operation ) {
		$result = wpla_build_document();
		if ( ! is_wp_error( $result ) ) {
			$result = array( 'message' => 'Bozza pronta.' );
		}
	} else {
		$result = new WP_Error( 'operation_invalid', 'Operazione non valida.' );
	}
	if ( is_wp_error( $result ) ) {
		wp_send_json_error(
			array(
				'message' => $result->get_error_message(),
				'code'    => $result->get_error_code(),
			),
			400
		);
	}
	wp_send_json_success( $result );
}

function wpla_undelivered_leads() {
	global $wpdb;
	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpla_leads WHERE delivery <> 'accepted'" );
}

/** P3.13 (D-030): WP-Cron runs only with site visits or a real cron; without it retention and retries stop silently. */
function wpla_cron_warning() {
	if ( ! wpla_cleanup_status()['late'] ) {
		return;
	}
	$days     = (int) wpla_get_settings()['lead_retention_days'];
	$disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? ' In wp-config.php c’è DISABLE_WP_CRON: WordPress non avvia il cron da solo.' : ' WP-Cron parte solo quando qualcuno visita il sito.';
	echo '<div id="wpla-cron-warning" class="notice notice-warning"><p><strong>La pulizia automatica non va da più di 48 ore</strong>: le richieste consegnate non vengono cancellate dopo ' . esc_html( $days ) . ' giorni e i nuovi tentativi di invio non partono.' . esc_html( $disabled ) . ' Chiedi all’hosting un cron reale ogni 15 minuti su <code>' . esc_html( site_url( 'wp-cron.php' ) ) . '</code>.</p></div>';
}

function wpla_workspace_leads( $filter = '' ) {
	global $wpdb;
	// Undelivered leads first: they are kept until handled and must never fall outside the list.
	$where = 'undelivered' === $filter ? " WHERE delivery <> 'accepted'" : '';
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is a fixed string chosen above, no input.
	$rows        = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpla_leads$where ORDER BY delivery = 'accepted', id DESC LIMIT 50", ARRAY_A );
	$undelivered = wpla_undelivered_leads();
	$total       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpla_leads" );
	echo '<section id="wpla-leads">';
	if ( $undelivered ) {
		echo '<div class="notice notice-warning inline"><p><strong>' . esc_html( 1 === $undelivered ? '1 richiesta non consegnata' : $undelivered . ' richieste non consegnate' ) . '</strong>: l’email non è stata accettata dal servizio email. Restano conservate finché non le rinvii o le elimini.</p></div>';
	}
	echo '<ul class="subsubsub"><li><a href="' . esc_url( wpla_admin_url( 'wpla-leads' ) ) . '"' . ( $filter ? '' : ' class="current" aria-current="page"' ) . '>Tutte <span class="count">(' . esc_html( $total ) . ')</span></a> |</li>';
	echo '<li><a href="' . esc_url( wpla_admin_url( 'wpla-leads', array( 'status' => 'undelivered' ) ) ) . '"' . ( $filter ? ' class="current" aria-current="page"' : '' ) . '>Non consegnate <span class="count">(' . esc_html( $undelivered ) . ')</span></a></li></ul>';
	echo '<p class="wpla-clear">Esportazione CSV ' . wp_kses_post( wpla_admin_soon( 'P6.9' ) ) . '</p>';
	if ( ! $rows ) {
		echo '<p>Nessuna richiesta da mostrare.</p>';
	}
	foreach ( $rows as $row ) {
		$p = json_decode( $row['payload'], true );
		echo '<details class="wpla-lead"><summary>#' . esc_html( $row['id'] . ' — ' . $row['created_at'] . ' — ' . $p['name'] . ' — ' . ( 'accepted' === $row['delivery'] ? 'accettata dal servizio email' : 'invio email da ritentare' ) ) . '</summary>';
		echo '<p>' . esc_html( $p['email'] . ' ' . $p['phone'] ) . '</p>';
		if ( ! empty( $p['mail'] ) ) {
			echo '<p>Ultimo destinatario: ' . esc_html( $p['mail']['recipient'] ) . '<br>Ultimo tentativo (UTC): ' . esc_html( $p['mail']['attempted_at'] ) . '</p>';
			if ( ! empty( $p['mail']['error'] ) ) {
				echo '<p class="wpla-source-error">' . esc_html( $p['mail']['error'] ) . '</p>';
			}
		} else {
			echo '<p>Dettagli del tentativo non registrati dalla versione precedente. Il prossimo invio li aggiornerà.</p>';
		}
		foreach ( $p['conversation'] as $m ) {
			echo '<p><strong>' . esc_html( $m['role'] ) . ':</strong> ' . esc_html( $m['text'] ) . '</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wpla_workspace_fields( 'accepted' === $row['delivery'] ? 'resend_lead' : 'retry_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( 'accepted' === $row['delivery'] ? 'Rinvia email della richiesta' : 'Riprova l’invio email', 'secondary', 'submit', false );
		echo '<p class="description">Invia al destinatario attuale indicato in “Dove arrivano”. Se il precedente messaggio era arrivato, riceverai una copia.</p></form>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Eliminare definitivamente questa richiesta?\');">';
		wpla_workspace_fields( 'delete_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( 'Elimina la richiesta', 'delete', 'submit', false );
		echo '</form></details>';
	}
	echo '</section>';
}
