<?php
/** The seven panel pages (D-036). Each function has one home page; the guided setup reuses the same sections. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Sections shared by the pages and the guided setup ---------- */

function wpla_section_business( $s, $with_privacy = false ) {
	?>
	<form id="wpla-business-form" method="post" action="options.php">
		<?php settings_fields( 'wpla_settings' ); ?>
		<table class="form-table" role="presentation">
			<?php
			wpla_select_field(
				$s,
				'workflow_mode',
				'Cosa offri?',
				array(
					'servizi'   => 'Servizi',
					'ecommerce' => 'Prodotti',
				)
			);
			wpla_field( $s, 'company', 'Nome dell’attività', 'text', 'Se vuoto, usa il nome del sito.' );
			wpla_field( $s, 'lead_email', 'Dove ricevere le richieste', 'email', 'Se vuoto, usa l’email dell’amministratore WordPress. Il destinatario effettivo è mostrato in Richieste.' );
			if ( $with_privacy ) {
				wpla_field( $s, 'privacy_url', 'Informativa privacy', 'url', 'Se vuoto, usa la pagina privacy di WordPress. Senza questo link la chat pubblica resta nascosta.' );
			}
			?>
		</table>
		<?php submit_button( 'Salva le scelte' ); ?>
	</form>
	<?php
}

function wpla_section_mode( $s ) {
	$choices = array(
		'off'  => array( 'Disattivata', 'Nessuno vede la chat.' ),
		'test' => array( 'Solo prova', 'La vedi tu e chi ha il link di anteprima.' ),
		'live' => array( 'Pubblica', 'La vedono tutti i visitatori.' ),
	);
	?>
	<form id="wpla-mode-form" method="post" action="options.php">
		<?php settings_fields( 'wpla_settings' ); ?>
		<fieldset class="wpla-mode"><legend class="screen-reader-text">Chi vede la chat</legend>
			<?php foreach ( $choices as $value => $choice ) : ?>
				<label class="wpla-mode-option"><input type="radio" name="wpla_settings[display_mode]" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['display_mode'], $value ); ?> /> <span><strong><?php echo esc_html( $choice[0] ); ?></strong><small><?php echo esc_html( $choice[1] ); ?></small></span></label>
			<?php endforeach; ?>
		</fieldset>
		<?php submit_button( 'Salva la visibilità', 'secondary', 'submit', false ); ?>
	</form>
	<?php
}

function wpla_section_open_chat( $s ) {
	$ready = ! wpla_frontend_setup_issues( $s );
	if ( 'test' === $s['display_mode'] && $ready ) {
		echo '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url(
			add_query_arg(
				array(
					'wpla_preview' => get_option( 'wpla_preview_token' ),
					'wpla'         => 'open',
				),
				home_url( '/' )
			)
		) . '">Apri la chat di prova</a></p>';
	} elseif ( 'live' === $s['display_mode'] && $ready ) {
		echo '<p><a class="button button-primary" target="_blank" rel="noopener noreferrer" href="' . esc_url( add_query_arg( 'wpla', 'open', home_url( '/' ) ) ) . '">Apri il sito con la chat</a></p>';
	} else {
		echo '<p>Approva la documentazione e scegli “Solo prova” per aprire la chat di prova. Quando hai verificato risposte e ricezione delle richieste, puoi scegliere “Pubblica”.</p>';
	}
}

function wpla_section_provider() {
	$ai = wpla_ai_settings();
	?>
	<p>Il consumo AI viene addebitato dal provider sul tuo conto. Le chiavi restano cifrate nel database del sito e non vengono mostrate nella chat. Se cambi le chiavi di sicurezza di WordPress, reinserisci le chiavi API.</p>
	<form id="wpla-provider-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wpla_workspace_fields( 'provider' ); ?>
		<input type="hidden" name="_consent_field" value="1" />
		<table class="form-table" role="presentation">
			<tr><th><label for="wpla-provider">Provider da usare</label></th><td><select id="wpla-provider" name="provider"><option value="openai" <?php selected( $ai['provider'], 'openai' ); ?>>OpenAI</option><option value="anthropic" <?php selected( $ai['provider'], 'anthropic' ); ?>>Anthropic</option></select></td></tr>
			<?php
			foreach ( array(
				'openai'    => 'OpenAI',
				'anthropic' => 'Anthropic',
			) as $provider => $label ) :
				?>
				<tr data-wpla-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="wpla-<?php echo esc_attr( $provider ); ?>-key">Chiave API <?php echo esc_html( $label ); ?></label></th><td>
					<input class="regular-text" id="wpla-<?php echo esc_attr( $provider ); ?>-key" type="password" name="<?php echo esc_attr( $provider ); ?>_key" value="" autocomplete="new-password" />
					<p class="description"><?php echo esc_html( wpla_ai_key_notice( $provider ) ); ?></p>
					<label><input type="checkbox" name="remove_<?php echo esc_attr( $provider ); ?>" value="1" /> Rimuovi la chiave salvata</label>
				</td></tr>
				<tr data-wpla-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="wpla-model-<?php echo esc_attr( $provider ); ?>">Modello <?php echo esc_html( $label ); ?></label></th><td><input class="regular-text" id="wpla-model-<?php echo esc_attr( $provider ); ?>" name="<?php echo esc_attr( $provider ); ?>_model" value="<?php echo esc_attr( $ai[ $provider . '_model' ] ); ?>" required /></td></tr>
			<?php endforeach; ?>
			<tr data-wpla-provider="anthropic" <?php echo 'anthropic' !== $ai['provider'] ? 'hidden' : ''; ?>><th><label for="wpla-workspace">Workspace Anthropic</label></th><td><input id="wpla-workspace" class="regular-text" name="workspace" value="<?php echo esc_attr( $ai['workspace'] ); ?>" /><p class="description">Facoltativo; necessario per alcune chiavi condivise tra workspace.</p></td></tr>
		</table>
		<p><label><input type="checkbox" name="consent" value="1" <?php checked( $ai['consent'] ); ?> /> Autorizzo l’invio al provider selezionato dei contenuti scelti e dei messaggi della chat per analisi e risposte.</label></p>
		<p id="wpla-provider-feedback" role="alert" hidden></p>
		<?php submit_button( 'Salva il collegamento', 'primary', 'submit', false ); ?>
		<?php submit_button( 'Salva e prova il collegamento AI', 'secondary', 'test_provider', false ); ?>
		<p class="description">Salva chiave, modello e autorizzazione, poi esegue una piccola richiesta sul tuo conto. Il numero di richieste AI al giorno si imposta in <a href="<?php echo esc_url( wpla_admin_url( 'wpla-settings', array( 'tab' => 'limits' ) ) ); ?>">Impostazioni › Limiti</a>.</p>
	</form>
	<?php
}

function wpla_section_scan() {
	wpla_render_discovery();
	?>
	<p><button type="button" class="button button-primary" id="wpla-scan" <?php disabled( ! is_array( get_option( 'wpla_discovery', false ) ) ); ?>>Scansiona il sito</button></p>
	<p id="wpla-progress" class="wpla-progress" role="status" aria-live="polite" tabindex="-1"></p>
	<?php
}

function wpla_section_upload() {
	?>
	<form id="wpla-upload-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wpla_workspace_fields( 'upload' ); ?>
		<p><label for="wpla-document">Documento aggiuntivo: TXT, MD, DOCX o PDF; massimo 3 MB e 60 KB di testo estratto.</label></p>
		<p><input id="wpla-document" type="file" name="document" accept=".txt,.md,.docx,.pdf" required /></p>
		<?php submit_button( 'Aggiungi documento', 'secondary', 'submit', false ); ?>
		<p class="description">I PDF vengono letti dal provider selezionato, con consumo API, in un’unica richiesta di massimo 25 secondi: nelle prove un PDF di 10 pagine di testo era già al limite, quindi dividi i documenti più lunghi in parti di poche pagine. Rivedi sempre il testo estratto. I file originali non vengono pubblicati nella libreria media. Le informazioni approvate potranno comparire nelle risposte ai visitatori: inserisci solo materiale adatto a questo uso. Per DOCX si importa il corpo del testo; per tabelle complesse, immagini, intestazioni o allegati preferisci un PDF e controllane l’estrazione.</p>
	</form>
	<?php
}

function wpla_section_manual() {
	?>
	<form id="wpla-manual-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wpla_workspace_fields( 'manual' ); ?>
		<p><label for="wpla-manual-title">Titolo</label><br><input id="wpla-manual-title" name="title" class="regular-text" required maxlength="200" /></p>
		<p><label for="wpla-manual-content">Informazioni approvate dall’attività</label><br><textarea id="wpla-manual-content" name="content" class="large-text" rows="5" required></textarea></p>
		<?php submit_button( 'Salva informazione', 'secondary', 'submit', false ); ?>
	</form>
	<?php
}

/** Analysis and draft: the source list comes from PHP because the source table is on another tab. */
function wpla_section_docs() {
	global $wpdb;
	$draft     = get_option( 'wpla_kb_draft', array() );
	$published = get_option( 'wpla_kb_published', array() );
	$included  = array_map(
		static function ( $row ) {
			return array(
				'id'    => (int) $row['id'],
				'title' => $row['title'],
			);
		},
		wpla_sources( true, true )
	);
	$errors    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpla_sources WHERE enabled = 1 AND analysis_error <> ''" );
	?>
	<p>Seleziona solo informazioni corrette. La ricostruzione analizza una fonte alla volta e prepara una bozza con riferimenti e citazioni verificabili. Le modifiche a una pagina ritirano subito la sua vecchia versione dalla chat: ripeti scansione, ricostruzione e approvazione per aggiornarla.</p>
	<?php wpla_render_analysis_exclusions( wpla_sources() ); ?>
	<p><strong><?php echo esc_html( count( $included ) . ' fonti incluse nella prossima bozza.' ); ?></strong> <a href="<?php echo esc_url( wpla_admin_url( 'wpla-sources' ) ); ?>">Controlla le fonti</a></p>
	<p><button type="button" class="button button-primary" id="wpla-generate" data-wpla-sources="<?php echo esc_attr( wp_json_encode( $included ) ); ?>">Ricrea la documentazione</button></p>
	<div id="wpla-generate-progress" class="wpla-progress" role="status" aria-live="polite" tabindex="-1"></div>
	<p><a class="button" id="wpla-select-errors" href="<?php echo esc_url( wpla_admin_url( 'wpla-sources', array( 'state' => 'error' ) ) . '#wpla-source-manager' ); ?>" <?php echo $errors ? '' : 'hidden'; ?>>Seleziona le fonti da correggere</a></p>
	<p class="description">L’analisi usa tutte le fonti incluse, anche quelle nascoste dai filtri. Le fonti senza contenuto utile o con risposte di analisi non utilizzabili vengono escluse automaticamente e conservate con il motivo. L’analisi prosegue e apre la bozza con le fonti utili. Se nessuna fonte è utilizzabile, non viene creata una bozza vuota. Errori di connessione, credenziali o quota richiedono un nuovo tentativo senza scartare le fonti.</p>
	<?php if ( ! empty( $draft['markdown'] ) ) : ?>
		<section id="wpla-knowledge-review" tabindex="-1" aria-labelledby="wpla-review-title">
			<h2 id="wpla-review-title">Bozza da approvare</h2>
			<p>La bozza è pronta. Controlla il testo qui sotto, poi seleziona la casella di conferma e premi “Approva la documentazione”. Finché non approvi, queste informazioni non vengono pubblicate per la chat.</p>
			<textarea class="large-text code" rows="14" readonly aria-label="Bozza della documentazione"><?php echo esc_textarea( $draft['markdown'] ); ?></textarea>
			<?php wpla_render_agent_editor( $draft ); ?>
		</section>
	<?php endif; ?>
	<?php
	if ( empty( $draft['markdown'] ) && ! empty( $published['markdown'] ) ) {
		wpla_render_agent_editor( $published, false ); }
	?>
	<?php if ( ! empty( $published['markdown'] ) ) : ?>
		<h2>Documentazione approvata</h2>
		<p>Documentazione approvata: <?php echo esc_html( $published['created_at'] ); ?>. Fonti attualmente utilizzabili: <?php echo esc_html( count( wpla_current_sources( $published ) ) . '/' . count( $published['sources'] ) ); ?>.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_workspace_fields( 'download' ); ?><?php submit_button( 'Scarica la documentazione (.md)', 'secondary', 'submit', false ); ?></form>
	<?php endif; ?>
	<?php if ( get_option( 'wpla_kb_previous' ) ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_workspace_fields( 'restore' ); ?><?php submit_button( 'Ripristina la documentazione precedente', 'secondary', 'submit', false ); ?></form>
	<?php endif; ?>
	<?php
}

function wpla_section_mail_test() {
	echo '<p><strong>Destinatario effettivo: <span id="wpla-mail-recipient">' . esc_html( wpla_mail_recipient() ) . '</span></strong> — ' . ( wpla_get_settings()['lead_email'] ? 'indirizzo scelto in <a href="' . esc_url( wpla_admin_url( 'wpla-settings' ) ) . '">Impostazioni › Attività</a>' : 'email amministratore nelle impostazioni generali WordPress' ) . '.</p>';
	echo '<p>Se la richiesta compare qui, è stata registrata. Se l’email non arriva, verifica il destinatario, la cartella spam e la configurazione della posta del sito. La prova usa lo stesso sistema delle notifiche. Dopo aver corretto la posta puoi rinviare una richiesta registrata.</p>';
	echo '<form id="wpla-mail-test" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wpla_workspace_fields( 'mail_test' );
	submit_button( 'Invia email di prova', 'secondary', 'submit', false );
	echo '</form>';
}

/* ---------- Panoramica ---------- */

function wpla_page_overview() {
	global $wpdb;
	$s = wpla_get_settings();
	wpla_admin_open( 'wpla', 'Lo stato della chat e le cose che richiedono la tua attenzione.' );
	wpla_cron_warning();
	$draft     = get_option( 'wpla_kb_draft', array() );
	$published = get_option( 'wpla_kb_published', array() );
	$recent    = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpla_leads ORDER BY id DESC LIMIT 3", ARRAY_A );
	$month     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}wpla_leads WHERE created_at >= %s", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) );
	?>
	<div class="wpla-grid">
		<section class="wpla-card wpla-card-wide" aria-labelledby="wpla-state-title">
			<h2 id="wpla-state-title">Stato della chat</h2>
			<?php wpla_workspace_readiness( $s ); ?>
			<?php if ( ! $s['privacy_url'] && ! get_privacy_policy_url() ) : ?>
				<p class="wpla-error">Manca l’informativa privacy: la chat pubblica resta nascosta. <a href="<?php echo esc_url( wpla_admin_url( 'wpla-settings', array( 'tab' => 'privacy' ) ) ); ?>">Imposta il link</a>.</p>
			<?php endif; ?>
			<?php wpla_section_mode( $s ); ?>
			<?php wpla_section_open_chat( $s ); ?>
			<p><a href="<?php echo esc_url( wpla_admin_url( 'wpla-appearance', array( 'tab' => 'where' ) ) ); ?>">Dove compare la chat</a></p>
		</section>
		<section class="wpla-card" aria-labelledby="wpla-check-title">
			<h2 id="wpla-check-title">Controllo iniziale <?php echo wp_kses_post( wpla_admin_soon( 'P6.1' ) ); ?></h2>
			<p>Prova del provider, email di prova e controlli del sito in un solo passaggio. Per ora: <a href="<?php echo esc_url( wpla_admin_url( 'wpla-settings', array( 'tab' => 'provider' ) ) ); ?>">prova il collegamento AI</a> e <a href="<?php echo esc_url( wpla_admin_url( 'wpla-leads' ) . '#wpla-mail-test' ); ?>">invia un’email di prova</a>.</p>
		</section>
		<section class="wpla-card" aria-labelledby="wpla-cost-title">
			<h2 id="wpla-cost-title">Costi del mese <?php echo wp_kses_post( wpla_admin_soon( 'P6.2' ) ); ?></h2>
			<p>La stima dei costi arriverà con P6.2. L’importo esatto è nel conto del provider.</p>
		</section>
		<section class="wpla-card" aria-labelledby="wpla-kb-title">
			<h2 id="wpla-kb-title">Documentazione</h2>
			<?php if ( ! empty( $draft['markdown'] ) ) : ?>
				<p><strong>Una bozza aspetta la tua approvazione.</strong></p>
			<?php endif; ?>
			<?php if ( ! empty( $published['markdown'] ) ) : ?>
				<ul class="wpla-stats">
					<li><strong><?php echo esc_html( count( wpla_current_sources( $published ) ) . ' su ' . count( $published['sources'] ) ); ?></strong> fonti approvate in uso</li>
					<li>Approvata il <strong><?php echo esc_html( wp_date( 'j/m/Y', strtotime( $published['created_at'] ) ) ); ?></strong></li>
				</ul>
			<?php else : ?>
				<p>Nessuna documentazione approvata.</p>
			<?php endif; ?>
			<p><a class="button" href="<?php echo esc_url( wpla_admin_url( 'wpla-sources', array( 'tab' => 'docs' ) ) ); ?>">Fonti e documentazione</a></p>
		</section>
		<section class="wpla-card" aria-labelledby="wpla-month-title">
			<h2 id="wpla-month-title">Ultimi 30 giorni</h2>
			<ul class="wpla-stats">
				<li><strong><?php echo esc_html( $month ); ?></strong> richieste di contatto</li>
				<li>Risposte con citazione <?php echo wp_kses_post( wpla_admin_soon( 'P6.9' ) ); ?></li>
			</ul>
			<p><a class="button" href="<?php echo esc_url( wpla_admin_url( 'wpla-questions' ) ); ?>">Domande senza risposta</a></p>
		</section>
		<section class="wpla-card wpla-card-wide" aria-labelledby="wpla-recent-title">
			<h2 id="wpla-recent-title">Ultime richieste</h2>
			<?php if ( ! $recent ) : ?>
				<p>Nessuna richiesta ricevuta.</p>
			<?php else : ?>
				<div class="wpla-scroll" tabindex="0" role="region" aria-label="Ultime richieste">
				<table class="widefat striped">
					<thead><tr><th scope="col">Data (UTC)</th><th scope="col">Nome</th><th scope="col">Email al titolare</th></tr></thead>
					<tbody>
					<?php
					foreach ( $recent as $row ) :
						$p = json_decode( $row['payload'], true );
						?>
						<tr><td><?php echo esc_html( $row['created_at'] ); ?></td><td><?php echo esc_html( $p['name'] ?? '' ); ?></td><td><?php echo 'accepted' === $row['delivery'] ? '<span class="wpla-pill wpla-pill-ok">Accettata</span>' : '<span class="wpla-pill wpla-pill-warn">Non consegnata</span>'; ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</div>
			<?php endif; ?>
			<p><a href="<?php echo esc_url( wpla_admin_url( 'wpla-leads' ) ); ?>">Tutte le richieste →</a></p>
		</section>
	</div>
	<?php
	wpla_admin_close();
}

/* ---------- Configurazione guidata ---------- */

function wpla_setup_steps() {
	$s         = wpla_get_settings();
	$ai        = wpla_ai_settings();
	$published = get_option( 'wpla_kb_published', array() );
	return array(
		1 => array( 'Attività', '' !== $s['company'] || '' !== $s['lead_email'] ),
		2 => array( 'Collegamento AI', $ai['consent'] && wpla_ai_key( $ai['provider'] ) ),
		3 => array( 'Contenuti', (bool) wpla_sources( false, true ) ),
		4 => array( 'Documentazione', ! empty( $published['markdown'] ) ),
		5 => array( 'Prova e pubblicazione', 'off' !== $s['display_mode'] ),
	);
}

function wpla_page_setup() {
	$step  = max( 1, min( 5, absint( $_GET['step'] ?? 1 ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	$steps = wpla_setup_steps();
	$s     = wpla_get_settings();
	wpla_admin_open( 'wpla-setup', 'Cinque passi per la prima installazione. Puoi ripeterla quando vuoi: ogni scelta si modifica anche dalla sua pagina.', array( (string) $step ) );
	echo '<ol class="wpla-steps" aria-label="Passi della configurazione">';
	foreach ( $steps as $n => $info ) {
		$class = $n === $step ? 'current' : ( $info[1] ? 'done' : '' );
		echo '<li class="' . esc_attr( $class ) . '"><a href="' . esc_url( wpla_admin_url( 'wpla-setup', array( 'step' => $n ) ) ) . '"' . ( $n === $step ? ' aria-current="step"' : '' ) . '><span class="wpla-step-n">' . esc_html( $n ) . '</span> ' . esc_html( $info[0] ) . ( $info[1] ? '<span class="screen-reader-text"> (fatto)</span>' : '' ) . '</a></li>';
	}
	echo '</ol><div class="wpla-wizard">';
	echo '<h2>' . esc_html( $step . '. ' . $steps[ $step ][0] ) . '</h2>';
	switch ( $step ) {
		case 1:
			wpla_section_business( $s, true );
			echo '<p class="description">Si modifica anche da <a href="' . esc_url( wpla_admin_url( 'wpla-settings' ) ) . '">Impostazioni › Attività</a> e <a href="' . esc_url( wpla_admin_url( 'wpla-settings', array( 'tab' => 'privacy' ) ) ) . '">Privacy e conservazione</a>.</p>';
			break;
		case 2:
			wpla_section_provider();
			break;
		case 3:
			wpla_section_scan();
			echo '<h3>Vuoi aggiungere un documento?</h3>';
			wpla_section_upload();
			echo '<p class="description">Informazioni manuali e gestione delle fonti in <a href="' . esc_url( wpla_admin_url( 'wpla-sources' ) ) . '">Fonti e documentazione</a>.</p>';
			break;
		case 4:
			wpla_section_docs();
			break;
		default:
			echo '<ol class="wpla-todo"><li>Invia un’email di prova per verificare che le richieste ti arrivino.';
			wpla_section_mail_test();
			echo '</li><li>Apri la chat di prova e fai qualche domanda come un cliente.';
			wpla_section_open_chat( $s );
			echo '</li><li>Quando sei soddisfatto, scegli chi può vedere la chat:';
			wpla_section_mode( $s );
			echo '</li></ol>';
	}
	echo '<div class="wpla-wizard-nav">';
	if ( $step > 1 ) {
		echo '<a class="button" href="' . esc_url( wpla_admin_url( 'wpla-setup', array( 'step' => $step - 1 ) ) ) . '">← Indietro</a>';
	}
	echo $step < 5
		? '<a class="button button-primary" href="' . esc_url( wpla_admin_url( 'wpla-setup', array( 'step' => $step + 1 ) ) ) . '">Avanti →</a>'
		: '<a class="button button-primary" href="' . esc_url( wpla_admin_url( 'wpla' ) ) . '">Vai alla panoramica</a>';
	echo '</div></div>';
	wpla_admin_close();
}

/* ---------- Fonti e documentazione ---------- */

function wpla_page_sources() {
	$tab = wpla_admin_open( 'wpla-sources', 'Cosa sa l’assistente e da dove lo prende. Nulla arriva ai visitatori senza la tua approvazione.' );
	switch ( $tab ) {
		case 'scan':
			wpla_section_scan();
			break;
		case 'files':
			echo '<div class="wpla-columns"><section class="wpla-card"><h2>Aggiungi un documento</h2>';
			wpla_section_upload();
			echo '</section><section class="wpla-card"><h2>Aggiungi o correggi un’informazione</h2>';
			wpla_section_manual();
			echo '</section></div>';
			break;
		case 'docs':
			echo '<h2>Modifiche da riapprovare ' . wp_kses_post( wpla_admin_soon( 'P6.4' ) ) . '</h2>';
			wpla_section_docs();
			break;
		case 'test':
			wpla_section_retrieval_test();
			break;
		default:
			$sources = wpla_sources();
			echo '<p id="wpla-progress" class="wpla-progress" role="status" aria-live="polite" tabindex="-1"></p>';
			wpla_render_analysis_exclusions( $sources );
			wpla_render_source_manager( $sources, get_option( 'wpla_kb_published', array() ) );
			echo '<p>Dopo aver cambiato le fonti, <a href="' . esc_url( wpla_admin_url( 'wpla-sources', array( 'tab' => 'docs' ) ) ) . '">ricrea e approva la documentazione</a>.</p>';
	}
	wpla_admin_close();
}

function wpla_section_retrieval_test() {
	// Prefilled by "Prova nelle fonti" with a POST, so the question text never lands in access logs.
	// It only fills the field: the check itself is an Ajax call with its own nonce.
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	$question = sanitize_textarea_field( is_string( $_POST['wpla_question'] ?? null ) ? wp_unslash( $_POST['wpla_question'] ) : '' );
	?>
	<section id="wpla-retrieval-check" aria-labelledby="wpla-retrieval-title">
		<h2 id="wpla-retrieval-title">Verifica quali fonti trova una domanda</h2>
		<p>La verifica locale mostra i brani scelti senza chiamare l’AI. Quando la ricerca locale è vuota o debole, la chat può selezionare fatti approvati; se questi non bastano, controlla anche i brani originali e cerca con termini alternativi. Puoi provare lo stesso percorso: nei casi difficili può consumare fino a sei richieste AI di ricerca e non verifica la risposta finale. Questa prova usa la domanda da sola: nella chat una domanda di seguito come «E quanto costa?» può riferirsi alla fonte citata prima oppure richiedere un chiarimento.</p>
		<form id="wpla-retrieval-form" class="wpla-inline-form">
			<label for="wpla-retrieval-query">Domanda di prova</label>
			<input id="wpla-retrieval-query" class="regular-text" required maxlength="1000" placeholder="Quali sono i vostri prodotti?" value="<?php echo esc_attr( $question ); ?>" />
			<label><input id="wpla-retrieval-assisted" type="checkbox" /> Prova anche la ricerca AI nelle fonti approvate</label>
			<button type="submit" class="button">Verifica le fonti</button>
		</form>
		<div id="wpla-retrieval-result" tabindex="-1" role="status" aria-live="polite"></div>
	</section>
	<?php
}

/* ---------- Richieste ---------- */

function wpla_page_leads() {
	$filter = 'undelivered' === sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ) ? 'undelivered' : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation, no state change.
	wpla_admin_open( 'wpla-leads', 'I contatti lasciati dai visitatori nella chat.' );
	wpla_workspace_leads( $filter );
	$days = (int) wpla_get_settings()['lead_retention_days'];
	$last = wpla_cleanup_status()['last'];
	?>
	<div class="wpla-columns">
		<section class="wpla-card" aria-labelledby="wpla-recipient-title">
			<h2 id="wpla-recipient-title">Dove arrivano</h2>
			<?php wpla_section_mail_test(); ?>
		</section>
		<section class="wpla-card" id="wpla-retention-summary" aria-labelledby="wpla-retention-title">
			<h2 id="wpla-retention-title">Per quanto le conserviamo</h2>
			<p>Le richieste accettate dal servizio email sono conservate per <?php echo esc_html( $days ); ?> giorni; la cancellazione programmata dipende dall’esecuzione di WP-Cron. Quelle non consegnate restano finché non le rinvii o le elimini. “Accettata dal servizio email” non garantisce la consegna in casella.</p>
			<p id="wpla-cleanup-last">Ultima pulizia automatica: <?php echo esc_html( $last ? wp_date( 'j F Y, H:i', $last ) : 'non ancora eseguita' ); ?>.</p>
			<p><a href="<?php echo esc_url( wpla_admin_url( 'wpla-settings', array( 'tab' => 'privacy' ) ) ); ?>">Cambia la conservazione</a> · Richieste di copia o cancellazione di un visitatore: <a href="<?php echo esc_url( admin_url( 'export-personal-data.php' ) ); ?>">Strumenti › Esporta dati personali</a> e <a href="<?php echo esc_url( admin_url( 'erase-personal-data.php' ) ); ?>">Cancella dati personali</a>.</p>
		</section>
	</div>
	<?php
	wpla_admin_close();
}

/* ---------- Domande senza risposta ---------- */

function wpla_page_questions() {
	wpla_admin_open( 'wpla-questions', 'Domande a cui la chat non ha saputo rispondere nelle sessioni dell’ultimo giorno. Ti dicono cosa manca nelle fonti.' );
	wpla_workspace_unanswered_questions();
	echo '<p>Bozza di FAQ da una domanda ' . wp_kses_post( wpla_admin_soon( 'P6.5' ) ) . '</p>';
	wpla_admin_close();
}

/* ---------- Aspetto ---------- */

function wpla_page_appearance() {
	$tab = wpla_admin_open( 'wpla-appearance', 'Come appare la chat e dove compare.' );
	$s   = wpla_get_settings();
	if ( 'widget' === $tab ) {
		echo '<div class="wpla-look"><div class="wpla-look-form">';
	}
	echo '<form id="wpla-appearance-form" method="post" action="options.php">';
	settings_fields( 'wpla_settings' );
	if ( 'where' === $tab ) {
		$pages = get_pages( array( 'sort_column' => 'post_title' ) );
		echo '<input type="hidden" name="wpla_settings[_visibility_form]" value="1" />';
		echo '<table class="form-table" role="presentation">';
		wpla_select_field(
			$s,
			'visibility',
			'Pagine',
			array(
				'all'     => 'Tutto il sito',
				'include' => 'Solo pagine selezionate',
				'exclude' => 'Tutto il sito, tranne le pagine selezionate',
			)
		);
		?>
		<tr><th scope="row"><label for="wpla-page-ids">Seleziona pagine</label></th><td>
			<select id="wpla-page-ids" name="wpla_settings[page_ids][]" multiple size="8" class="wpla-page-ids">
				<?php foreach ( $pages as $page ) : ?>
					<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( in_array( (int) $page->ID, $s['page_ids'], true ) ); ?>><?php echo esc_html( $page->post_title ?: '(senza titolo) #' . $page->ID ); ?></option>
				<?php endforeach; ?>
			</select><p class="description">Maiusc/Ctrl per selezioni multiple. Shortcode e blocco mostrano il widget anche fuori da queste regole.</p>
		</td></tr>
		<?php
		echo '</table>';
	} elseif ( 'contacts' === $tab ) {
		echo '<p>Mostrati quando la chat non può rispondere o il visitatore preferisce parlare con una persona.</p><table class="form-table" role="presentation">';
		wpla_field( $s, 'fallback_phone', 'Telefono di emergenza' );
		wpla_field( $s, 'fallback_email', 'Email di emergenza', 'email' );
		echo '<tr><th scope="row">WhatsApp ' . wp_kses_post( wpla_admin_soon( 'P6.6' ) ) . '</th><td></td></tr></table>';
	} else {
		echo '<table class="form-table" role="presentation">';
		wpla_field( $s, 'title', 'Titolo chat' );
		wpla_field( $s, 'color', 'Colore', 'text', 'Colore esadecimale scuro, ad esempio #0b4f8a: il testo sopra è bianco.' );
		wpla_select_field(
			$s,
			'position',
			'Posizione',
			array(
				'right' => 'Destra',
				'left'  => 'Sinistra',
			)
		);
		wpla_field( $s, 'welcome', 'Benvenuto', 'textarea', 'L’avviso che si tratta di un assistente AI resta sempre visibile.' );
		wpla_field( $s, 'suggestions', 'Domande suggerite', 'textarea', 'Una domanda per riga, massimo 8.' );
		wpla_field( $s, 'launcher_label', 'Testo pulsante chat' );
		echo '</table>';
	}
	submit_button( 'Salva le modifiche' );
	echo '</form>';
	if ( 'widget' === $tab ) {
		echo '</div>';
		wpla_widget_preview( $s );
		echo '</div>';
	}
	if ( 'where' === $tab ) {
		$preview = add_query_arg( 'wpla_preview', get_option( 'wpla_preview_token', '' ), home_url( '/' ) );
		?>
		<h2>Blocco e shortcode</h2>
		<p>Inserisci <code>[wpla_chat]</code> in una pagina o aggiungi il blocco “WP Lead Assistant” per mostrare la chat anche fuori da queste regole.</p>
		<h2>Link di anteprima</h2>
		<p>In modalità prova la chat è visibile solo agli amministratori e a chi ha questo link: <a href="<?php echo esc_url( $preview ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $preview ); ?></a></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Rigenerare il link? Quello vecchio smetterà di funzionare.');">
			<input type="hidden" name="action" value="wpla_regenerate_preview" />
			<?php wp_nonce_field( 'wpla_regenerate_preview' ); ?>
			<?php submit_button( 'Rigenera link di anteprima', 'secondary', 'submit', false ); ?>
		</form>
		<p>Chi vede la chat (disattivata, solo prova, pubblica) si sceglie in <a href="<?php echo esc_url( wpla_admin_url( 'wpla' ) ); ?>">Panoramica</a>.</p>
		<?php
	}
	wpla_admin_close();
}

/** Static preview of the widget, updated while typing; empty fields show the widget's own defaults. */
function wpla_widget_preview( $s ) {
	$company = $s['company'] ?: 'l’azienda';
	$welcome = 'Ciao! Sono l’assistente virtuale di ' . $company . ', un sistema di intelligenza artificiale. Rispondo usando le informazioni presenti su questo sito. Per richieste particolari posso metterti in contatto con una persona del nostro team.';
	?>
	<aside class="wpla-preview" aria-labelledby="wpla-preview-label">
		<p class="wpla-preview-label" id="wpla-preview-label">Anteprima</p>
		<div class="wpla-preview-site" id="wpla-preview" data-position="<?php echo esc_attr( $s['position'] ); ?>" style="--wpla-color:<?php echo esc_attr( $s['color'] ); ?>" aria-hidden="true">
			<div class="wpla-preview-chat">
				<div class="wpla-preview-head"><span data-wpla-out="title" data-default="Assistente virtuale"><?php echo esc_html( $s['title'] ?: 'Assistente virtuale' ); ?></span><small>Assistente AI · può sbagliare</small></div>
				<div class="wpla-preview-body">
					<p class="wpla-bubble" data-wpla-out="welcome" data-default="<?php echo esc_attr( $welcome ); ?>"><?php echo esc_html( $s['welcome'] ?: $welcome ); ?></p>
					<div class="wpla-chips" data-wpla-out="suggestions">
					<?php
					foreach ( array_filter( explode( '|', $s['suggestions'] ) ) as $suggestion ) :
						?>
						<span><?php echo esc_html( $suggestion ); ?></span><?php endforeach; ?></div>
				</div>
			</div>
			<span class="wpla-preview-launcher" data-wpla-out="launcher_label" data-default="Hai domande? Chiedi a me"><?php echo esc_html( $s['launcher_label'] ?: 'Hai domande? Chiedi a me' ); ?></span>
		</div>
		<p class="description">Indicativa: aspetto e testi definitivi si vedono con “Apri la chat di prova”.</p>
	</aside>
	<?php
}

/* ---------- Impostazioni ---------- */

function wpla_page_settings() {
	$tab = wpla_admin_open( 'wpla-settings' );
	$s   = wpla_get_settings();
	switch ( $tab ) {
		case 'provider':
			wpla_section_provider();
			break;
		case 'privacy':
			wpla_cron_warning();
			$last = wpla_cleanup_status()['last'];
			?>
			<form id="wpla-privacy-form" method="post" action="options.php">
				<?php settings_fields( 'wpla_settings' ); ?>
				<table class="form-table" role="presentation">
					<?php wpla_field( $s, 'privacy_url', 'Informativa privacy', 'url', 'Se vuoto, usa la pagina privacy di WordPress. Senza questo link la chat pubblica resta nascosta.' ); ?>
					<tr><th scope="row"><label for="wpla-lead_retention_days">Conserva le richieste consegnate per</label></th><td>
						<select id="wpla-lead_retention_days" name="wpla_settings[lead_retention_days]">
							<?php foreach ( wpla_retention_choices() as $choice ) : ?>
								<option value="<?php echo esc_attr( $choice ); ?>" <?php selected( (int) $s['lead_retention_days'], $choice ); ?>><?php echo esc_html( $choice . ' giorni' ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">Vale solo per le richieste accettate dal servizio email: quelle non consegnate restano finché non le rinvii o le elimini. La cancellazione programmata dipende da WP-Cron. Ultima pulizia automatica: <?php echo esc_html( $last ? wp_date( 'j F Y, H:i', $last ) : 'non ancora eseguita' ); ?>.</p>
					</td></tr>
					<tr><th scope="row">Richieste dei visitatori</th><td><p>Copia o cancellazione dei dati di un visitatore: <a href="<?php echo esc_url( admin_url( 'export-personal-data.php' ) ); ?>">Strumenti › Esporta dati personali</a> e <a href="<?php echo esc_url( admin_url( 'erase-personal-data.php' ) ); ?>">Strumenti › Cancella dati personali</a>, con l’email usata nel modulo. <a href="<?php echo esc_url( admin_url( 'options-privacy.php?tab=policyguide' ) ); ?>">Testo suggerito per l’informativa</a>.</p></td></tr>
				</table>
				<?php submit_button( 'Salva le modifiche' ); ?>
			</form>
			<?php
			break;
		case 'limits':
			$ai = wpla_ai_settings();
			?>
			<form id="wpla-limits-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wpla_workspace_fields( 'limits' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="wpla-daily-limit">Richieste AI al giorno</label></th><td><input id="wpla-daily-limit" class="small-text" type="number" min="1" max="1000" name="daily_limit" value="<?php echo esc_attr( $ai['daily_limit'] ); ?>" required /><p class="description">Include analisi, lettura PDF, prove e chat. Il pannello ne può usare al massimo il 70%: il resto è riservato alla chat. Imposta anche i limiti di spesa nel conto del provider.</p></td></tr>
					<tr><th scope="row">Tetto di spesa mensile <?php echo wp_kses_post( wpla_admin_soon( 'P6.2' ) ); ?></th><td></td></tr>
				</table>
				<?php submit_button( 'Salva i limiti' ); ?>
			</form>
			<?php
			break;
		case 'network':
			echo '<form id="wpla-network-form" method="post" action="options.php">';
			settings_fields( 'wpla_settings' );
			echo '<table class="form-table" role="presentation">';
			wpla_field( $s, 'trusted_proxies', 'Proxy fidati', 'textarea', 'Solo se il sito è dietro Cloudflare, un CDN o un reverse proxy: indirizzi o reti (es. 203.0.113.5 o 10.0.0.0/8), uno per riga. Per le richieste che arrivano da questi indirizzi i limiti per visitatore usano l’IP indicato in X-Forwarded-For. Lascia vuoto se non sai che cosa usa il tuo hosting.' );
			echo '</table>';
			submit_button( 'Salva le modifiche' );
			echo '</form>';
			break;
		default:
			wpla_section_business( $s );
	}
	wpla_admin_close();
}
