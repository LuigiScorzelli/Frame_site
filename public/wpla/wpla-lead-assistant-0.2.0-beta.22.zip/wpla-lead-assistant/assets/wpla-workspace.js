(function () {
  'use strict';
  // One script for every panel page (P6.16): each part starts only when its elements are on the page.
  var cfg = window.WPLA_WORKSPACE;
  if (!cfg) return;
  var page = document.querySelector('.wpla-admin');
  var progress = document.getElementById('wpla-progress');
  var scan = document.getElementById('wpla-scan');
  var generate = document.getElementById('wpla-generate');
  var generateProgress = document.getElementById('wpla-generate-progress');
  try {
    var scanResult = sessionStorage.getItem('wpla-scan-result');
    if (scanResult && progress) {
      progress.textContent = scanResult;
      sessionStorage.removeItem('wpla-scan-result');
    }
  } catch (error) { /* Discovery also works when browser storage is unavailable. */ }
  var review = document.getElementById('wpla-knowledge-review');
  if (review && window.location.hash === '#wpla-knowledge-review') {
    var showReview = function () {
      review.focus();
      review.scrollIntoView({ block: 'start' });
    };
    showReview();
    // Restored scroll positions can arrive after this script; show the draft again once the page is loaded.
    window.addEventListener('load', showReview, { once: true });
  }
  var provider = document.getElementById('wpla-provider');
  if (provider) {
    provider.addEventListener('change', function () {
      document.querySelectorAll('[data-wpla-provider]').forEach(function (row) {
        row.hidden = row.dataset.wplaProvider !== provider.value;
      });
    });
  }
  var providerForm = document.getElementById('wpla-provider-form');
  if (providerForm) {
    var consent = providerForm.querySelector('[name="consent"]');
    var feedback = document.getElementById('wpla-provider-feedback');
    providerForm.addEventListener('submit', function (event) {
      if (event.submitter && event.submitter.name === 'test_provider' && !consent.checked) {
        event.preventDefault();
        feedback.textContent = 'Per provare il collegamento, seleziona la casella “Autorizzo l’invio al provider selezionato…”.';
        feedback.hidden = false;
        consent.focus();
      }
    });
    consent.addEventListener('change', function () { feedback.hidden = true; });
  }

  function request(operation, values) {
    var body = new URLSearchParams(Object.assign({ action: 'wpla_knowledge', nonce: cfg.nonce, operation: operation }, values));
    return fetch(cfg.url, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (response) { return response.json(); })
      .then(function (response) {
        if (!response.success) {
          var error = new Error(response.data && response.data.message || 'Operazione non riuscita. Ricarica la pagina e riprova.');
          error.code = response.data && response.data.code;
          throw error;
        }
        return response.data;
      });
  }

  // Long operations lock the page they run on, so no other form is submitted halfway.
  function run(work, status) {
    var controls = page ? Array.from(page.querySelectorAll('input, button, select, textarea')) : [];
    var states = controls.map(function (control) { return control.disabled; });
    controls.forEach(function (control) { control.disabled = true; });
    work().catch(function (error) {
      status.textContent = error.message + (status === generateProgress ? ' La nuova bozza non è stata completata.' : '') + ' I passaggi già completati sono conservati. Puoi riprendere dopo aver risolto il problema.';
      status.focus();
      status.scrollIntoView({ block: 'center' });
    }).finally(function () {
      controls.forEach(function (control, index) { control.disabled = states[index]; });
    });
  }

  var manager = document.getElementById('wpla-source-manager');
  var rows = Array.from(document.querySelectorAll('.wpla-source'));

  function sourceAnalysisResult(row, message) {
    if (!row) return;
    row.dataset.state = message ? 'error' : 'ready';
    row.querySelector('.wpla-source-status').textContent = message ? 'Da correggere' : 'Analizzata';
    row.querySelector('.wpla-source-error').textContent = message || '';
  }

  if (manager) {
    var search = document.getElementById('wpla-source-search');
    var kind = document.getElementById('wpla-source-kind');
    var inclusion = document.getElementById('wpla-source-inclusion');
    var state = document.getElementById('wpla-source-state');
    var pageSize = document.getElementById('wpla-source-size');
    var selectPage = document.getElementById('wpla-source-select-page');
    var selectMatching = document.getElementById('wpla-source-select-matching');
    var clearSelection = document.getElementById('wpla-source-clear');
    var sourcePage = 1;
    var matching = rows;
    var visibleRows = [];

    var updateSelection = function () {
      var selected = rows.filter(function (row) { return row.querySelector('.wpla-source-check').checked; });
      var hidden = selected.filter(function (row) { return row.hidden; }).length;
      document.getElementById('wpla-source-selection').textContent = selected.length + ' selezionate' + (hidden ? ' (' + hidden + ' fuori dalla pagina visibile)' : '');
      var checked = visibleRows.filter(function (row) { return row.querySelector('.wpla-source-check').checked; }).length;
      selectPage.checked = visibleRows.length > 0 && checked === visibleRows.length;
      selectPage.indeterminate = checked > 0 && checked < visibleRows.length;
    };

    var filterSources = function (resetPage) {
      if (resetPage) sourcePage = 1;
      var query = search.value.toLocaleLowerCase().trim();
      matching = rows.filter(function (row) {
        return (!query || row.dataset.search.toLocaleLowerCase().includes(query)) &&
          (!kind.value || row.dataset.kind === kind.value) &&
          (!inclusion.value || row.dataset.enabled === inclusion.value) &&
          (!state.value || row.dataset.state === state.value);
      });
      var size = Number(pageSize.value);
      var pages = Math.max(1, Math.ceil(matching.length / size));
      sourcePage = Math.min(sourcePage, pages);
      visibleRows = matching.slice((sourcePage - 1) * size, sourcePage * size);
      rows.forEach(function (row) { row.hidden = !visibleRows.includes(row); });
      document.getElementById('wpla-source-empty').hidden = matching.length !== 0;
      document.getElementById('wpla-source-page').textContent = 'Pagina ' + sourcePage + ' di ' + pages + ' · ' + matching.length + ' risultati su ' + rows.length;
      document.getElementById('wpla-source-prev').disabled = sourcePage === 1;
      document.getElementById('wpla-source-next').disabled = sourcePage === pages;
      selectMatching.textContent = 'Seleziona tutti i risultati (' + matching.length + ')';
      updateSelection();
    };

    manager.querySelector('.wpla-source-filters').hidden = false;
    manager.querySelector('.wpla-source-pagination').hidden = false;
    selectMatching.hidden = clearSelection.hidden = false;
    [search, kind, inclusion, state, pageSize].forEach(function (control) {
      control.addEventListener(control === search ? 'input' : 'change', function () { filterSources(true); });
    });
    document.getElementById('wpla-source-prev').addEventListener('click', function () { sourcePage--; filterSources(false); });
    document.getElementById('wpla-source-next').addEventListener('click', function () { sourcePage++; filterSources(false); });
    rows.forEach(function (row) { row.querySelector('.wpla-source-check').addEventListener('change', updateSelection); });
    selectPage.addEventListener('change', function () {
      visibleRows.forEach(function (row) { row.querySelector('.wpla-source-check').checked = selectPage.checked; });
      updateSelection();
    });
    selectMatching.addEventListener('click', function () {
      matching.forEach(function (row) { row.querySelector('.wpla-source-check').checked = true; });
      updateSelection();
    });
    clearSelection.addEventListener('click', function () {
      rows.forEach(function (row) { row.querySelector('.wpla-source-check').checked = false; });
      updateSelection();
    });
    document.getElementById('wpla-sources-form').addEventListener('submit', function (event) {
      var count = rows.filter(function (row) { return row.querySelector('.wpla-source-check').checked; }).length;
      var feedback = document.getElementById('wpla-source-feedback');
      feedback.hidden = true;
      if (!count || count > 1000) {
        event.preventDefault();
        feedback.textContent = 'Seleziona da 1 a 1000 fonti prima di applicare un’azione.';
        feedback.hidden = false;
      } else if (this.elements.source_action.value === 'delete' && !window.confirm('Rimuovere dal plugin le ' + count + ' fonti selezionate, comprese quelle fuori dalla pagina visibile? Il sito originale resta intatto. La documentazione approvata che le contiene verrà ritirata.')) {
        event.preventDefault();
      }
    });
    document.querySelectorAll('.wpla-source-delete').forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!window.confirm('Rimuovere questa fonte dal plugin? Il sito originale resta intatto. La documentazione approvata che la contiene verrà ritirata.')) event.preventDefault();
      });
    });
    // "Seleziona le fonti da correggere" on the Documentation tab opens this list with the failed sources selected.
    if (new URLSearchParams(window.location.search).get('state') === 'error') {
      inclusion.value = '1';
      state.value = 'error';
      rows.forEach(function (row) { row.querySelector('.wpla-source-check').checked = row.dataset.enabled === '1' && row.dataset.state === 'error'; });
      document.querySelector('#wpla-sources-form [name="source_action"]').value = 'exclude';
      manager.focus();
    }
    filterSources(true);
  }

  var retrievalForm = document.getElementById('wpla-retrieval-form');
  if (retrievalForm) {
    var query = document.getElementById('wpla-retrieval-query');
    if (query.value) query.focus();
    retrievalForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var result = document.getElementById('wpla-retrieval-result');
      run(async function () {
        result.textContent = 'Verifica delle fonti approvate…';
        var data = await request('retrieval_test', { query: query.value, assisted: document.getElementById('wpla-retrieval-assisted').checked ? '1' : '' });
        var retrievalIssue = {
          selection_index_limit: 'L’indice dei fatti approvati supera il limite e la ricerca alternativa nei brani originali non ha trovato una risposta. La chat usa il risultato locale, se disponibile.',
          selection_index_empty: 'Nessuna citazione valida è disponibile nell’indice dei fatti approvati; anche la ricerca alternativa non ha trovato una risposta. Controlla l’analisi e il testo letto.',
          selection_failed: 'La selezione AI non è riuscita o non ha restituito riferimenti validi. Verifica il collegamento e la quota del provider, poi riprova.',
          selection_budget: 'Il tempo destinato alla ricerca assistita è esaurito. Riprova o controlla la risposta del provider.'
        }[data.retrieval_status];
        var found = data.titles.length ? (data.overview ? 'Panoramica del catalogo. ' : '') + 'Fonti trovate: ' + data.titles.join(' · ') : '';
        result.textContent = 'Fonti approvate utilizzabili: ' + data.approved + '. ' + (data.greeting ? 'Saluto riconosciuto: la chat risponde senza cercare fatti aziendali.' : (retrievalIssue ? retrievalIssue + (found ? ' ' + found : '') : (found || 'Nessuna fonte pertinente trovata. Controlla il testo letto e approva le informazioni necessarie.')));
        if (!data.greeting && data.passages && data.passages.length) {
          var list = document.createElement('ol');
          data.passages.forEach(function (passage) {
            var item = document.createElement('li');
            var details = document.createElement('details');
            var title = document.createElement('summary');
            var text = document.createElement('pre');
            title.textContent = passage.title;
            text.textContent = passage.text;
            text.style.whiteSpace = 'pre-wrap';
            details.appendChild(title);
            details.appendChild(text);
            item.appendChild(details);
            list.appendChild(item);
          });
          result.appendChild(list);
        }
      }, result);
    });
  }

  document.querySelectorAll('.wpla-discovery-search').forEach(function (input) {
    input.addEventListener('input', function () {
      var text = input.value.toLocaleLowerCase();
      input.closest('details').querySelectorAll('[data-discovery-title]').forEach(function (label) {
        label.hidden = !label.dataset.discoveryTitle.toLocaleLowerCase().includes(text);
      });
    });
  });
  var discoveryForm = document.getElementById('wpla-discovery-form');
  if (discoveryForm && scan) {
    discoveryForm.addEventListener('change', function (event) {
      if (event.target.type !== 'checkbox') return;
      scan.disabled = true;
      progress.textContent = 'La selezione è cambiata: premi “Salva la selezione e mostra il riepilogo” prima di scansionare.';
    });
  }

  // Aspetto › Widget: the preview follows the fields while the owner types.
  var preview = document.getElementById('wpla-preview');
  if (preview) {
    var out = function (key) { return preview.querySelector('[data-wpla-out="' + key + '"]'); };
    var live = function (key) {
      var field = document.getElementById('wpla-' + key);
      if (!field) return;
      var update = function () {
        var value = field.value.trim();
        if (key === 'color') {
          if (/^#[0-9a-f]{6}$/i.test(value)) preview.style.setProperty('--wpla-color', value);
        } else if (key === 'position') {
          preview.dataset.position = value;
        } else if (key === 'suggestions') {
          var chips = out('suggestions');
          chips.textContent = '';
          value.split(/[\r\n|]+/).map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 8).forEach(function (text) {
            var chip = document.createElement('span');
            chip.textContent = text;
            chips.appendChild(chip);
          });
        } else {
          out(key).textContent = value || out(key).dataset.default;
        }
      };
      field.addEventListener(field.tagName === 'SELECT' ? 'change' : 'input', update);
    };
    ['title', 'color', 'position', 'welcome', 'suggestions', 'launcher_label'].forEach(live);
  }

  var inSetup = new URLSearchParams(window.location.search).get('page') === 'wpla-setup';

  if (scan) {
    scan.addEventListener('click', function () {
      run(async function () {
        var pageNumber = 1;
        var count = 0;
        var warnings = [];
        var result;
        do {
          progress.textContent = 'Lettura del sito… ' + count + ' fonti importate.';
          result = await request('scan', { page: pageNumber++ });
          count += result.imported;
          warnings = warnings.concat(result.skipped);
        } while (!result.done);
        var message = 'Scansione terminata: ' + count + ' fonti importate o aggiornate.' + (warnings.length ? ' Fonti non importate: ' + warnings.join(' | ') : '');
        try { sessionStorage.setItem('wpla-scan-result', message); } catch (error) { /* The refreshed source list is still available. */ }
        if (inSetup) {
          window.location.reload();
        } else {
          window.location.href = cfg.sourcesUrl + '#wpla-source-manager';
        }
      }, progress);
    });
  }

  if (generate) {
    var selectErrors = document.getElementById('wpla-select-errors');
    generate.addEventListener('click', function () {
      run(async function () {
        // The source list comes from PHP: the source table is on another tab.
        var sources = JSON.parse(generate.dataset.wplaSources || '[]');
        if (!sources.length) throw new Error('Scansiona il sito o includi almeno una fonte.');
        var failures = [];
        for (var i = 0; i < sources.length; i++) {
          var title = sources[i].title;
          var row = document.querySelector('.wpla-source[data-source="' + sources[i].id + '"]');
          generateProgress.textContent = 'Analisi delle fonti: ' + (i + 1) + ' di ' + sources.length + ' — ' + title + '. ' + failures.length + ' escluse automaticamente. Lascia aperta questa pagina.';
          try {
            var analysis = await request('analyze', { source_id: sources[i].id });
            if (analysis.skipped) {
              failures.push({ title: title, message: analysis.message });
              sourceAnalysisResult(row, analysis.message);
            } else {
              sourceAnalysisResult(row, '');
            }
          } catch (error) {
            sourceAnalysisResult(row, error.message);
            if (selectErrors) selectErrors.hidden = false;
            throw new Error('Analisi interrotta sulla fonte “' + title + '”: ' + error.message + ' Le fonti non analizzate restano incluse; le altre analisi sono conservate.');
          }
        }
        generateProgress.textContent = 'Analisi terminata. Preparazione della bozza da approvare…';
        await request('build', {});
        // Without this the browser restores the old scroll position and hides the new draft.
        if ('scrollRestoration' in history) {
          history.scrollRestoration = 'manual';
        }
        window.location.hash = 'wpla-knowledge-review';
        window.location.reload();
      }, generateProgress);
    });
  }
})();
