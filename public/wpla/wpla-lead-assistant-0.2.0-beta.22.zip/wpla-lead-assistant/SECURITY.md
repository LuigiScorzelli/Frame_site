# Sicurezza — WP Lead Assistant

> Procedura in vigore dal 2026-10-26 (decisione D-031 in [DECISIONI.md](DECISIONI.md), attività P1.2 di [PIANO.md](PIANO.md)). Questo file è incluso nello zip del plugin da `build-zip.sh`; la sezione "Security" di `wp-plugin/readme.txt` ne riporta l'essenziale in inglese. Aggiornarli insieme quando cambiano il canale o le versioni supportate.

## Versioni supportate

Il plugin è in beta privata. Le correzioni di sicurezza escono solo sull'**ultima beta pubblicata**: gli utenti devono aggiornare a quella.

| Versione | Correzioni di sicurezza |
|---|---|
| Ultima `0.2.0-beta.N` | ✅ |
| Beta precedenti | ❌ (aggiornare all'ultima sostituendo lo zip, senza disinstallare) |

## Come segnalare una vulnerabilità

**Non aprire issue pubbliche e non pubblicare dettagli** finché la correzione non è disponibile.

Scrivi a: **security@aiframe.it** (casella dedicata, letta da Luigi Scorzelli, responsabile del plugin). Metti nell'oggetto "WP Lead Assistant" e la versione.

Indica, se puoi:

- versione del plugin, di WordPress e di PHP;
- descrizione del problema e del suo impatto (chi può fare cosa);
- passi per riprodurlo o una prova di concetto **senza dati reali di terzi**;
- se il problema è già noto ad altri o sfruttato.

Non includere chiavi API, password o dati personali di visitatori. Se servono per riprodurre il problema, descrivili senza copiarli.

## Cosa succede dopo

| Fase | Tempo indicativo |
|---|---|
| Conferma di ricezione | entro 3 giorni lavorativi |
| Prima valutazione (confermata / non riproducibile / fuori perimetro) | entro 10 giorni lavorativi |
| Correzione per i problemi gravi | appena possibile, con una nuova beta e un test di regressione |
| Comunicazione ai tester e nota nel changelog | con il rilascio della correzione |

Chi segnala viene ringraziato nel changelog, se lo desidera.

## Perimetro

**Dentro:** il codice in `wp-plugin/` e il widget `widget/src/wpla-widget.js` distribuito nello zip. Esempi:

- accesso non autorizzato al pannello o alle sue azioni;
- lettura di chiavi API, lead o conversazioni;
- elusione della modalità test o dei limiti di frequenza;
- risposte della chat che mostrano contenuti non approvati;
- XSS, SQL injection, CSRF.

**Fuori:**

- i workflow demo in `n8n-templates/` e i siti in `widget/demo/` (non distribuiti);
- configurazioni dell'hosting del titolare;
- vulnerabilità di WordPress, WooCommerce o dei provider AI (vanno segnalate ai rispettivi progetti);
- limiti già documentati in [ARCHITETTURA.md](ARCHITETTURA.md) §5, ad esempio i limiti per IP dietro un proxy non indicato tra i proxy fidati.

## Misure in essere

Il riepilogo completo è in [ARCHITETTURA.md](ARCHITETTURA.md) §6.

- Chiavi API cifrate sul server (AES-256-GCM); non arrivano mai al browser.
- Un solo endpoint pubblico (`POST /wp-json/wpla/v1/chat`), con controllo dell'origine, limiti per IP e per sito, dimensione massima e token in modalità test.
- Azioni amministrative protette da `manage_options` e nonce; query preparate; escape dell'output.
- Fonti e conversazioni trattate come dati non fidati nei prompt; risposte accettate solo con citazioni verificate.
- Ricerca di segreti (gitleaks) a ogni push.
