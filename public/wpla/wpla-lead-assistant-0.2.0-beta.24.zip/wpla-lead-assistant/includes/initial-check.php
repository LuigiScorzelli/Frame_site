<?php
/**
 * One-click initial check (P6.1): AI key and model, test email, WP-Cron, HTTPS and privacy page.
 * Each check says what to do and links to the page where it is fixed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * True when wp-config.php disables WP-Cron. The override exists for the tests: the CI stack defines the constant.
 *
 * @param bool|null $override Value to use instead of the constant; null restores the constant.
 */
function wpla_cron_disabled( $override = null ) {
	static $forced = null;
	if ( func_num_args() ) {
		$forced = $override;
	}
	return null !== $forced ? (bool) $forced : ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );
}

/** Run every check, store the result (not autoloaded) and return it. */
function wpla_initial_check_run() {
	$loopback = wpla_cron_disabled() ? null : wpla_initial_check_loopback();
	$result   = array(
		'at'    => time(),
		'items' => array(
			wpla_initial_check_ai(),
			wpla_initial_check_mail(),
			wpla_initial_check_cron( $loopback ),
			wpla_initial_check_https( $loopback ),
			wpla_initial_check_privacy(),
		),
	);
	update_option( 'wpla_initial_check', $result, false );
	return $result;
}

/** One result row: ok, warning or error, what it means and where to fix it. */
function wpla_initial_check_item( $id, $label, $status, $message, $fix_url = '', $fix_label = '' ) {
	return array(
		'id'        => $id,
		'label'     => $label,
		'status'    => $status,
		'message'   => $message,
		'fix_url'   => $fix_url,
		'fix_label' => $fix_label,
	);
}

function wpla_initial_check_ai() {
	$label = 'Chiave API e modello';
	$fix   = wpla_admin_url( 'wpla-settings', array( 'tab' => 'provider' ) );
	// At the cap the chat already uses the contact form: a test call would only add to the bill (P6.2).
	if ( wpla_cost_cap_reached() ) {
		return wpla_initial_check_item( 'ai', $label, 'warning', 'Prova saltata: il tetto di spesa mensile è raggiunto e la chat passa al modulo contatti. Alza il tetto o attendi il mese prossimo, poi ripeti il controllo.', wpla_admin_url( 'wpla-settings', array( 'tab' => 'limits' ) ), 'Limiti' );
	}
	$s      = wpla_ai_settings();
	$result = wpla_ai_connection_test();
	if ( is_wp_error( $result ) ) {
		return wpla_initial_check_item( 'ai', $label, 'error', $result->get_error_message(), $fix, 'Provider AI' );
	}
	$name  = 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic';
	$model = 'openai' === $s['provider'] ? $s['openai_model'] : $s['anthropic_model'];
	return wpla_initial_check_item( 'ai', $label, 'ok', $name . ' ha risposto con il modello ' . $model . '. La prova costa pochi token, contati nei costi del mese.' );
}

function wpla_initial_check_mail() {
	$sent = wpla_send_mail( wpla_mail_recipient(), '[TEST] Controllo iniziale WP Lead Assistant', 'Questa email verifica l’invio delle notifiche del plugin. Non contiene dati di clienti.' );
	if ( ! $sent['accepted'] ) {
		return wpla_initial_check_item( 'mail', 'Email delle richieste', 'error', $sent['error'], wpla_admin_url( 'wpla-settings' ), 'Dove ricevere le richieste' );
	}
	return wpla_initial_check_item( 'mail', 'Email delle richieste', 'ok', 'Email di prova accettata dal servizio email per ' . $sent['recipient'] . '. Controlla la casella e lo spam: il plugin non può confermare la consegna.' );
}

/** The site calls its own wp-cron.php, as WordPress does after a visit, checking the certificate too. */
function wpla_initial_check_loopback() {
	return wp_remote_get(
		site_url( 'wp-cron.php' ),
		array(
			'timeout'   => 5,
			'sslverify' => true,
		)
	);
}

function wpla_initial_check_is_ssl_error( $response ) {
	return is_wp_error( $response ) && (bool) preg_match( '/SSL|certificate|cURL error (?:35|51|58|60)\b/i', $response->get_error_message() );
}

function wpla_initial_check_cron( $loopback ) {
	$label = 'Pulizia automatica (WP-Cron)';
	$url   = site_url( 'wp-cron.php' );
	if ( ! wp_next_scheduled( 'wpla_local_cleanup' ) ) {
		return wpla_initial_check_item( 'cron', $label, 'error', 'La pulizia automatica non è in programma: le richieste consegnate non vengono cancellate e i nuovi tentativi di invio non partono. Disattiva e riattiva il plugin per programmarla di nuovo.', admin_url( 'plugins.php' ), 'Plugin' );
	}
	if ( wpla_cleanup_status()['late'] ) {
		return wpla_initial_check_item( 'cron', $label, 'error', 'La pulizia automatica non va da più di 48 ore. Chiedi all’hosting un cron reale ogni 15 minuti su ' . $url . '.' );
	}
	if ( wpla_cron_disabled() ) {
		return wpla_initial_check_item( 'cron', $label, 'warning', 'In wp-config.php c’è DISABLE_WP_CRON: WordPress non avvia il cron da solo. Serve un cron reale dell’hosting ogni 15 minuti su ' . $url . '.' );
	}
	// WordPress itself calls wp-cron.php without checking the certificate: a certificate problem belongs to the HTTPS check.
	if ( ( is_wp_error( $loopback ) && ! wpla_initial_check_is_ssl_error( $loopback ) ) || ( ! is_wp_error( $loopback ) && wp_remote_retrieve_response_code( $loopback ) >= 400 ) ) {
		return wpla_initial_check_item( 'cron', $label, 'warning', 'Il sito non riesce a chiamare se stesso: WP-Cron potrebbe non partire dopo le visite. Chiedi all’hosting un cron reale ogni 15 minuti su ' . $url . '.' );
	}
	return wpla_initial_check_item( 'cron', $label, 'ok', 'La pulizia è in programma e il sito riesce ad avviare WP-Cron.' );
}

function wpla_initial_check_https( $loopback ) {
	$label = 'HTTPS';
	if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) || 'https' !== wp_parse_url( site_url(), PHP_URL_SCHEME ) ) {
		return wpla_initial_check_item( 'https', $label, 'error', 'L’indirizzo del sito non usa https: i dati lasciati nel modulo contatti viaggiano in chiaro. Attiva il certificato dall’hosting, poi imposta gli indirizzi con https in Impostazioni › Generali.', admin_url( 'options-general.php' ), 'Impostazioni generali' );
	}
	if ( wpla_initial_check_is_ssl_error( $loopback ) ) {
		return wpla_initial_check_item( 'https', $label, 'warning', 'Il sito non accetta il proprio certificato: potrebbe essere scaduto o non valido per questo indirizzo. Controllalo con l’hosting.' );
	}
	return wpla_initial_check_item( 'https', $label, 'ok', 'Il sito usa https.' );
}

function wpla_initial_check_privacy() {
	$url = wpla_get_settings()['privacy_url'] ?: get_privacy_policy_url();
	if ( ! $url ) {
		return wpla_initial_check_item( 'privacy', 'Informativa privacy', 'error', 'Manca l’informativa privacy: la chat pubblica resta nascosta finché non imposti il link o pubblichi la pagina privacy di WordPress.', wpla_admin_url( 'wpla-settings', array( 'tab' => 'privacy' ) ), 'Privacy e conservazione' );
	}
	return wpla_initial_check_item( 'privacy', 'Informativa privacy', 'ok', 'La chat mostra il link a ' . $url . '.' );
}

/** Errors and warnings of a result. */
function wpla_initial_check_counts( $result ) {
	$statuses = array_column( $result['items'] ?? array(), 'status' );
	return array(
		'error'   => count( array_keys( $statuses, 'error', true ) ),
		'warning' => count( array_keys( $statuses, 'warning', true ) ),
	);
}

function wpla_initial_check_summary( $result ) {
	$n = wpla_initial_check_counts( $result );
	if ( $n['error'] ) {
		return 1 === $n['error'] ? '1 problema da sistemare' : $n['error'] . ' problemi da sistemare';
	}
	if ( $n['warning'] ) {
		return 1 === $n['warning'] ? 'Nessun problema bloccante, 1 avviso' : 'Nessun problema bloccante, ' . $n['warning'] . ' avvisi';
	}
	return 'Tutto a posto';
}

/** The check with its last result: Overview and last step of the guided setup. */
function wpla_section_initial_check() {
	$result = get_option( 'wpla_initial_check', array() );
	$labels = array(
		'ok'      => 'OK',
		'warning' => 'Da verificare',
		'error'   => 'Da sistemare',
	);
	echo '<div id="wpla-initial-check">';
	echo '<p>Prova il provider AI, invia un’email di prova e controlla WP-Cron, HTTPS e informativa privacy. La prova AI usa pochi token; l’email arriva a ' . esc_html( wpla_mail_recipient() ) . '.</p>';
	if ( empty( $result['items'] ) ) {
		echo '<p><strong>Non ancora eseguito.</strong></p>';
	} else {
		echo '<p><strong>' . esc_html( wpla_initial_check_summary( $result ) ) . '</strong> — ultimo controllo il ' . esc_html( wp_date( 'j/m/Y \a\l\l\e H:i', (int) $result['at'] ) ) . '.</p>';
		echo '<ul class="wpla-checks">';
		foreach ( $result['items'] as $item ) {
			echo '<li data-check="' . esc_attr( $item['id'] ) . '" data-status="' . esc_attr( $item['status'] ) . '" class="wpla-check-' . esc_attr( $item['status'] ) . '">';
			echo '<strong>' . esc_html( $item['label'] ) . '</strong> <span class="wpla-check-status">' . esc_html( $labels[ $item['status'] ] ?? $item['status'] ) . '</span><br />' . esc_html( $item['message'] );
			if ( $item['fix_url'] ) {
				echo ' <a href="' . esc_url( $item['fix_url'] ) . '">' . esc_html( $item['fix_label'] ) . '</a>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wpla_workspace_fields( 'initial_check' );
	submit_button( 'Esegui il controllo', 'secondary', 'submit', false );
	echo '</form></div>';
}
