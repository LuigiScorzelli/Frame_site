<?php
/** Server-side provider credentials and bounded API requests for the standalone beta. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_ai_settings() {
	return wp_parse_args(
		get_option( 'wpla_ai_settings', array() ),
		array(
			'provider'        => 'openai',
			'openai_model'    => wpla_economic_models()['openai'],
			'anthropic_model' => wpla_economic_models()['anthropic'],
			'workspace'       => '',
			'consent'         => false,
			'daily_limit'     => 100,
			'monthly_cap'     => 20,
			'usd_eur'         => 0.89,
			'prices'          => wpla_default_prices(),
		)
	);
}

function wpla_encrypt_secret( $plain ) {
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return new WP_Error( 'crypto_missing', 'Questo hosting deve abilitare OpenSSL per custodire la chiave API.' );
	}
	$iv     = random_bytes( 12 );
	$tag    = '';
	$cipher = openssl_encrypt( $plain, 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, $iv, $tag );
	return false === $cipher ? new WP_Error( 'crypto_failed', 'Impossibile custodire la chiave API.' ) : base64_encode( $iv . $tag . $cipher );
}

function wpla_ai_key_constant( $provider ) {
	return 'openai' === $provider ? 'WPLA_OPENAI_API_KEY' : 'WPLA_ANTHROPIC_API_KEY';
}

/** A key defined in wp-config.php wins over the panel: say so, never show it. */
function wpla_ai_key_notice( $provider ) {
	$constant = wpla_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		return 'Viene usata la chiave definita in wp-config.php (' . $constant . '): prevale su quella inserita qui. Per usare la chiave del pannello, rimuovi la costante da wp-config.php.';
	}
	return wpla_ai_key( $provider ) ? 'Chiave già presente. Lascia vuoto per conservarla.' : 'Chiave non ancora inserita.';
}

function wpla_ai_key( $provider ) {
	$constant = wpla_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		return (string) constant( $constant );
	}
	$vault = get_option( 'wpla_ai_credentials', array() );
	$raw   = base64_decode( $vault[ $provider ] ?? '', true );
	if ( ! $raw || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}
	return openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) ) ?: '';
}

function wpla_ai_save( $input ) {
	$old = wpla_ai_settings();
	// Provider and limits are saved from different tabs: a field missing from the form keeps its value.
	$provider             = $input['provider'] ?? $old['provider'];
	$settings             = $old;
	$settings['provider'] = in_array( $provider, array( 'openai', 'anthropic' ), true ) ? $provider : 'openai';
	if ( isset( $input['consent'] ) || ! empty( $input['_consent_field'] ) ) {
		$settings['consent'] = ! empty( $input['consent'] );
	}
	$settings['daily_limit'] = max( 1, min( 1000, (int) ( $input['daily_limit'] ?? $old['daily_limit'] ) ) );
	$costs                   = wpla_cost_settings_input( $input );
	if ( is_wp_error( $costs ) ) {
		return $costs;
	}
	$settings              = array_merge( $settings, $costs );
	$settings['workspace'] = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $input['workspace'] ?? $old['workspace'] ) );
	foreach ( array( 'openai_model', 'anthropic_model' ) as $field ) {
		$settings[ $field ] = preg_replace( '/[^A-Za-z0-9._:-]/', '', (string) ( $input[ $field ] ?? $old[ $field ] ) );
		if ( ! $settings[ $field ] ) {
			return new WP_Error( 'model_missing', 'Inserisci il nome del modello per entrambi i provider.' );
		}
	}
	$vault = get_option( 'wpla_ai_credentials', array() );
	foreach ( array( 'openai', 'anthropic' ) as $name ) {
		if ( ! empty( $input[ 'remove_' . $name ] ) ) {
			unset( $vault[ $name ] );
		}
		$key = trim( (string) ( $input[ $name . '_key' ] ?? '' ) );
		if ( $key ) {
			if ( strlen( $key ) > 512 || preg_match( '/\s/', $key ) ) {
				return new WP_Error( 'key_invalid', 'La chiave API contiene caratteri non validi.' );
			}
			$encrypted = wpla_encrypt_secret( $key );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$vault[ $name ] = $encrypted;
		}
	}
	update_option( 'wpla_ai_credentials', $vault, false );
	update_option( 'wpla_ai_settings', $settings, false );
	return true;
}

/** Atomic counters bound public inference spending and flood attempts across PHP workers. */
function wpla_take_quota( $bucket, $limit, $window ) {
	global $wpdb;
	$period = (int) floor( time() / $window );
	$key    = hash( 'sha256', $bucket . ':' . $period );
	$table  = $wpdb->prefix . 'wpla_counters';
	$ok     = $wpdb->query(
		$wpdb->prepare(
			'INSERT INTO %i (bucket, hits, expires) VALUES (%s, 1, %d) ON DUPLICATE KEY UPDATE hits = hits + 1',
			$table,
			$key,
			( $period + 1 ) * $window
		)
	);
	return false !== $ok && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT hits FROM %i WHERE bucket = %s', $table, $key ) ) <= $limit;
}

/** Absolute time (microtime) by which every AI call must finish; 0 means no limit. Set by the public chat. */
function wpla_ai_deadline( $at = null ) {
	static $deadline = 0;
	if ( null !== $at ) {
		$deadline = (float) $at;
	}
	return $deadline;
}

/** True while the public chat is answering: its calls use the share of the daily limit the panel cannot take. */
function wpla_ai_for_chat( $on = null ) {
	static $chat = false;
	if ( null !== $on ) {
		$chat = (bool) $on;
	}
	return $chat;
}

function wpla_ai_request( $system, $message, $max_tokens = 1200, $pdf = null, $timeout = 25 ) {
	$s   = wpla_ai_settings();
	$key = wpla_ai_key( $s['provider'] );
	if ( ! $s['consent'] ) {
		return new WP_Error( 'ai_consent_missing', 'Prima del test seleziona la casella “Autorizzo l’invio al provider selezionato…” e premi “Salva e prova il collegamento AI”.' );
	}
	if ( ! $key ) {
		$label = 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic';
		$vault = get_option( 'wpla_ai_credentials', array() );
		if ( ! empty( $vault[ $s['provider'] ] ) ) {
			return new WP_Error( 'ai_key_unreadable', 'Non riesco a leggere la chiave API salvata per ' . $label . '. Reinseriscila e premi “Salva e prova il collegamento AI”.' );
		}
		return new WP_Error( 'ai_key_missing', 'Non risulta una chiave API salvata per ' . $label . '. Inseriscila nel campo del provider selezionato e premi “Salva e prova il collegamento AI”.' );
	}
	$deadline = wpla_ai_deadline();
	if ( $deadline ) {
		$left = (int) floor( $deadline - microtime( true ) );
		if ( $left < 2 ) {
			return new WP_Error( 'ai_budget', 'Tempo massimo della risposta raggiunto.' );
		}
		$timeout = min( $timeout, $left );
	}
	// One daily limit; calls outside the public chat may use 70% of it, so the panel never leaves the chat without answers.
	$panel_limit = max( 1, (int) floor( $s['daily_limit'] * 0.7 ) );
	if ( ! wpla_ai_for_chat() && ! wpla_take_quota( 'ai-admin', $panel_limit, DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ai_admin_limit', 'Il pannello ha usato oggi le sue ' . $panel_limit . ' richieste AI su ' . $s['daily_limit'] . ': il resto è riservato alla chat. Riprova domani o alza "Richieste AI al giorno".' );
	}
	if ( ! wpla_take_quota( 'ai-site', $s['daily_limit'], DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ai_daily_limit', 'Raggiunto il limite giornaliero di richieste AI del sito.' );
	}
	if ( 'openai' === $s['provider'] ) {
		$content = array(
			array(
				'type' => 'input_text',
				'text' => $message,
			),
		);
		if ( $pdf ) {
			array_unshift(
				$content,
				array(
					'type'      => 'input_file',
					'filename'  => 'document.pdf',
					'file_data' => 'data:application/pdf;base64,' . base64_encode( $pdf ),
				)
			);
		}
		$url     = 'https://api.openai.com/v1/responses';
		$headers = array( 'Authorization' => 'Bearer ' . $key );
		$body    = array(
			'model'             => $s['openai_model'],
			'instructions'      => $system,
			'input'             => array(
				array(
					'role'    => 'user',
					'content' => $content,
				),
			),
			'store'             => false,
			'max_output_tokens' => $max_tokens,
		);
	} else {
		$content = array(
			array(
				'type' => 'text',
				'text' => $message,
			),
		);
		if ( $pdf ) {
			array_unshift(
				$content,
				array(
					'type'   => 'document',
					'source' => array(
						'type'       => 'base64',
						'media_type' => 'application/pdf',
						'data'       => base64_encode( $pdf ),
					),
				)
			);
		}
		$url     = 'https://api.anthropic.com/v1/messages';
		$headers = array(
			'x-api-key'         => $key,
			'anthropic-version' => '2023-06-01',
		);
		if ( $s['workspace'] ) {
			$headers['anthropic-workspace-id'] = $s['workspace'];
		}
		$body = array(
			'model'      => $s['anthropic_model'],
			'system'     => $system,
			'messages'   => array(
				array(
					'role'    => 'user',
					'content' => $content,
				),
			),
			'max_tokens' => $max_tokens,
		);
	}
	$headers['Content-Type'] = 'application/json';
	$seconds                 = max( 1, min( 25, (int) $timeout ) );
	$response                = wp_remote_post(
		$url,
		array(
			'headers'             => $headers,
			'body'                => wp_json_encode( $body ),
			'timeout'             => $seconds,
			'redirection'         => 0,
			'limit_response_size' => 600000,
		)
	);
	// Never return provider response bodies: they may contain secrets or sensitive input.
	if ( is_wp_error( $response ) ) {
		// A slow answer is not a connection problem: cURL error 28 and the streams transport both say "timed out".
		if ( preg_match( '/cURL error 28|timed out/i', $response->get_error_message() ) ) {
			return new WP_Error( 'ai_timeout', 'Il provider non ha completato la risposta entro ' . $seconds . ' secondi. Riprova; se succede ancora, riduci il testo da elaborare.' );
		}
		return new WP_Error( 'ai_network', 'Il provider non risponde. Controlla la connessione e riprova.' );
	}
	$code = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		$constant = wpla_ai_key_constant( $s['provider'] );
		$messages = array(
			401 => defined( $constant ) ? 'Chiave API non valida. È la chiave definita in wp-config.php (' . $constant . '), che prevale su quella del pannello.' : 'Chiave API non valida.',
			403 => 'Il conto non ha accesso al modello o al workspace.',
			404 => 'Modello non trovato: controlla il nome del modello per ' . ( 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic' ) . '.',
			429 => 'Quota o limite del provider raggiunto.',
		);
		return new WP_Error( 'ai_http', $messages[ $code ] ?? 'Richiesta AI non riuscita. Verifica modello, credito e compatibilità del file.', array( 'http_status' => $code ) );
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	// Every accepted call is billed, even when the answer is then rejected as incomplete (P6.2).
	wpla_usage_record( $s['provider'], $body['model'], $data['usage'] ?? null );
	$text = '';
	if ( 'openai' === $s['provider'] ) {
		if ( 'completed' !== ( $data['status'] ?? '' ) ) {
			return new WP_Error( 'ai_incomplete', 'Risposta AI incompleta. Riduci la fonte o usa un modello compatibile.' );
		}
		foreach ( $data['output'] ?? array() as $item ) {
			foreach ( $item['content'] ?? array() as $part ) {
				if ( 'output_text' === ( $part['type'] ?? '' ) ) {
					$text .= $part['text'];
				}
			}
		}
	} else {
		if ( ! in_array( $data['stop_reason'] ?? '', array( 'end_turn', 'stop_sequence' ), true ) ) {
			return new WP_Error( 'ai_incomplete', 'Risposta AI incompleta. Riduci la fonte o usa un modello compatibile.' );
		}
		foreach ( $data['content'] ?? array() as $part ) {
			if ( 'text' === ( $part['type'] ?? '' ) ) {
				$text .= $part['text'];
			}
		}
	}
	return trim( $text ) ?: new WP_Error( 'ai_empty', 'Il provider non ha restituito testo utilizzabile.' );
}

/** The connection check must use the fields the customer has just submitted. */
function wpla_ai_save_and_test( $input ) {
	$saved = wpla_ai_save( $input );
	return is_wp_error( $saved ) ? $saved : wpla_ai_connection_test();
}

/** An accepted request proves key, model and quota: a reasoning model may spend the small budget thinking and return no text. */
function wpla_ai_connection_test() {
	$result = wpla_ai_request( 'Rispondi solo OK.', 'Prova del collegamento.', 50 );
	return is_wp_error( $result ) && in_array( $result->get_error_code(), array( 'ai_incomplete', 'ai_empty' ), true ) ? 'OK' : $result;
}

function wpla_ai_json( $text ) {
	$text = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', trim( $text ) );
	$data = json_decode( $text, true );
	return is_array( $data ) ? $data : new WP_Error( 'ai_json', 'Risposta AI non valida. La bozza precedente è conservata; riprova.' );
}

/* ---------- Costi (P6.2) ---------- */

/** List prices in USD per million tokens, checked on the providers' pages on 11/11/2026. A key also prices the dated versions it prefixes. */
function wpla_default_prices() {
	return array(
		'gpt-4.1-mini'     => array(
			'in'  => 0.4,
			'out' => 1.6,
		),
		'claude-haiku-4-5' => array(
			'in'  => 1.0,
			'out' => 5.0,
		),
	);
}

/** Cheapest model of each provider (P6.3): the default of a first configuration and the panel's recommendation. */
function wpla_economic_models() {
	return array(
		'openai'    => 'gpt-4.1-mini',
		'anthropic' => 'claude-haiku-4-5-20251001',
	);
}

/**
 * Typical chat question for the cost estimate (P6.3), an assumption to be checked on real sites.
 * Measured in CI on 16/11: about 730 input tokens per answer with the short test sources; the code allows
 * up to about 5500 (6 passages of 1600 characters, a 6000-character agent prompt, 12 messages of history).
 */
function wpla_typical_question() {
	return array(
		'in'  => 3000,
		'out' => 300,
	);
}

/** Euro per million tokens and per 100 typical questions with a model; null when the price list has no price for it. */
function wpla_model_estimate( $model, $settings = null ) {
	$s     = $settings ?? wpla_ai_settings();
	$price = wpla_model_price( (string) $model, $s['prices'] ?: wpla_default_prices() );
	if ( null === $price ) {
		return null;
	}
	$rate = (float) $s['usd_eur'];
	$q    = wpla_typical_question();
	return array(
		'in'     => $price['in'] * $rate,
		'out'    => $price['out'] * $rate,
		'per100' => 100 * ( $q['in'] * $price['in'] + $q['out'] * $price['out'] ) / 1000000 * $rate,
	);
}

/** Provider of a price list entry, for the model suggestions: Anthropic model names start with "claude". */
function wpla_price_provider( $model ) {
	return 0 === strpos( (string) $model, 'claude' ) ? 'anthropic' : 'openai';
}

/** A number typed in the panel, with comma or dot decimals; null when it is not a number. */
function wpla_cost_number( $value ) {
	$value = str_replace( ',', '.', trim( (string) $value ) );
	return is_numeric( $value ) ? (float) $value : null;
}

/** Validate the cost fields of the Limits tab. Returns the fields to merge or a WP_Error; absent fields keep their value. */
function wpla_cost_settings_input( $input ) {
	$out = array();
	if ( isset( $input['monthly_cap'] ) ) {
		$cap = wpla_cost_number( $input['monthly_cap'] );
		if ( null === $cap || $cap < 0 || $cap > 10000 ) {
			return new WP_Error( 'cap_invalid', 'Il tetto di spesa mensile deve essere un importo tra 0 e 10.000 euro (0 = nessun tetto).' );
		}
		$out['monthly_cap'] = $cap;
	}
	if ( isset( $input['usd_eur'] ) ) {
		$rate = wpla_cost_number( $input['usd_eur'] );
		if ( null === $rate || $rate < 0.01 || $rate > 10 ) {
			return new WP_Error( 'rate_invalid', 'Il cambio deve indicare quanti euro vale un dollaro, per esempio 0,89.' );
		}
		$out['usd_eur'] = $rate;
	}
	if ( ! empty( $input['_prices_field'] ) ) {
		$prices = array();
		foreach ( array_slice( (array) ( $input['prices'] ?? array() ), 0, 20 ) as $row ) {
			$model = preg_replace( '/[^A-Za-z0-9._:-]/', '', (string) ( $row['model'] ?? '' ) );
			if ( '' === $model && '' === trim( (string) ( $row['in'] ?? '' ) ) && '' === trim( (string) ( $row['out'] ?? '' ) ) ) {
				continue;
			}
			$in   = wpla_cost_number( $row['in'] ?? '' );
			$cost = wpla_cost_number( $row['out'] ?? '' );
			if ( '' === $model || null === $in || null === $cost || $in < 0 || $cost < 0 || $in > 1000 || $cost > 1000 ) {
				return new WP_Error( 'price_invalid', 'Ogni riga del listino richiede il nome del modello e due prezzi in dollari tra 0 e 1000 per milione di token.' );
			}
			$prices[ $model ] = array(
				'in'  => $in,
				'out' => $cost,
			);
		}
		$out['prices'] = $prices;
	}
	return $out;
}

/** Price of a model: the exact name, else the longest listed name it starts with (dated versions); null when unlisted. */
function wpla_model_price( $model, $prices ) {
	if ( isset( $prices[ $model ] ) ) {
		return $prices[ $model ];
	}
	$best = null;
	$len  = 0;
	foreach ( $prices as $name => $price ) {
		if ( strlen( $name ) > $len && 0 === strpos( $model, $name . '-' ) ) {
			$best = $price;
			$len  = strlen( $name );
		}
	}
	return $best;
}

/** Record the tokens of one provider call: never questions, passages or answers. */
function wpla_usage_record( $provider, $model, $usage ) {
	global $wpdb;
	if ( ! is_array( $usage ) ) {
		return;
	}
	$input = (int) ( $usage['input_tokens'] ?? 0 );
	if ( 'anthropic' === $provider ) {
		// Anthropic reports cache writes and reads apart from input_tokens.
		$input += (int) ( $usage['cache_creation_input_tokens'] ?? 0 ) + (int) ( $usage['cache_read_input_tokens'] ?? 0 );
	}
	$chat = wpla_ai_for_chat();
	$wpdb->insert(
		$wpdb->prefix . 'wpla_usage',
		array(
			'created_at'    => current_time( 'mysql', true ),
			'scope'         => $chat ? 'chat' : 'panel',
			'conversation'  => $chat ? wpla_ai_conversation() : '',
			'provider'      => $provider,
			'model'         => substr( (string) $model, 0, 100 ),
			'input_tokens'  => max( 0, $input ),
			'output_tokens' => max( 0, (int) ( $usage['output_tokens'] ?? 0 ) ),
		)
	);
}

/** Pseudonymous conversation of the chat call in progress (hash of the session key); empty outside the chat. */
function wpla_ai_conversation( $hash = null ) {
	static $conversation = '';
	if ( null !== $hash ) {
		$conversation = (string) $hash;
	}
	return $conversation;
}

/** First instant of the current calendar month in the site time zone, as a UTC MySQL datetime. */
function wpla_month_start_utc() {
	$start = new DateTimeImmutable( 'first day of this month midnight', wp_timezone() );
	return $start->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
}

/**
 * Estimated cost of the month in euro, computed from the tokens with the current price list.
 * A model missing from the list is priced at the highest list prices and reported.
 */
function wpla_usage_summary() {
	global $wpdb;
	$s      = wpla_ai_settings();
	$prices = $s['prices'] ?: wpla_default_prices();
	$top    = array(
		'in'  => max( array_column( $prices, 'in' ) ),
		'out' => max( array_column( $prices, 'out' ) ),
	);
	$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT scope, conversation, model, SUM(input_tokens) AS input_tokens, SUM(output_tokens) AS output_tokens, COUNT(*) AS calls FROM %i WHERE created_at >= %s GROUP BY scope, conversation, model', $wpdb->prefix . 'wpla_usage', wpla_month_start_utc() ), ARRAY_A );
	$out    = array(
		'total'            => 0.0,
		'chat'             => 0.0,
		'panel'            => 0.0,
		'calls'            => 0,
		'conversations'    => 0,
		'conversation_avg' => 0.0,
		'conversation_max' => 0.0,
		'missing'          => array(),
		'cap'              => (float) $s['monthly_cap'],
	);
	$per    = array();
	foreach ( $rows ?: array() as $row ) {
		$price = wpla_model_price( $row['model'], $prices );
		if ( null === $price ) {
			$price            = $top;
			$out['missing'][] = $row['model'];
		}
		$eur            = ( $row['input_tokens'] * $price['in'] + $row['output_tokens'] * $price['out'] ) / 1000000 * (float) $s['usd_eur'];
		$scope          = 'chat' === $row['scope'] ? 'chat' : 'panel';
		$out[ $scope ] += $eur;
		$out['calls']  += (int) $row['calls'];
		if ( 'chat' === $scope && '' !== $row['conversation'] ) {
			$per[ $row['conversation'] ] = ( $per[ $row['conversation'] ] ?? 0 ) + $eur;
		}
	}
	$out['total']            = $out['chat'] + $out['panel'];
	$out['missing']          = array_values( array_unique( $out['missing'] ) );
	$out['conversations']    = count( $per );
	$out['conversation_avg'] = $per ? array_sum( $per ) / count( $per ) : 0.0;
	$out['conversation_max'] = $per ? max( $per ) : 0.0;
	return $out;
}

/** True when a monthly cap is set and the month estimate has reached it. */
function wpla_cost_cap_reached( $summary = null ) {
	$summary = $summary ?? wpla_usage_summary();
	return $summary['cap'] > 0 && $summary['total'] >= $summary['cap'];
}

function wpla_format_eur( $amount, $decimals = 2 ) {
	return number_format( (float) $amount, $decimals, ',', '.' ) . ' €';
}

/** A stored amount as the panel shows it in a field: comma decimals, no trailing zeros. */
function wpla_cost_input_value( $value ) {
	if ( '' === $value ) {
		return '';
	}
	return str_replace( '.', ',', rtrim( rtrim( number_format( (float) $value, 6, '.', '' ), '0' ), '.' ) );
}
