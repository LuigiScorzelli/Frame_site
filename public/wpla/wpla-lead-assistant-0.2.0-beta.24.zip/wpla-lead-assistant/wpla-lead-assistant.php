<?php
/**
 * Plugin Name: WP Lead Assistant
 * Description: Assistente AI con OpenAI o Anthropic, scansione del sito e documentazione approvata.
 * Version: 0.2.0-beta.24
 * Requires at least: 7.0
 * Requires PHP: 8.3
 * Author: WP Lead Assistant
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wpla-lead-assistant
 * Update URI: https://aiframe.it/wpla/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPLA_VERSION', '0.2.0-beta.24' );
define( 'WPLA_PLUGIN_FILE', __FILE__ );

require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/frontend.php';
require_once __DIR__ . '/includes/ai-provider.php';
require_once __DIR__ . '/includes/local-storage.php';
require_once __DIR__ . '/includes/knowledge.php';
require_once __DIR__ . '/includes/discovery.php';
require_once __DIR__ . '/includes/agent.php';
require_once __DIR__ . '/includes/local-chat.php';
require_once __DIR__ . '/includes/source-manager.php';
require_once __DIR__ . '/includes/workspace.php';
require_once __DIR__ . '/includes/initial-check.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/admin-pages.php';
require_once __DIR__ . '/includes/updater.php';
require_once __DIR__ . '/includes/privacy.php';

/** Create a private preview token once, without loading it on every request. */
function wpla_activate() {
	wpla_local_install();
	if ( ! get_option( 'wpla_preview_token' ) ) {
		add_option( 'wpla_preview_token', wp_generate_password( 40, false, false ), '', false );
	}
}
register_activation_hook( __FILE__, 'wpla_activate' );

add_action( 'admin_init', 'wpla_register_settings' );
add_action( 'admin_init', 'wpla_local_maybe_install' );
add_action( 'init', 'wpla_remove_legacy_settings', 0 );
add_action( 'admin_menu', 'wpla_admin_menu' );
add_action( 'admin_init', 'wpla_legacy_redirect', 0 );
add_action( 'admin_enqueue_scripts', 'wpla_admin_assets' );
add_filter( 'admin_footer_text', 'wpla_admin_footer' );
add_action( 'admin_post_wpla_regenerate_preview', 'wpla_regenerate_preview' );
add_action( 'admin_init', 'wpla_register_privacy_text' );
add_filter( 'wp_privacy_personal_data_exporters', 'wpla_privacy_register_exporter' );
add_filter( 'wp_privacy_personal_data_erasers', 'wpla_privacy_register_eraser' );
add_action( 'admin_post_wpla_workspace', 'wpla_workspace_action' );
add_action( 'wp_ajax_wpla_knowledge', 'wpla_knowledge_ajax' );
add_action( 'rest_api_init', 'wpla_local_register_routes' );
add_action( 'save_post', 'wpla_post_changed', 100 );
add_action( 'before_delete_post', 'wpla_post_deleted' );
// WooCommerce fires save_post before writing price and stock: check again once the product is fully saved.
add_action( 'woocommerce_update_product', 'wpla_post_changed' );
add_action( 'woocommerce_update_product_variation', 'wpla_post_changed' );
add_action( 'updated_post_meta', 'wpla_product_meta_changed', 10, 3 );
add_action( 'added_post_meta', 'wpla_product_meta_changed', 10, 3 );
add_action( 'deleted_post_meta', 'wpla_product_meta_changed', 10, 3 );
add_action( 'set_object_terms', 'wpla_terms_changed', 10, 4 );
add_action( 'edited_term', 'wpla_term_changed', 10, 3 );
add_action( 'deleted_term', 'wpla_term_changed', 10, 5 );
add_action( 'wpla_local_cleanup', 'wpla_local_cleanup' );
add_action( 'wpla_local_retry', 'wpla_local_deliver' );

function wpla_deactivate() {
	wp_clear_scheduled_hook( 'wpla_local_cleanup' );
	// Parameterized retry events are cleared individually.
	foreach ( _get_cron_array() as $events ) {
		foreach ( $events['wpla_local_retry'] ?? array() as $event ) {
			wp_clear_scheduled_hook( 'wpla_local_retry', $event['args'] );
		}
	}
}
register_deactivation_hook( __FILE__, 'wpla_deactivate' );

add_action( 'init', 'wpla_register_block' );
add_shortcode( 'wpla_chat', 'wpla_shortcode' );
add_action( 'wp_footer', 'wpla_enqueue_frontend', 1 );
