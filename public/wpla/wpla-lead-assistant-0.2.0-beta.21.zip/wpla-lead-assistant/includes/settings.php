<?php
/** Administration, option validation, and diagnostics. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_defaults() {
	return array(
		'lead_email'     => '',
		'display_mode'   => 'off',
		'workflow_mode'  => 'servizi',
		'visibility'     => 'all',
		'page_ids'       => array(),
		'title'          => '',
		'company'        => '',
		'color'          => '#1f5fbf',
		'position'       => 'right',
		'welcome'        => '',
		'privacy_url'    => '',
		'fallback_phone' => '',
		'fallback_email' => '',
		'suggestions'    => '',
		'launcher_label' => '',
		'trusted_proxies' => '',
		'lead_retention_days' => 30,
	);
}

/** Days a lead accepted by the email service is kept (P3.11). Undelivered leads are not affected (D-020). */
function wpla_retention_choices() {
	return array( 7, 30, 90, 180, 365 );
}

function wpla_get_settings() {
	$saved = get_option( 'wpla_settings', array() );
	$defaults = wpla_defaults();
	return wp_parse_args( is_array( $saved ) ? array_intersect_key( $saved, $defaults ) : array(), $defaults );
}

/** Remove the retired external-service configuration after an upgrade. */
function wpla_remove_legacy_settings() {
	$saved = get_option( 'wpla_settings', array() );
	if ( ! is_array( $saved ) || ! array_intersect( array( 'engine', 'endpoint', 'site_key' ), array_keys( $saved ) ) ) {
		return;
	}
	unset( $saved['engine'], $saved['endpoint'], $saved['site_key'] );
	update_option( 'wpla_settings', $saved, false );
}

function wpla_sanitize_settings( $input ) {
	$input = is_array( $input ) ? wp_unslash( $input ) : array();
	$old   = wpla_get_settings();
	// Customer and technical forms edit subsets of the same options.
	if ( ! empty( $input['_visibility_form'] ) && ! isset( $input['page_ids'] ) ) {
		$input['page_ids'] = array();
	}
	$input = wp_parse_args( $input, $old );
	$clean = wpla_defaults();
	$clean['lead_email'] = sanitize_email( $input['lead_email'] );

	$clean['display_mode']  = in_array( $input['display_mode'] ?? '', array( 'off', 'test', 'live' ), true ) ? $input['display_mode'] : 'off';
	$clean['workflow_mode'] = in_array( $input['workflow_mode'] ?? '', array( 'servizi', 'ecommerce' ), true ) ? $input['workflow_mode'] : 'servizi';
	$clean['visibility']    = in_array( $input['visibility'] ?? '', array( 'all', 'include', 'exclude' ), true ) ? $input['visibility'] : 'all';
	$clean['position']      = in_array( $input['position'] ?? '', array( 'left', 'right' ), true ) ? $input['position'] : 'right';
	$page_ids               = array_map( 'intval', (array) ( $input['page_ids'] ?? array() ) );
	$clean['page_ids']      = array_values( array_unique( array_filter( $page_ids, static function ( $id ) { return $id > 0; } ) ) );
	$clean['color']         = sanitize_hex_color( $input['color'] ?? '' ) ?: '#1f5fbf';

	foreach ( array( 'title', 'company', 'fallback_phone', 'launcher_label' ) as $key ) {
		$clean[ $key ] = sanitize_text_field( $input[ $key ] ?? '' );
	}
	$clean['fallback_email'] = sanitize_email( $input['fallback_email'] ?? '' );
	$clean['privacy_url']    = esc_url_raw( $input['privacy_url'] ?? '', array( 'http', 'https' ) );
	$clean['welcome']        = sanitize_textarea_field( $input['welcome'] ?? '' );
	$lines                   = preg_split( '/[\r\n|]+/', (string) ( $input['suggestions'] ?? '' ) );
	$clean['suggestions']    = implode( '|', array_slice( array_filter( array_map( 'sanitize_text_field', $lines ) ), 0, 8 ) );
	$proxies                 = preg_split( '/[\s,]+/', (string) ( $input['trusted_proxies'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY );
	$clean['trusted_proxies'] = implode( "\n", array_slice( array_values( array_unique( array_filter( $proxies, 'wpla_is_ip_range' ) ) ), 0, 20 ) );
	$days = (int) ( $input['lead_retention_days'] ?? 30 );
	$clean['lead_retention_days'] = in_array( $days, wpla_retention_choices(), true ) ? $days : 30;

	return $clean;
}

/** A single IPv4/IPv6 address or a network in CIDR notation. */
function wpla_is_ip_range( $range ) {
	$parts = explode( '/', (string) $range, 2 );
	$ip = filter_var( $parts[0], FILTER_VALIDATE_IP );
	if ( ! $ip ) {
		return false;
	}
	$max = false !== strpos( $ip, ':' ) ? 128 : 32;
	return ! isset( $parts[1] ) || ( ctype_digit( $parts[1] ) && (int) $parts[1] <= $max );
}

function wpla_register_settings() {
	register_setting(
		'wpla_settings',
		'wpla_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'wpla_sanitize_settings',
			'default'           => wpla_defaults(),
		)
	);
}

function wpla_add_settings_page() {
	add_options_page( 'WP Lead Assistant', 'WP Lead Assistant', 'manage_options', 'wpla', 'wpla_render_settings_page' );
}

function wpla_field( $settings, $key, $label, $type = 'text', $description = '' ) {
	$value = $settings[ $key ];
	echo '<tr><th scope="row"><label for="wpla-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
	if ( 'textarea' === $type ) {
		$shown = 'suggestions' === $key ? str_replace( '|', "\n", $value ) : $value;
		echo '<textarea class="large-text" rows="3" id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']">' . esc_textarea( $shown ) . '</textarea>';
	} else {
		echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '" />';
	}
	if ( $description ) {
		echo '<p class="description">' . esc_html( $description ) . '</p>';
	}
	echo '</td></tr>';
}

function wpla_select_field( $settings, $key, $label, $choices ) {
	echo '<tr><th scope="row"><label for="wpla-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><select id="wpla-' . esc_attr( $key ) . '" name="wpla_settings[' . esc_attr( $key ) . ']">';
	foreach ( $choices as $value => $text ) {
		echo '<option value="' . esc_attr( $value ) . '" ' . selected( $settings[ $key ], $value, false ) . '>' . esc_html( $text ) . '</option>';
	}
	echo '</select></td></tr>';
}

function wpla_render_technical_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accesso negato.', 'wpla-lead-assistant' ) );
	}
	$s        = wpla_get_settings();
	$token    = get_option( 'wpla_preview_token', '' );
	$preview  = add_query_arg( 'wpla_preview', $token, home_url( '/' ) );
	$pages    = get_pages( array( 'sort_column' => 'post_title' ) );
	?>
	<div class="wrap">
		<h1>WP Lead Assistant</h1>
		<p>Configura l’aspetto e le pagine in cui compare l’assistente. La chat usa il provider e la documentazione approvata su questo sito WordPress.</p>
		<?php settings_errors( 'wpla_settings' ); ?>
		<?php if ( ! $s['privacy_url'] && ! get_privacy_policy_url() ) : ?>
			<div class="notice notice-warning"><p>Imposta l’URL dell’informativa privacy qui o in WordPress. Il widget pubblico resta nascosto finché manca il link.</p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'wpla_settings' ); ?>
			<input type="hidden" name="wpla_settings[_visibility_form]" value="1" />
			<h2>Visibilità</h2>
			<table class="form-table" role="presentation">
				<?php
				wpla_select_field( $s, 'display_mode', 'Stato', array( 'off' => 'Disattivato', 'test' => 'Solo test', 'live' => 'Pubblico' ) );
				wpla_select_field( $s, 'workflow_mode', 'Cosa offri?', array( 'servizi' => 'Servizi', 'ecommerce' => 'Prodotti' ) );
				wpla_select_field( $s, 'visibility', 'Pagine', array( 'all' => 'Tutto il sito', 'include' => 'Solo pagine selezionate', 'exclude' => 'Tutto il sito, tranne le pagine selezionate' ) );
				?>
				<tr><th scope="row"><label for="wpla-page-ids">Seleziona pagine</label></th><td>
					<select id="wpla-page-ids" name="wpla_settings[page_ids][]" multiple size="8" style="min-width:300px">
						<?php foreach ( $pages as $page ) : ?>
							<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( in_array( (int) $page->ID, $s['page_ids'], true ) ); ?>><?php echo esc_html( $page->post_title ?: '(senza titolo) #' . $page->ID ); ?></option>
						<?php endforeach; ?>
					</select><p class="description">Maiusc/Ctrl per selezioni multiple. Shortcode e blocco mostrano il widget anche fuori da queste regole.</p>
				</td></tr>
			</table>
			<h2>Aspetto e contatti</h2>
			<table class="form-table" role="presentation">
				<?php
				wpla_field( $s, 'title', 'Titolo chat' );
				wpla_field( $s, 'company', 'Azienda' );
				wpla_field( $s, 'color', 'Colore', 'text', 'Colore esadecimale scuro, ad esempio #0b4f8a.' );
				wpla_select_field( $s, 'position', 'Posizione', array( 'right' => 'Destra', 'left' => 'Sinistra' ) );
				wpla_field( $s, 'welcome', 'Benvenuto', 'textarea', 'L’avviso che si tratta di un assistente AI resta sempre visibile.' );
				wpla_field( $s, 'privacy_url', 'Informativa privacy', 'url', 'Se vuoto, usa la pagina privacy configurata in WordPress.' );
				wpla_field( $s, 'fallback_phone', 'Telefono di emergenza' );
				wpla_field( $s, 'fallback_email', 'Email di emergenza', 'email' );
				wpla_field( $s, 'suggestions', 'Domande suggerite', 'textarea', 'Una domanda per riga, massimo 8.' );
				wpla_field( $s, 'launcher_label', 'Testo pulsante chat' );
				?>
			</table>
			<h2>Rete</h2>
			<table class="form-table" role="presentation">
				<?php wpla_field( $s, 'trusted_proxies', 'Proxy fidati', 'textarea', 'Solo se il sito è dietro Cloudflare, un CDN o un reverse proxy: indirizzi o reti (es. 203.0.113.5 o 10.0.0.0/8), uno per riga. Per le richieste che arrivano da questi indirizzi i limiti per visitatore usano l’IP indicato in X-Forwarded-For. Lascia vuoto se non sai che cosa usa il tuo hosting.' ); ?>
			</table>
			<?php submit_button( 'Salva impostazioni' ); ?>
		</form>
		<h2>Anteprima</h2>
		<p>In modalità test la chat è visibile solo agli amministratori e a chi ha questo link: <a href="<?php echo esc_url( $preview ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $preview ); ?></a></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpla_regenerate_preview" />
			<?php wp_nonce_field( 'wpla_regenerate_preview' ); ?>
			<?php submit_button( 'Rigenera link di anteprima', 'secondary', 'submit', false ); ?>
		</form>
		<p>Inserisci <code>[wpla_chat]</code> in una pagina o aggiungi il blocco “WP Lead Assistant”.</p>
		<p class="description">Versione plugin: <?php echo esc_html( WPLA_VERSION ); ?>.</p>
	</div>
	<?php
}

function wpla_regenerate_preview() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accesso negato.', 'wpla-lead-assistant' ) );
	}
	check_admin_referer( 'wpla_regenerate_preview' );
	update_option( 'wpla_preview_token', wp_generate_password( 40, false, false ), false );
	wp_safe_redirect( admin_url( 'options-general.php?page=wpla' ) );
	exit;
}
