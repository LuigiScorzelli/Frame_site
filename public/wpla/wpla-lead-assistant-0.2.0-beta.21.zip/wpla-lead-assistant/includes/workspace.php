<?php
/** Customer workspace: provider, site discovery, additional files and knowledge approval. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Accesso negato.', 'wpla-lead-assistant' ) );
	}
	if ( isset( $_GET['tab'] ) && 'technical' === $_GET['tab'] ) {
		echo '<p><a href="' . esc_url( admin_url( 'options-general.php?page=wpla' ) ) . '">← Il tuo assistente</a></p>';
		wpla_render_technical_settings_page();
		return;
	}
	$s = wpla_get_settings();
	$ai = wpla_ai_settings();
	$sources = wpla_sources();
	$draft = get_option( 'wpla_kb_draft', array() );
	$published = get_option( 'wpla_kb_published', array() );
	$notice = get_transient( 'wpla_workspace_' . get_current_user_id() );
	delete_transient( 'wpla_workspace_' . get_current_user_id() );
	wp_enqueue_style( 'wpla-workspace', plugins_url( 'assets/wpla-workspace.css', WPLA_PLUGIN_FILE ), array(), WPLA_VERSION );
	wp_enqueue_script( 'wpla-workspace', plugins_url( 'assets/wpla-workspace.js', WPLA_PLUGIN_FILE ), array(), WPLA_VERSION, true );
	wp_localize_script( 'wpla-workspace', 'WPLA_WORKSPACE', array( 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'wpla_knowledge' ) ) );
	?>
	<div class="wrap">
		<h1>Il tuo assistente <small>Beta gratuita <?php echo esc_html( WPLA_VERSION ); ?></small></h1>
		<p>Collega il provider, scegli cosa offri e prepara le informazioni che l’assistente potrà usare. Il consumo AI viene addebitato dal provider sul tuo conto.</p>
		<?php settings_errors( 'wpla_settings' ); ?>
		<?php if ( $notice ) : ?><div class="notice <?php echo $notice['ok'] ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $notice['message'] ); ?></p></div><?php endif; ?>
		<?php if ( wpla_undelivered_leads() ) : ?><div class="notice notice-warning"><p>Ci sono richieste di contatto non consegnate per email. <a href="#wpla-leads">Vedi le richieste ricevute</a>.</p></div><?php endif; ?>
		<?php wpla_cron_warning(); ?>
		<?php wpla_workspace_readiness( $s ); ?>
		<h2>1. Configura il tuo assistente</h2>
		<form method="post" action="options.php">
			<?php settings_fields( 'wpla_settings' ); ?>
			<table class="form-table" role="presentation">
				<?php
				wpla_select_field( $s, 'workflow_mode', 'Cosa offri?', array( 'servizi' => 'Servizi', 'ecommerce' => 'Prodotti' ) );
				wpla_field( $s, 'company', 'Nome dell’attività', 'text', 'Se vuoto, usa il nome del sito.' );
				wpla_field( $s, 'lead_email', 'Dove ricevere le richieste', 'email', 'Se vuoto, usa l’email dell’amministratore WordPress. Il destinatario effettivo è mostrato in “Richieste ricevute”.' );
				wpla_field( $s, 'privacy_url', 'Informativa privacy', 'url', 'Se vuoto, usa la pagina privacy di WordPress. Senza questo link la chat pubblica resta nascosta.' );
				wpla_select_field( $s, 'display_mode', 'Visibilità', array( 'off' => 'Disattivato', 'test' => 'Solo test', 'live' => 'Pubblico' ) );
				?>
			</table>
			<?php submit_button( 'Salva le scelte' ); ?>
		</form>
		<h2>2. Collega OpenAI o Anthropic</h2>
		<p>Le chiavi restano cifrate nel database del sito e non vengono mostrate nella chat. Se cambi le chiavi di sicurezza di WordPress, reinserisci le chiavi API.</p>
		<form id="wpla-provider-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wpla_workspace_fields( 'provider' ); ?>
			<table class="form-table" role="presentation">
				<tr><th><label for="wpla-provider">Provider da usare</label></th><td><select id="wpla-provider" name="provider"><option value="openai" <?php selected( $ai['provider'], 'openai' ); ?>>OpenAI</option><option value="anthropic" <?php selected( $ai['provider'], 'anthropic' ); ?>>Anthropic</option></select></td></tr>
				<?php foreach ( array( 'openai' => 'OpenAI', 'anthropic' => 'Anthropic' ) as $provider => $label ) : ?>
					<tr data-wpla-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="wpla-<?php echo esc_attr( $provider ); ?>-key">Chiave API <?php echo esc_html( $label ); ?></label></th><td>
						<input class="regular-text" id="wpla-<?php echo esc_attr( $provider ); ?>-key" type="password" name="<?php echo esc_attr( $provider ); ?>_key" value="" autocomplete="new-password" />
						<p class="description"><?php echo esc_html( wpla_ai_key_notice( $provider ) ); ?></p>
						<label><input type="checkbox" name="remove_<?php echo esc_attr( $provider ); ?>" value="1" /> Rimuovi la chiave salvata</label>
					</td></tr>
					<tr data-wpla-provider="<?php echo esc_attr( $provider ); ?>" <?php echo $ai['provider'] !== $provider ? 'hidden' : ''; ?>><th><label for="wpla-model-<?php echo esc_attr( $provider ); ?>">Modello <?php echo esc_html( $label ); ?></label></th><td><input class="regular-text" id="wpla-model-<?php echo esc_attr( $provider ); ?>" name="<?php echo esc_attr( $provider ); ?>_model" value="<?php echo esc_attr( $ai[ $provider . '_model' ] ); ?>" required /></td></tr>
				<?php endforeach; ?>
				<tr data-wpla-provider="anthropic" <?php echo 'anthropic' !== $ai['provider'] ? 'hidden' : ''; ?>><th><label for="wpla-workspace">Workspace Anthropic</label></th><td><input id="wpla-workspace" name="workspace" value="<?php echo esc_attr( $ai['workspace'] ); ?>" /><p class="description">Facoltativo; necessario per alcune chiavi condivise tra workspace.</p></td></tr>
				<tr><th><label for="wpla-daily-limit">Richieste AI al giorno</label></th><td><input id="wpla-daily-limit" type="number" min="1" max="1000" name="daily_limit" value="<?php echo esc_attr( $ai['daily_limit'] ); ?>" /><p class="description">Include analisi, lettura PDF, prove e chat. Il pannello ne può usare al massimo il 70%: il resto è riservato alla chat. Imposta anche i limiti di spesa nel conto del provider.</p></td></tr>
			</table>
			<p><label><input type="checkbox" name="consent" value="1" <?php checked( $ai['consent'] ); ?> /> Autorizzo l’invio al provider selezionato dei contenuti scelti e dei messaggi della chat per analisi e risposte.</label></p>
			<p id="wpla-provider-feedback" role="alert" hidden></p>
			<?php submit_button( 'Salva il collegamento' ); ?>
			<?php submit_button( 'Salva e prova il collegamento AI', 'secondary', 'test_provider', false ); ?>
			<p class="description">Salva chiave, modello e autorizzazione, poi esegue una piccola richiesta sul tuo conto.</p>
		</form>
		<h2>3. Leggi il sito e aggiungi i documenti</h2>
		<?php wpla_render_discovery(); ?>
		<button type="button" class="button" id="wpla-scan" <?php disabled( ! is_array( get_option( 'wpla_discovery', false ) ) ); ?>>Scansiona il sito</button>
		<p id="wpla-progress" role="status" aria-live="polite"></p>
		<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wpla_workspace_fields( 'upload' ); ?>
			<p><label for="wpla-document">Documento aggiuntivo: TXT, MD, DOCX o PDF; massimo 3 MB e 60 KB di testo estratto.</label></p>
			<input id="wpla-document" type="file" name="document" accept=".txt,.md,.docx,.pdf" required />
			<?php submit_button( 'Aggiungi documento', 'secondary', 'submit', false ); ?>
			<p class="description">I PDF vengono letti dal provider selezionato, con consumo API, in un’unica richiesta di massimo 25 secondi: nelle prove un PDF di 10 pagine di testo era già al limite, quindi dividi i documenti più lunghi in parti di poche pagine. Rivedi sempre il testo estratto. I file originali non vengono pubblicati nella libreria media. Le informazioni approvate potranno comparire nelle risposte ai visitatori: inserisci solo materiale adatto a questo uso. Per DOCX si importa il corpo del testo; per tabelle complesse, immagini, intestazioni o allegati preferisci un PDF e controllane l’estrazione.</p>
		</form>
		<details><summary>Aggiungi o correggi un’informazione manualmente</summary>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wpla_workspace_fields( 'manual' ); ?>
				<p><label>Titolo <input name="title" class="regular-text" required maxlength="200" /></label></p>
				<p><label>Informazioni approvate dall’attività<textarea name="content" class="large-text" rows="5" required></textarea></label></p>
				<?php submit_button( 'Salva informazione', 'secondary' ); ?>
			</form>
		</details>
		<h2>4. Controlla le fonti e ricrea la documentazione</h2>
		<p>Seleziona solo informazioni corrette. La ricostruzione analizza una fonte alla volta e prepara una bozza con riferimenti e citazioni verificabili. Le modifiche a una pagina ritirano subito la sua vecchia versione dalla chat: ripeti scansione, ricostruzione e approvazione per aggiornarla.</p>
		<?php wpla_render_analysis_exclusions( $sources ); ?>
		<?php wpla_render_source_manager( $sources, $published ); ?>
		<p><button type="button" class="button button-primary" id="wpla-generate">Ricrea la documentazione</button></p>
		<div id="wpla-generate-progress" role="status" aria-live="polite" tabindex="-1" style="scroll-margin-top:60px"></div>
		<p><button type="button" class="button" id="wpla-select-errors" hidden>Seleziona le fonti da correggere</button></p>
		<p class="description">L’analisi usa tutte le fonti incluse, anche quelle nascoste dai filtri. Le fonti senza contenuto utile o con risposte di analisi non utilizzabili vengono escluse automaticamente e conservate con il motivo. L’analisi prosegue e apre la bozza con le fonti utili. Se nessuna fonte è utilizzabile, non viene creata una bozza vuota. Errori di connessione, credenziali o quota richiedono un nuovo tentativo senza scartare le fonti.</p>
		<?php if ( ! empty( $draft['markdown'] ) ) : ?>
			<section id="wpla-knowledge-review" tabindex="-1" aria-labelledby="wpla-review-title" style="scroll-margin-top:60px">
			<h3 id="wpla-review-title">Bozza da approvare</h3>
			<p>La bozza è pronta. Controlla il testo qui sotto, poi seleziona la casella di conferma e premi “Approva la documentazione”. Finché non approvi, queste informazioni non vengono pubblicate per la chat.</p>
			<textarea class="large-text code" rows="14" readonly aria-label="Bozza della documentazione"><?php echo esc_textarea( $draft['markdown'] ); ?></textarea>
			<?php wpla_render_agent_editor( $draft ); ?>
			</section>
		<?php endif; ?>
		<?php if ( empty( $draft['markdown'] ) && ! empty( $published['markdown'] ) ) { wpla_render_agent_editor( $published, false ); } ?>
		<?php if ( ! empty( $published['markdown'] ) ) : ?>
			<p>Documentazione approvata: <?php echo esc_html( $published['created_at'] ); ?>. Fonti attualmente utilizzabili: <?php echo esc_html( count( wpla_current_sources( $published ) ) . '/' . count( $published['sources'] ) ); ?>.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_workspace_fields( 'download' ); ?><?php submit_button( 'Scarica la documentazione (.md)', 'secondary', 'submit', false ); ?></form>
		<?php endif; ?>
		<?php if ( get_option( 'wpla_kb_previous' ) ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_workspace_fields( 'restore' ); ?><?php submit_button( 'Ripristina la documentazione precedente', 'secondary', 'submit', false ); ?></form>
		<?php endif; ?>
		<h2>5. Prova l’assistente</h2>
		<?php if ( 'test' === $s['display_mode'] && ! wpla_frontend_setup_issues( $s ) ) : ?>
			<p><a class="button" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( add_query_arg( array( 'wpla_preview' => get_option( 'wpla_preview_token' ), 'wpla' => 'open' ), home_url( '/' ) ) ); ?>">Apri la chat di prova</a></p>
		<?php elseif ( 'live' === $s['display_mode'] && ! wpla_frontend_setup_issues( $s ) ) : ?>
			<p><a class="button" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( add_query_arg( 'wpla', 'open', home_url( '/' ) ) ); ?>">Apri il sito con la chat</a></p>
		<?php else : ?><p>Approva la documentazione e scegli “Solo test” al punto 1 per aprire la prova. Quando hai verificato risposte e ricezione delle richieste, puoi scegliere “Pubblico”.</p><?php endif; ?>
		<details id="wpla-retrieval-check"><summary>Verifica quali fonti trova una domanda</summary>
			<p>La verifica locale mostra i brani scelti senza chiamare l’AI. Quando la ricerca locale è vuota o debole, la chat può selezionare fatti approvati; se questi non bastano, controlla anche i brani originali e cerca con termini alternativi. Puoi provare lo stesso percorso: nei casi difficili può consumare fino a sei richieste AI di ricerca e non verifica la risposta finale. Questa prova usa la domanda da sola: nella chat una domanda di seguito come «E quanto costa?» può riferirsi alla fonte citata prima oppure richiedere un chiarimento.</p>
			<form id="wpla-retrieval-form">
				<label for="wpla-retrieval-query">Domanda di prova</label>
				<input id="wpla-retrieval-query" class="regular-text" required maxlength="1000" placeholder="Quali sono i vostri prodotti?" />
				<label><input id="wpla-retrieval-assisted" type="checkbox" /> Prova anche la ricerca AI nelle fonti approvate</label>
				<button type="submit" class="button">Verifica le fonti</button>
			</form>
			<div id="wpla-retrieval-result" tabindex="-1" role="status" aria-live="polite"></div>
		</details>
		<?php wpla_workspace_unanswered_questions(); ?>
		<p><a href="<?php echo esc_url( admin_url( 'options-general.php?page=wpla&tab=technical' ) ); ?>">Aspetto e pagine</a></p>
		<?php wpla_workspace_leads(); ?>
	</div>
	<?php
}

function wpla_workspace_unanswered_questions() {
	$questions = wpla_local_unanswered_questions();
	echo '<details id="wpla-unanswered-questions"><summary>Domande senza risposta nelle sessioni temporanee (' . esc_html( count( $questions ) ) . ')</summary>';
	echo '<p>Mostra fino a 50 domande distinte ancora presenti nelle sessioni conservate per un giorno; quelle inviate come lead o già scadute non compaiono. Email, link e numeri lunghi vengono mascherati. Il testo può comunque contenere dati personali: usalo solo per correggere le fonti e la chat.</p>';
	if ( ! $questions ) {
		echo '<p>Nessuna domanda senza risposta registrata nelle sessioni disponibili.</p>';
	} else {
		echo '<ol>';
		foreach ( $questions as $item ) {
			echo '<li><strong>' . esc_html( $item['question'] ) . '</strong> — <code>' . esc_html( $item['diagnostic'] ) . '</code>';
			if ( $item['retrieval_status'] ) {
				echo ' (<code>' . esc_html( $item['retrieval_status'] ) . '</code>)';
			}
			if ( $item['count'] > 1 ) {
				echo ' (' . esc_html( $item['count'] ) . ' volte)';
			}
			echo ' <button type="button" class="button-link" data-wpla-retry-question="' . esc_attr( $item['question'] ) . '">Prova nelle fonti</button></li>';
		}
		echo '</ol>';
	}
	echo '</details>';
}

function wpla_workspace_readiness( $s ) {
	$issues = wpla_frontend_setup_issues( $s );
	$blocked = 'off' === $s['display_mode'] || $issues;
	?>
	<div id="wpla-readiness" class="notice <?php echo $blocked ? 'notice-warning' : 'notice-success'; ?>" role="status">
		<p><strong><?php echo $blocked ? 'La chat è nascosta.' : ( 'live' === $s['display_mode'] ? 'La chat è pronta per il pubblico.' : 'La chat è pronta per la prova riservata.' ); ?></strong></p>
		<?php if ( 'off' === $s['display_mode'] ) : ?><p>Al punto 1 scegli “Solo test” o “Pubblico” e premi “Salva le scelte”.</p><?php endif; ?>
		<?php if ( $issues ) : ?><ul><?php foreach ( $issues as $issue ) : ?><li><?php echo esc_html( $issue ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		<?php if ( 'all' !== $s['visibility'] ) : ?><p>È attivo un filtro sulle pagine. Controlla “Aspetto e pagine” in fondo al pannello: la chat compare solo dove consentito, oppure nelle pagine con il suo blocco o shortcode.</p><?php endif; ?>
		<?php if ( ! $blocked ) : ?>
			<p><?php echo 'test' === $s['display_mode'] ? 'I visitatori non la vedono: usa “Apri la chat di prova” al punto 5.' : 'Apri una pagina del sito e attendi circa 3 secondi. Se non compare, svuota la cache del sito e dell’eventuale CDN e ricarica la pagina.'; ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function wpla_workspace_fields( $operation ) {
	echo '<input type="hidden" name="action" value="wpla_workspace" /><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '" />';
	wp_nonce_field( 'wpla_workspace' );
}

function wpla_workspace_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Accesso negato.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'wpla_workspace' );
	global $wpdb;
	$input = wp_unslash( $_POST );
	$operation = sanitize_key( $input['operation'] ?? '' );
	$result = true;
	$message = 'Operazione completata.';
	switch ( $operation ) {
		case 'provider':
			$test_now = ! empty( $input['test_provider'] );
			$result = $test_now ? wpla_ai_save_and_test( $input ) : wpla_ai_save( $input );
			$message = $test_now ? 'Collegamento salvato. Il provider ha risposto correttamente.' : 'Collegamento salvato. Ora puoi provarlo.';
			$provider = wpla_ai_settings()['provider'];
			if ( defined( wpla_ai_key_constant( $provider ) ) ) {
				$message .= ' ' . wpla_ai_key_notice( $provider );
			}
			break;
		case 'test_provider':
			$result = wpla_ai_connection_test();
			$message = 'Il provider ha risposto correttamente.';
			break;
		case 'discovery':
			$result = wpla_save_discovery( $input );
			$message = 'Selezione salvata. Controlla il riepilogo, poi premi “Scansiona il sito”.';
			break;
		case 'upload':
			$result = wpla_import_file( $_FILES['document'] ?? array() );
			$message = 'Testo importato. Controllalo nelle fonti prima di approvarlo.';
			break;
		case 'manual':
			$title = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result = $title && $content && strlen( $content ) <= 60000 ? wpla_source_put( 'manual:' . hash( 'sha256', wpla_text_lower( $title ) ), 'manual', $title, '', $content ) : new WP_Error( 'manual_invalid', 'Inserisci titolo e testo, entro 60 KB.' );
			break;
		case 'sources':
			$action = sanitize_key( $input['source_action'] ?? '' );
			$result = wpla_manage_sources( $action, $input['source_ids'] ?? array() );
			$message = is_wp_error( $result ) ? '' : $result . ' fonti aggiornate. Ricrea e approva la documentazione per pubblicare la nuova selezione.';
			if ( 'delete' === $action && ! is_wp_error( $result ) ) {
				$message .= ' Rimosse soltanto dal plugin. Le pagine torneranno con una nuova scansione; i documenti possono essere ricaricati.';
			}
			break;
		case 'source_edit':
			$id = absint( $input['source_id'] ?? 0 );
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpla_sources WHERE id = %d AND post_id = 0", $id ), ARRAY_A );
			$title = sanitize_text_field( is_string( $input['title'] ?? null ) ? $input['title'] : '' );
			$content = sanitize_textarea_field( is_string( $input['content'] ?? null ) ? $input['content'] : '' );
			$result = $row && $title && $content && strlen( $content ) <= 60000 ? wpla_source_put( $row['source_key'], $row['kind'], $title, '', $content ) : new WP_Error( 'source_edit_invalid', 'Fonte non modificabile o testo non valido. Inserisci titolo e contenuto entro 60 KB. Le pagine si modificano nell’editor WordPress.' );
			$message = 'Testo aggiornato. Ricrea e approva la documentazione.';
			break;
		case 'prompt':
		case 'publish':
			$save_only = 'prompt' === $operation || ! empty( $input['save_prompt'] ) || ! empty( $input['reset_prompt'] );
			if ( ! $save_only && empty( $input['approved'] ) ) {
				$result = new WP_Error( 'approval_missing', 'Conferma di aver controllato la documentazione e il prompt.' );
				break;
			}
			$result = isset( $input['document_version'] ) ? wpla_save_agent_prompt( $input ) : true;
			if ( ! is_wp_error( $result ) && ! $save_only ) {
				$result = wpla_publish_document();
			}
			$message = $save_only ? 'Prompt salvato in bozza. Controlla e approva per usarlo nella chat.' : 'Documentazione approvata. Prompt approvato. La visibilità della chat si sceglie al punto 1.';
			break;
		case 'restore':
			$previous = get_option( 'wpla_kb_previous', array() );
			if ( empty( $previous['sources'] ) || count( wpla_current_sources( $previous ) ) !== count( $previous['sources'] ) ) {
				$result = new WP_Error( 'restore_stale', 'Le fonti della versione precedente sono cambiate. Ricrea la documentazione.' );
			} else {
				update_option( 'wpla_kb_previous', get_option( 'wpla_kb_published' ), false );
				update_option( 'wpla_kb_published', $previous, false );
				update_option( 'wpla_agent_preferences', array( 'system_prompt' => wpla_agent_prompt( $previous ), 'prompt_custom' => ! empty( $previous['prompt_custom'] ) ), false );
				delete_option( 'wpla_kb_draft' );
			}
			break;
		case 'download':
			$doc = get_option( 'wpla_kb_published', array() );
			nocache_headers();
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="documentazione-assistente.md"' );
			echo ( $doc['markdown'] ?? '' ) . ( $doc ? "\n# Prompt di sistema dell’agente\n\n" . wpla_agent_prompt( $doc ) . "\n" : '' );
			exit;
		case 'mail_test':
			$sent = wpla_send_mail( wpla_mail_recipient(), '[TEST] Verifica email WP Lead Assistant', 'Questa email verifica l’invio delle notifiche del plugin. Non contiene dati di clienti.' );
			$result = $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] );
			$message = 'Email di prova accettata dal servizio email per ' . $sent['recipient'] . '. Controlla la casella e lo spam: la consegna non è confermata dal plugin.';
			break;
		case 'resend_lead':
			$id = absint( $input['lead_id'] ?? 0 );
			$wpdb->update( $wpdb->prefix . 'wpla_leads', array( 'delivery' => 'pending' ), array( 'id' => $id ) );
			// The administrator explicitly requested another notification, even if previously accepted.
			$sent = wpla_local_deliver( $id );
			$result = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			$message = 'Nuovo invio accettato dal servizio email per ' . ( is_wp_error( $sent ) ? '' : $sent['recipient'] ) . '. Controlla la casella di destinazione.';
			break;
		case 'delete_lead':
			$id = absint( $input['lead_id'] ?? 0 );
			$result = wpla_local_delete_lead( $id ) ? true : new WP_Error( 'lead_missing', 'Richiesta non trovata.' );
			$message = 'Richiesta #' . $id . ' eliminata.';
			break;
		case 'retry_lead':
			$sent = wpla_local_deliver( absint( $input['lead_id'] ?? 0 ) );
			$result = is_wp_error( $sent ) ? $sent : ( $sent['accepted'] ? true : new WP_Error( 'mail_failed', $sent['error'] ) );
			$message = 'Tentativo accettato dal servizio email. Controlla lo stato e la casella di destinazione.';
			break;
		default:
			$result = new WP_Error( 'operation_invalid', 'Operazione non valida.' );
	}
	set_transient( 'wpla_workspace_' . get_current_user_id(), array( 'ok' => ! is_wp_error( $result ), 'message' => is_wp_error( $result ) ? $result->get_error_message() : $message ), MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'options-general.php?page=wpla' ) . ( in_array( $operation, array( 'sources', 'source_edit', 'upload', 'manual' ), true ) ? '#wpla-source-manager' : ( in_array( $operation, array( 'mail_test', 'resend_lead', 'retry_lead', 'delete_lead' ), true ) ? '#wpla-leads' : ( 'discovery' === $operation ? '#wpla-discovery-form' : ( in_array( $operation, array( 'publish', 'prompt' ), true ) ? '#wpla-knowledge-review' : '' ) ) ) ) );
	exit;
}

function wpla_knowledge_ajax() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Accesso negato.' ), 403 );
	}
	check_ajax_referer( 'wpla_knowledge', 'nonce' );
	$operation = sanitize_key( $_POST['operation'] ?? '' );
	if ( 'scan' === $operation ) {
		$result = wpla_scan_batch( absint( $_POST['page'] ?? 1 ) );
	} elseif ( 'analyze' === $operation ) {
		$result = wpla_analyze_for_document( absint( $_POST['source_id'] ?? 0 ) );
	} elseif ( 'retrieval_test' === $operation ) {
		$query = sanitize_textarea_field( is_string( $_POST['query'] ?? null ) ? wp_unslash( $_POST['query'] ) : '' );
		if ( ! trim( $query ) || wpla_text_length( $query ) > 1000 ) {
			$result = new WP_Error( 'query_invalid', 'Scrivi una domanda entro 1000 caratteri.' );
		} else {
			$sources = wpla_current_sources( get_option( 'wpla_kb_published', array() ), true );
			$chunks = wpla_retrieve( $query, $sources );
			$retrieval_status = 'lexical';
			if ( ! empty( $_POST['assisted'] ) ) {
				$chunks = wpla_retrieve_assisted( $query, $sources, $chunks, $retrieval_status );
			}
			$result = array(
				'approved' => count( $sources ),
				'retrieval_status' => $retrieval_status,
				'titles' => array_values( array_unique( array_column( $chunks, 'title' ) ) ),
				'passages' => array_map( static function ( $chunk ) {
					return array( 'title' => $chunk['title'], 'text' => $chunk['text'] );
				}, $chunks ),
				'greeting' => wpla_local_is_greeting( $query ),
				'overview' => wpla_retrieval_is_overview( $query ),
			);
		}
	} elseif ( 'build' === $operation ) {
		$result = wpla_build_document();
		if ( ! is_wp_error( $result ) ) {
			$result = array( 'message' => 'Bozza pronta.' );
		}
	} else {
		$result = new WP_Error( 'operation_invalid', 'Operazione non valida.' );
	}
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message(), 'code' => $result->get_error_code() ), 400 );
	}
	wp_send_json_success( $result );
}

function wpla_undelivered_leads() {
	global $wpdb;
	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpla_leads WHERE delivery <> 'accepted'" );
}

/** P3.13 (D-030): WP-Cron runs only with site visits or a real cron; without it retention and retries stop silently. */
function wpla_cron_warning() {
	if ( ! wpla_cleanup_status()['late'] ) {
		return;
	}
	$days = (int) wpla_get_settings()['lead_retention_days'];
	$disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? ' In wp-config.php c’è DISABLE_WP_CRON: WordPress non avvia il cron da solo.' : ' WP-Cron parte solo quando qualcuno visita il sito.';
	echo '<div id="wpla-cron-warning" class="notice notice-warning"><p><strong>La pulizia automatica non va da più di 48 ore</strong>: le richieste consegnate non vengono cancellate dopo ' . esc_html( $days ) . ' giorni e i nuovi tentativi di invio non partono.' . esc_html( $disabled ) . ' Chiedi all’hosting un cron reale ogni 15 minuti su <code>' . esc_html( site_url( 'wp-cron.php' ) ) . '</code>.</p></div>';
}

function wpla_workspace_leads() {
	global $wpdb;
	// Undelivered leads first: they are kept until handled and must never fall outside the list.
	$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpla_leads ORDER BY delivery = 'accepted', id DESC LIMIT 50", ARRAY_A );
	$undelivered = wpla_undelivered_leads();
	echo '<section id="wpla-leads" style="scroll-margin-top:60px"><h2>Richieste ricevute</h2>';
	if ( $undelivered ) {
		echo '<div class="notice notice-warning inline"><p><strong>' . esc_html( 1 === $undelivered ? '1 richiesta non consegnata' : $undelivered . ' richieste non consegnate' ) . '</strong>: l’email non è stata accettata dal servizio email. Restano conservate finché non le rinvii o le elimini.</p></div>';
	}
	$days = (int) wpla_get_settings()['lead_retention_days'];
	echo '<p>Le richieste accettate dal servizio email sono conservate per ' . esc_html( $days ) . ' giorni; la cancellazione programmata dipende dall’esecuzione di WP-Cron. Quelle non consegnate restano finché non le rinvii o le elimini. “Accettata dal servizio email” non garantisce la consegna in casella.</p>';
	$last = wpla_cleanup_status()['last'];
	echo '<p id="wpla-cleanup-last">Ultima pulizia automatica: ' . esc_html( $last ? wp_date( 'j F Y, H:i', $last ) : 'non ancora eseguita' ) . '.</p>';
	echo '<form id="wpla-retention" method="post" action="' . esc_url( admin_url( 'options.php' ) ) . '">';
	settings_fields( 'wpla_settings' );
	echo '<p><label for="wpla-lead_retention_days">Conserva le richieste consegnate per</label> <select id="wpla-lead_retention_days" name="wpla_settings[lead_retention_days]">';
	foreach ( wpla_retention_choices() as $choice ) {
		echo '<option value="' . esc_attr( $choice ) . '" ' . selected( $days, $choice, false ) . '>' . esc_html( $choice . ' giorni' ) . '</option>';
	}
	echo '</select> ';
	submit_button( 'Salva la conservazione', 'secondary', 'submit', false );
	echo '</p><p class="description">Vale solo per le richieste accettate dal servizio email. Le richieste di copia o cancellazione di un visitatore si gestiscono da Strumenti › Esporta dati personali e Strumenti › Cancella dati personali, con l’email usata nel modulo.</p></form>';
	echo '<p><strong>Destinatario effettivo: <span id="wpla-mail-recipient">' . esc_html( wpla_mail_recipient() ) . '</span></strong> — ' . ( wpla_get_settings()['lead_email'] ? 'indirizzo scelto al punto 1' : 'email amministratore nelle impostazioni generali WordPress' ) . '.</p>';
	echo '<p>Se la richiesta compare qui, è stata registrata. Se l’email non arriva, verifica il destinatario, la cartella spam e la configurazione della posta del sito. La prova usa lo stesso sistema delle notifiche. Dopo aver corretto la posta puoi rinviare una richiesta registrata.</p>';
	echo '<form id="wpla-mail-test" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wpla_workspace_fields( 'mail_test' );
	submit_button( 'Invia email di prova', 'secondary', 'submit', false );
	echo '</form>';
	foreach ( $rows as $row ) {
		$p = json_decode( $row['payload'], true );
		echo '<details class="wpla-lead"><summary>#' . esc_html( $row['id'] . ' — ' . $row['created_at'] . ' — ' . $p['name'] . ' — ' . ( 'accepted' === $row['delivery'] ? 'accettata dal servizio email' : 'invio email da ritentare' ) ) . '</summary>';
		echo '<p>' . esc_html( $p['email'] . ' ' . $p['phone'] ) . '</p>';
		if ( ! empty( $p['mail'] ) ) {
			echo '<p>Ultimo destinatario: ' . esc_html( $p['mail']['recipient'] ) . '<br>Ultimo tentativo (UTC): ' . esc_html( $p['mail']['attempted_at'] ) . '</p>';
			if ( ! empty( $p['mail']['error'] ) ) {
				echo '<p class="wpla-source-error">' . esc_html( $p['mail']['error'] ) . '</p>';
			}
		} else {
			echo '<p>Dettagli del tentativo non registrati dalla versione precedente. Il prossimo invio li aggiornerà.</p>';
		}
		foreach ( $p['conversation'] as $m ) {
			echo '<p><strong>' . esc_html( $m['role'] ) . ':</strong> ' . esc_html( $m['text'] ) . '</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wpla_workspace_fields( 'accepted' === $row['delivery'] ? 'resend_lead' : 'retry_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( 'accepted' === $row['delivery'] ? 'Rinvia email della richiesta' : 'Riprova l’invio email', 'secondary', 'submit', false );
		echo '<p class="description">Invia al destinatario attuale indicato sopra. Se il precedente messaggio era arrivato, riceverai una copia.</p></form>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Eliminare definitivamente questa richiesta?\');">';
		wpla_workspace_fields( 'delete_lead' );
		echo '<input type="hidden" name="lead_id" value="' . esc_attr( $row['id'] ) . '" />';
		submit_button( 'Elimina la richiesta', 'delete', 'submit', false );
		echo '</form></details>';
	}
	echo '</section>';
}
