<?php
/**
 * Updates from the private endpoint on aiframe.it (D-024, D-027).
 * WordPress shows them in Dashboard > Updates like any other plugin update; the package is the tag ZIP (D-009).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WPLA_UPDATE_URL = 'https://aiframe.it/wpla/update.json';
const WPLA_UPDATE_HOSTS = array( 'aiframe.it', 'www.aiframe.it' );

/**
 * Latest version announced on aiframe.it, or null when the file is missing, slow or invalid.
 * Answers are cached: 6 hours when valid, 1 hour after a failure. "Check again" in Dashboard > Updates bypasses the cache.
 */
function wpla_update_info() {
	$forced = doing_action( 'load-update-core.php' ) && ! empty( $_GET['force-check'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only refresh, like WordPress core.
	$cached = get_transient( 'wpla_update_info' );
	if ( ! $forced && is_array( $cached ) && array_key_exists( 'info', $cached ) ) {
		return $cached['info'];
	}
	// Nothing about the site is sent: no query string, no cookies, and a fixed user agent instead of WordPress' default with the site address.
	$response = wp_safe_remote_get(
		WPLA_UPDATE_URL,
		array(
			'timeout'             => 5,
			'redirection'         => 2,
			'limit_response_size' => 65536,
			'user-agent'          => 'WP-Lead-Assistant-Updater',
			'headers'             => array( 'Accept' => 'application/json' ),
		)
	);
	$info = wpla_update_parse( $response );
	set_transient( 'wpla_update_info', array( 'info' => $info ), $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $info;
}

/** Validates the update file. Any missing or unexpected field rejects the whole answer. */
function wpla_update_parse( $response ) {
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) ) {
		return null;
	}
	$text = static function ( $key ) use ( $data ) {
		return isset( $data[ $key ] ) && is_string( $data[ $key ] ) ? $data[ $key ] : '';
	};
	$version = $text( 'version' );
	$package = $text( 'package' );
	$sha256 = strtolower( $text( 'sha256' ) );
	if ( ! preg_match( '/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?$/', $version ) || ! preg_match( '/^[a-f0-9]{64}$/', $sha256 ) || ! wpla_update_is_own_package( $package ) ) {
		return null;
	}
	$info = array(
		'version'   => $version,
		'package'   => $package,
		'sha256'    => $sha256,
		'released'  => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $text( 'released' ) ) ? $text( 'released' ) : '',
		'changelog' => mb_substr( $text( 'changelog' ), 0, 5000 ),
	);
	foreach ( array( 'requires', 'requires_php', 'tested' ) as $key ) {
		$value = $text( $key );
		if ( '' !== $value && ! preg_match( '/^\d+(?:\.\d+){0,2}$/', $value ) ) {
			return null;
		}
		$info[ $key ] = $value;
	}
	return $info;
}

/** Only HTTPS ZIP files in /wpla/ on aiframe.it can be offered or verified. */
function wpla_update_is_own_package( $url ) {
	$parts = wp_parse_url( (string) $url );
	return is_array( $parts ) && 'https' === ( $parts['scheme'] ?? '' ) && in_array( $parts['host'] ?? '', WPLA_UPDATE_HOSTS, true ) && empty( $parts['port'] ) && empty( $parts['query'] ) && preg_match( '~^/wpla/[0-9A-Za-z._-]+\.zip$~', $parts['path'] ?? '' );
}

/** Filter update_plugins_aiframe.it: WordPress compares the version and offers the update only when it is newer. */
function wpla_update_check( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( WPLA_PLUGIN_FILE ) !== $plugin_file ) {
		return $update;
	}
	$info = wpla_update_info();
	if ( ! $info ) {
		return $update;
	}
	// WordPress compares "tested" with the full version: like WordPress.org, "7.1" covers every 7.1.x release.
	$tested = $info['tested'];
	$wp_version = wp_get_wp_version();
	if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $wp_version, $tested . '.' ) ) {
		$tested = $wp_version;
	}
	return array(
		'slug'         => 'wpla-lead-assistant',
		'version'      => $info['version'],
		'url'          => 'https://aiframe.it/wpla/',
		'package'      => $info['package'],
		'requires'     => $info['requires'],
		'requires_php' => $info['requires_php'],
		'tested'       => $tested,
	);
}

/** "View details" in the plugin list. Without the update file this is an error, never another plugin with the same slug on WordPress.org. */
function wpla_update_details( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || 'wpla-lead-assistant' !== ( $args->slug ?? '' ) ) {
		return $result;
	}
	$info = wpla_update_info();
	if ( ! $info ) {
		return new WP_Error( 'wpla_update_unavailable', __( 'Le informazioni sull\'aggiornamento non sono disponibili. Riprova più tardi.', 'wpla-lead-assistant' ) );
	}
	return (object) array(
		'name'          => 'WP Lead Assistant',
		'slug'          => 'wpla-lead-assistant',
		'version'       => $info['version'],
		'author'        => 'WP Lead Assistant',
		'homepage'      => 'https://aiframe.it/',
		'requires'      => $info['requires'],
		'requires_php'  => $info['requires_php'],
		'tested'        => $info['tested'],
		'last_updated'  => $info['released'],
		'download_link' => $info['package'],
		'sections'      => array( 'changelog' => wpautop( esc_html( $info['changelog'] ) ) ),
	);
}

/** Downloads a package from aiframe.it only if it is the announced one, and installs it only if its SHA-256 matches. */
function wpla_update_download( $reply, $package ) {
	if ( false !== $reply || ! is_string( $package ) || ! wpla_update_is_own_package( $package ) ) {
		return $reply;
	}
	$info = wpla_update_info();
	if ( ! $info || $info['package'] !== $package ) {
		return new WP_Error( 'wpla_update_unknown', __( 'Il pacchetto non corrisponde all\'ultima versione annunciata. Controlla di nuovo gli aggiornamenti.', 'wpla-lead-assistant' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$file = download_url( $package, 300 );
	if ( is_wp_error( $file ) ) {
		return $file;
	}
	if ( ! hash_equals( $info['sha256'], (string) hash_file( 'sha256', $file ) ) ) {
		wp_delete_file( $file );
		return new WP_Error( 'wpla_update_hash', __( 'Il pacchetto scaricato non corrisponde a quello annunciato: aggiornamento annullato, il plugin installato non è cambiato.', 'wpla-lead-assistant' ) );
	}
	return $file;
}
