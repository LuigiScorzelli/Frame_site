<?php
/** Searchable source collection; bulk changes never edit the original WordPress pages. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_source_action_fields( $id, $action ) {
	wpla_workspace_fields( 'sources' );
	echo '<input type="hidden" name="source_ids[]" value="' . esc_attr( $id ) . '" /><input type="hidden" name="source_action" value="' . esc_attr( $action ) . '" />';
}

function wpla_render_analysis_exclusions( $sources ) {
	$excluded = array_filter( $sources, static function ( $row ) { return ! $row['enabled'] && ! empty( $row['analysis_error'] ); } );
	if ( ! $excluded ) {
		return;
	}
	echo '<details id="wpla-analysis-exclusions" open><summary><strong>' . esc_html( count( $excluded ) . ' fonti escluse con segnalazioni' ) . '</strong></summary><p>Non sono nella nuova documentazione. Il testo resta nel gestore: correggilo, includi la fonte e ripeti la creazione per riprovare. La documentazione e il prompt richiedono sempre approvazione.</p><ul>';
	foreach ( $excluded as $row ) {
		echo '<li><strong>' . esc_html( $row['title'] ) . ':</strong> ' . esc_html( $row['analysis_error'] ) . '</li>';
	}
	echo '</ul></details>';
}

function wpla_render_source_manager( $sources, $published ) {
	$types = array( 'page' => 'Pagina / articolo', 'product' => 'Prodotto', 'document' => 'Documento', 'manual' => 'Informazione manuale' );
	$current = wpla_current_sources( $published );
	$included = count( array_filter( $sources, static function ( $row ) { return (bool) $row['enabled']; } ) );
	?>
	<section id="wpla-source-manager" tabindex="-1" aria-label="Gestione delle fonti">
		<p><strong><?php echo esc_html( count( $sources ) . ' fonti · ' . $included . ' incluse nella prossima bozza · ' . ( count( $sources ) - $included ) . ' escluse' ); ?></strong></p>
		<p>“Escludi” conserva la fonte e la ritira subito dalle risposte. “Includi” la reinserisce nella selezione. “Rimuovi dal plugin” elimina il testo importato; non elimina pagine o prodotti dal sito. Una nuova scansione recupera le pagine rimosse e conserva le esclusioni. Se rimuovi una fonte approvata, la documentazione che la contiene viene ritirata: ricreala e approvala.</p>
		<div class="wpla-source-filters" hidden>
			<label>Cerca titolo o URL <input type="search" id="wpla-source-search" /></label>
			<label>Tipo <select id="wpla-source-kind"><option value="">Tutti i tipi</option><?php foreach ( $types as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
			<label>Selezione <select id="wpla-source-inclusion"><option value="">Incluse ed escluse</option><option value="1">Incluse</option><option value="0">Escluse</option></select></label>
			<label>Analisi <select id="wpla-source-state"><option value="">Tutti gli stati</option><option value="pending">Da analizzare</option><option value="ready">Analizzate</option><option value="error">Da correggere</option><option value="stale">Da riscansionare</option></select></label>
		</div>
		<form id="wpla-sources-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wpla_workspace_fields( 'sources' ); ?>
			<div class="wpla-source-toolbar">
				<label>Azione sulle fonti selezionate <select name="source_action" required><option value="">Scegli un’azione</option><option value="exclude">Escludi dalla documentazione</option><option value="include">Includi nella documentazione</option><option value="reanalyze">Ripeti l’analisi</option><option value="delete">Rimuovi dal plugin</option></select></label>
				<button class="button" type="submit">Applica alle selezionate</button>
				<span id="wpla-source-selection" role="status" aria-live="polite">0 selezionate</span>
				<button type="button" class="button-link" id="wpla-source-select-matching" hidden>Seleziona tutti i risultati</button>
				<button type="button" class="button-link" id="wpla-source-clear" hidden>Azzera selezione</button>
			</div>
			<p id="wpla-source-feedback" role="alert" hidden></p>
		</form>
		<div class="wpla-source-table-wrap">
		<table class="widefat striped wpla-source-table">
			<caption class="screen-reader-text">Fonti importate e loro utilizzo nella documentazione</caption>
			<thead><tr><td class="check-column"><input type="checkbox" id="wpla-source-select-page" aria-label="Seleziona le fonti di questa pagina" /></td><th scope="col">Fonte e testo letto</th><th scope="col">Tipo</th><th scope="col">Selezione e analisi</th><th scope="col">Azioni</th></tr></thead>
			<tbody>
			<?php foreach ( $sources as $row ) :
				$analysis = json_decode( $row['analysis'], true );
				$state = wpla_source_state( $row );
				?>
				<tr class="wpla-source" data-source="<?php echo esc_attr( $row['id'] ); ?>" data-title="<?php echo esc_attr( $row['title'] ); ?>" data-enabled="<?php echo esc_attr( $row['enabled'] ); ?>" data-kind="<?php echo esc_attr( $row['kind'] ); ?>" data-state="<?php echo esc_attr( $state[0] ); ?>" data-search="<?php echo esc_attr( $row['title'] . ' ' . $row['url'] ); ?>">
					<th scope="row" class="check-column"><input type="checkbox" class="wpla-source-check" name="source_ids[]" form="wpla-sources-form" value="<?php echo esc_attr( $row['id'] ); ?>" aria-label="<?php echo esc_attr( 'Seleziona ' . $row['title'] ); ?>" /></th>
					<td><strong><?php echo esc_html( $row['title'] ); ?></strong>
						<?php if ( $row['url'] ) : ?><p><a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $row['url'] ); ?>"><?php echo esc_html( $row['url'] ); ?></a></p><?php endif; ?>
						<details><summary>Testo letto · <?php echo esc_html( wpla_text_length( $row['content'] ) ); ?> caratteri</summary>
							<pre class="wpla-source-text"><?php echo esc_html( $row['content'] ); ?></pre>
							<?php if ( ! empty( $analysis['facts'] ) ) : ?><ul><?php foreach ( $analysis['facts'] as $fact ) : ?><li><strong><?php echo esc_html( $fact['label'] ); ?>:</strong> <?php echo esc_html( $fact['quote'] ); ?></li><?php endforeach; ?></ul><?php endif; ?>
						</details>
						<?php if ( ! $row['post_id'] ) : ?>
						<details><summary>Modifica il testo della fonte</summary>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wpla_workspace_fields( 'source_edit' ); ?>
								<input type="hidden" name="source_id" value="<?php echo esc_attr( $row['id'] ); ?>" />
								<p><label>Titolo <input name="title" value="<?php echo esc_attr( $row['title'] ); ?>" required maxlength="200" /></label></p>
								<p><label>Testo estratto o informazione manuale<textarea class="large-text" name="content" rows="6" required><?php echo esc_textarea( $row['content'] ); ?></textarea></label></p>
								<button type="submit" class="button">Salva il testo</button>
							</form>
						</details>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $types[ $row['kind'] ] ?? $row['kind'] ); ?></td>
					<td><strong><?php echo $row['enabled'] ? 'Inclusa' : 'Esclusa'; ?></strong><p class="wpla-source-status"><?php echo esc_html( $state[1] ); ?></p>
						<?php if ( ! $row['enabled'] && ! empty( $row['exclusion_reason'] ) ) : ?><p><?php echo esc_html( array( 'scope' => 'Fuori dalla selezione di scansione', 'analysis' => 'Esclusa automaticamente: non utilizzabile', 'manual' => 'Esclusa dal titolare' )[ $row['exclusion_reason'] ] ?? '' ); ?></p><?php endif; ?>
						<p class="wpla-source-error"><?php echo esc_html( $row['analysis_error'] ?? '' ); ?></p>
						<p><?php echo isset( $current[ $row['id'] ] ) ? 'In uso nella chat' : 'Non in uso nella chat'; ?></p>
					</td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_source_action_fields( $row['id'], $row['enabled'] ? 'exclude' : 'include' ); ?><button type="submit" class="button"><?php echo $row['enabled'] ? 'Escludi' : 'Includi'; ?></button></form>
						<form class="wpla-source-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wpla_source_action_fields( $row['id'], 'delete' ); ?><button type="submit" class="button-link-delete">Rimuovi dal plugin</button></form>
						<?php if ( $row['post_id'] ) : ?><p><a href="<?php echo esc_url( get_edit_post_link( $row['post_id'], 'raw' ) ); ?>">Modifica in WordPress</a></p><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<p id="wpla-source-empty" <?php echo $sources ? 'hidden' : ''; ?>>Nessuna fonte corrisponde ai filtri. Modifica la ricerca o scansiona il sito per aggiungere fonti.</p>
		<div class="wpla-source-pagination" hidden>
			<button type="button" class="button" id="wpla-source-prev">Precedente</button><span id="wpla-source-page" role="status" aria-live="polite"></span><button type="button" class="button" id="wpla-source-next">Successiva</button>
			<label>Fonti per pagina <select id="wpla-source-size"><option>20</option><option>50</option><option>100</option></select></label>
		</div>
	</section>
	<?php
}
