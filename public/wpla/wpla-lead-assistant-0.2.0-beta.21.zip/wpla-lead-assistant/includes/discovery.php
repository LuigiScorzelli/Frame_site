<?php
/** Explicit discovery scope: catalogue, services and customer assistance. No AI calls. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_discovery_types() {
	return array_values( array_diff( get_post_types( array( 'public' => true ), 'names' ), array( 'attachment', 'product', 'product_variation', 'e-landing-page', 'elementor_library' ) ) );
}

function wpla_discovery_skip_ids() {
	return array_filter( array_map( 'intval', array( get_option( 'woocommerce_cart_page_id' ), get_option( 'woocommerce_checkout_page_id' ), get_option( 'woocommerce_myaccount_page_id' ) ) ) );
}

function wpla_discovery_group( $post ) {
	if ( 'post' === $post->post_type ) {
		return 'other';
	}
	$label = wpla_text_lower( remove_accents( $post->post_title . ' ' . $post->post_name ) );
	// Utility pages must never be suggested merely because a plugin published them.
	if ( preg_match( '/\b(login|logout|register|registration|password|account|profile|profilo|registrazione|accedi|accesso|carrello|checkout|thank you|search users|user group|landing page)\b/u', str_replace( '-', ' ', $label ) ) ) {
		return 'other';
	}
	if ( in_array( (int) $post->ID, array_filter( array( (int) get_option( 'wp_page_for_privacy_policy' ), (int) get_option( 'woocommerce_terms_page_id' ) ) ), true ) ) {
		return 'support';
	}
	if ( preg_match( '/\b(contatt\w*|contact\w*|chi siamo|about\w*|azienda|spedizion\w*|shipping|delivery|consegn\w*|resi|reso|recess\w*|rimbor\w*|return\w*|refund\w*|pagament\w*|payment\w*|garanzi\w*|warrant\w*|faq|domande frequenti|assistenz\w*|support\w*|condizion\w*|terms|privacy|orari|sedi)\b/u', str_replace( '-', ' ', $label ) ) ) {
		return 'support';
	}
	return preg_match( '/\b(serviz\w*|service\w*|consulenz\w*|installazion\w*|manutenzion\w*|riparazion\w*)\b/u', str_replace( '-', ' ', $label ) ) ? 'service' : 'other';
}

function wpla_discovery_candidates() {
	$types = wpla_discovery_types();
	return $types ? get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'has_password' => false, 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post__not_in' => wpla_discovery_skip_ids() ) ) : array();
}

function wpla_discovery_settings() {
	$saved = get_option( 'wpla_discovery', false );
	$defaults = array( 'all_products' => false, 'product_terms' => array(), 'service_terms' => array(), 'service_ids' => array(), 'support_ids' => array(), 'extra_ids' => array() );
	if ( is_array( $saved ) ) {
		return wp_parse_args( $saved, $defaults );
	}
	foreach ( wpla_discovery_candidates() as $post ) {
		$group = wpla_discovery_group( $post );
		if ( 'support' === $group || ( 'service' === $group && 'servizi' === wpla_get_settings()['workflow_mode'] ) ) {
			$defaults[ 'support' === $group ? 'support_ids' : 'service_ids' ][] = (int) $post->ID;
		}
	}
	return $defaults;
}

function wpla_service_taxonomies() {
	$allowed = array();
	foreach ( get_taxonomies( array( 'public' => true, 'hierarchical' => true ), 'objects' ) as $tax ) {
		if ( array_intersect( $tax->object_type, wpla_discovery_types() ) ) {
			$allowed[ $tax->name ] = $tax;
		}
	}
	return $allowed;
}

function wpla_save_discovery( $input ) {
	$clean = array( 'all_products' => ! empty( $input['all_products'] ), 'product_terms' => array(), 'service_terms' => array() );
	foreach ( array( 'service_ids', 'support_ids', 'extra_ids' ) as $field ) {
		$clean[ $field ] = array_values( array_unique( array_filter( array_map( 'absint', is_array( $input[ $field ] ?? null ) ? $input[ $field ] : array() ) ) ) );
	}
	foreach ( is_array( $input['product_terms'] ?? null ) ? $input['product_terms'] : array() as $id ) {
		if ( taxonomy_exists( 'product_cat' ) && term_exists( absint( $id ), 'product_cat' ) ) {
			$clean['product_terms'][] = absint( $id );
		}
	}
	$taxonomies = wpla_service_taxonomies();
	foreach ( is_array( $input['service_terms'] ?? null ) ? $input['service_terms'] : array() as $term ) {
		$parts = explode( ':', (string) $term );
		if ( count( $parts ) === 2 && isset( $taxonomies[ $parts[0] ] ) && term_exists( absint( $parts[1] ), $parts[0] ) ) {
			$clean['service_terms'][] = $parts[0] . ':' . absint( $parts[1] );
		}
	}
	update_option( 'wpla_discovery', $clean, false );
	return true;
}

/** Resolve IDs only; reading full contents remains batched. An empty selection stays empty. */
function wpla_discovery_ids() {
	$s = wpla_discovery_settings();
	$ids = array_merge( $s['support_ids'], $s['extra_ids'] );
	$base = array( 'post_status' => 'publish', 'has_password' => false, 'fields' => 'ids', 'numberposts' => -1, 'orderby' => 'ID', 'order' => 'ASC' );
	if ( 'ecommerce' === wpla_get_settings()['workflow_mode'] && function_exists( 'wc_get_product' ) && ( $s['all_products'] || $s['product_terms'] ) ) {
		$args = array_merge( $base, array( 'post_type' => 'product' ) );
		if ( ! $s['all_products'] ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $s['product_terms'], 'include_children' => true ) );
		}
		$ids = array_merge( $ids, get_posts( $args ) );
	}
	if ( 'servizi' === wpla_get_settings()['workflow_mode'] ) {
		$ids = array_merge( $ids, $s['service_ids'] );
		$taxonomies = wpla_service_taxonomies();
		foreach ( $s['service_terms'] as $term ) {
			list( $taxonomy, $id ) = explode( ':', $term );
			if ( isset( $taxonomies[ $taxonomy ] ) ) {
				$ids = array_merge( $ids, get_posts( array_merge( $base, array( 'post_type' => $taxonomies[ $taxonomy ]->object_type, 'tax_query' => array( array( 'taxonomy' => $taxonomy, 'terms' => array( (int) $id ), 'include_children' => true ) ) ) ) ) );
			}
		}
	}
	$allowed_types = wpla_discovery_types();
	$skip = wpla_discovery_skip_ids();
	$ids = array_filter( array_unique( array_map( 'intval', $ids ) ), static function ( $id ) use ( $allowed_types, $skip ) {
		$post = get_post( $id );
		return $post && ! in_array( $id, $skip, true ) && ! $post->post_password && is_post_publicly_viewable( $post ) && ( in_array( $post->post_type, $allowed_types, true ) || ( 'product' === $post->post_type && 'ecommerce' === wpla_get_settings()['workflow_mode'] && function_exists( 'wc_get_product' ) && ( $product = wc_get_product( $id ) ) && $product->is_visible() ) );
	} );
	sort( $ids, SORT_NUMERIC );
	return array_values( $ids );
}

function wpla_render_discovery() {
	$s = wpla_discovery_settings();
	$groups = array( 'service' => array(), 'support' => array(), 'other' => array() );
	foreach ( wpla_discovery_candidates() as $post ) {
		$groups[ wpla_discovery_group( $post ) ][] = $post;
	}
	?>
	<form id="wpla-discovery-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wpla_workspace_fields( 'discovery' ); ?>
		<p>Scegli le categorie e le pagine prima della scansione. I suggerimenti dipendono dai titoli: controllali e aggiungi le pagine mancanti. La selezione non usa l’AI.</p>
		<?php if ( 'ecommerce' === wpla_get_settings()['workflow_mode'] ) : ?>
		<fieldset><legend><strong>Prodotti WooCommerce</strong></legend>
		<?php if ( function_exists( 'wc_get_product' ) ) : ?>
		<p><label><input type="checkbox" name="all_products" value="1" <?php checked( $s['all_products'] ); ?> /> Tutto il catalogo WooCommerce (scelta esplicita)</label></p>
		<div class="wpla-discovery-list">
		<?php $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) : ?>
		<label><input type="checkbox" name="product_terms[]" value="<?php echo esc_attr( $term->term_id ); ?>" <?php checked( in_array( (int) $term->term_id, $s['product_terms'], true ) ); ?> /> <?php echo esc_html( $term->name . ' (' . $term->count . ')' ); ?></label>
		<?php endforeach; ?></div>
		<p class="description">Sono comprese le sottocategorie. Si leggono solo schede visibili, con descrizioni, categorie, prezzi, varianti e disponibilità. Nessuna categoria selezionata = nessun prodotto importato.</p>
		<?php else : ?><p>WooCommerce non è attivo. Attivalo per leggere il catalogo oppure aggiungi documenti sui prodotti.</p><?php endif; ?>
		</fieldset>
		<?php else : ?>
		<fieldset><legend><strong>Categorie dei servizi</strong></legend><div class="wpla-discovery-list">
		<?php foreach ( wpla_service_taxonomies() as $taxonomy => $object ) :
			$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
			foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) : $value = $taxonomy . ':' . $term->term_id; ?>
		<label><input type="checkbox" name="service_terms[]" value="<?php echo esc_attr( $value ); ?>" <?php checked( in_array( $value, $s['service_terms'], true ) ); ?> /> <?php echo esc_html( $object->labels->singular_name . ': ' . $term->name . ' (' . $term->count . ')' ); ?></label>
		<?php endforeach; endforeach; ?></div><p class="description">Scegli solo categorie dedicate ai tuoi servizi. Se usi pagine senza categorie, selezionale qui sotto.</p></fieldset>
		<?php endif; ?>
		<?php foreach ( array( 'service' => array( 'Pagine dei servizi', 'service_ids' ), 'support' => array( 'Informazioni per l’assistenza clienti', 'support_ids' ), 'other' => array( 'Altre pagine: aggiungile solo se utili', 'extra_ids' ) ) as $group => $info ) :
			if ( 'service' === $group && 'ecommerce' === wpla_get_settings()['workflow_mode'] ) { $info = array( 'Altre pagine dei servizi (facoltative)', 'extra_ids' ); }
		?>
		<details <?php echo 'other' !== $group ? 'open' : ''; ?>><summary><?php echo esc_html( $info[0] . ' · ' . count( $groups[ $group ] ) ); ?></summary>
		<label>Cerca in questo gruppo <input type="search" class="wpla-discovery-search" /></label>
		<div class="wpla-discovery-list">
		<?php foreach ( $groups[ $group ] as $post ) : ?>
		<label data-discovery-title="<?php echo esc_attr( $post->post_title ); ?>"><input type="checkbox" name="<?php echo esc_attr( $info[1] ); ?>[]" value="<?php echo esc_attr( $post->ID ); ?>" <?php checked( in_array( (int) $post->ID, array_merge( $s['service_ids'], $s['support_ids'], $s['extra_ids'] ), true ) ); ?> /> <?php echo esc_html( $post->post_title . ' — ' . $post->post_type ); ?></label>
		<?php endforeach; ?></div></details>
		<?php endforeach; ?>
		<?php submit_button( 'Salva la selezione e mostra il riepilogo', 'secondary' ); ?>
		<p class="description">La scansione usa la selezione salvata. Alla scansione, le vecchie fonti del sito fuori selezione saranno escluse e conservate nel gestore; documenti caricati e informazioni manuali restano disponibili. Le esclusioni già impostate nel gestore non vengono annullate.</p>
	</form>
	<?php $ids = wpla_discovery_ids(); ?>
	<p id="wpla-discovery-summary"><strong><?php echo esc_html( count( $ids ) . ( is_array( get_option( 'wpla_discovery', false ) ) ? ' pagine e prodotti nella selezione salvata' : ' pagine e prodotti suggeriti: salva la selezione per scansionare' ) ); ?></strong></p>
	<details><summary>Anteprima delle fonti da scansionare</summary><ul>
	<?php foreach ( $ids as $id ) : ?><li><?php echo esc_html( get_the_title( $id ) . ( 'product' === get_post_type( $id ) ? ' — WooCommerce' : '' ) ); ?></li><?php endforeach; ?>
	</ul></details>
	<?php
}

function wpla_terms_changed( $object_id, $terms, $tt_ids, $taxonomy ) {
	if ( 'product_cat' === $taxonomy || isset( wpla_service_taxonomies()[ $taxonomy ] ) ) {
		wpla_post_changed( $object_id );
	}
}

function wpla_term_changed( $term_id, $tt_id, $taxonomy, $deleted_term = null, $object_ids = array() ) {
	if ( 'product_cat' !== $taxonomy && ! isset( wpla_service_taxonomies()[ $taxonomy ] ) ) {
		return;
	}
	$ids = $object_ids ?: get_objects_in_term( $term_id, $taxonomy );
	foreach ( is_array( $ids ) ? $ids : array() as $id ) {
		wpla_post_changed( $id );
	}
}
