<?php
/** GDPR tools for the site owner: export and erasure by visitor email, suggested privacy policy text. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WPLA_PRIVACY_PAGE = 50;

function wpla_privacy_register_exporter( $exporters ) {
	$exporters['wpla-lead-assistant'] = array( 'exporter_friendly_name' => 'WP Lead Assistant', 'callback' => 'wpla_privacy_export' );
	return $exporters;
}

function wpla_privacy_register_eraser( $erasers ) {
	$erasers['wpla-lead-assistant'] = array( 'eraser_friendly_name' => 'WP Lead Assistant', 'callback' => 'wpla_privacy_erase' );
	return $erasers;
}

/**
 * Leads whose contact email is $email, oldest first. Only the email field counts: an address quoted
 * in someone else's conversation must not expose or delete that lead (D-029). The LIKE on the JSON
 * payload narrows the rows; the exact match is checked after decoding.
 */
function wpla_privacy_leads( $email, $offset ) {
	global $wpdb;
	$email = strtolower( trim( (string) $email ) );
	if ( ! is_email( $email ) ) {
		return array();
	}
	$needle = '%' . $wpdb->esc_like( substr( wp_json_encode( array( 'email' => $email ) ), 1, -1 ) ) . '%';
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wpla_leads WHERE payload LIKE %s ORDER BY id ASC", $needle ), ARRAY_A );
	$leads = array();
	foreach ( $rows as $row ) {
		$payload = json_decode( $row['payload'], true );
		if ( is_array( $payload ) && is_string( $payload['email'] ?? null ) && strtolower( $payload['email'] ) === $email ) {
			$row['payload'] = $payload;
			$leads[] = $row;
		}
	}
	return array_slice( $leads, $offset, WPLA_PRIVACY_PAGE );
}

function wpla_privacy_export( $email, $page = 1 ) {
	$leads = wpla_privacy_leads( $email, ( max( 1, (int) $page ) - 1 ) * WPLA_PRIVACY_PAGE );
	$data = array();
	foreach ( $leads as $row ) {
		$p = $row['payload'];
		$conversation = '';
		foreach ( (array) ( $p['conversation'] ?? array() ) as $m ) {
			if ( is_array( $m ) && is_string( $m['text'] ?? null ) ) {
				$conversation .= ( 'user' === ( $m['role'] ?? '' ) ? 'Visitatore' : 'Assistente' ) . ': ' . $m['text'] . "\n";
			}
		}
		$values = array(
			'Richiesta' => '#' . $row['id'],
			'Ricevuta il (UTC)' => $row['created_at'],
			'Nome' => $p['name'] ?? '',
			'Email' => $p['email'] ?? '',
			'Telefono' => $p['phone'] ?? '',
			'Consegna al titolare' => 'accepted' === $row['delivery'] ? 'Email accettata dal servizio email' : 'Email non ancora consegnata',
			'Consenso' => $p['consent_text'] ?? '',
			'Versione dell’informativa' => $p['consent_version'] ?? '',
			'Consenso dato il' => $p['consented_at'] ?? '',
			'Informativa' => $p['privacy_url'] ?? '',
			'Conversazione' => trim( $conversation ),
		);
		$item = array();
		foreach ( $values as $name => $value ) {
			if ( '' !== (string) $value ) {
				$item[] = array( 'name' => $name, 'value' => (string) $value );
			}
		}
		$data[] = array( 'group_id' => 'wpla-leads', 'group_label' => 'Richieste di contatto (WP Lead Assistant)', 'item_id' => 'wpla-lead-' . $row['id'], 'data' => $item );
	}
	return array( 'data' => $data, 'done' => count( $leads ) < WPLA_PRIVACY_PAGE );
}

/** Deleted rows are gone, so every page reads from the start. Undelivered leads are erased too (D-029). */
function wpla_privacy_erase( $email, $page = 1 ) {
	$leads = wpla_privacy_leads( $email, 0 );
	$removed = false;
	foreach ( $leads as $row ) {
		$removed = wpla_local_delete_lead( (int) $row['id'] ) || $removed;
	}
	return array( 'items_removed' => $removed, 'items_retained' => false, 'messages' => array(), 'done' => count( $leads ) < WPLA_PRIVACY_PAGE );
}

/** Text proposed in Settings › Privacy; it follows the current retention and provider. */
function wpla_privacy_policy_text() {
	$days = wpla_get_settings()['lead_retention_days'];
	$provider = 'anthropic' === wpla_ai_settings()['provider'] ? 'Anthropic' : 'OpenAI';
	$paragraphs = array(
		'Questo sito usa WP Lead Assistant, un assistente via chat. I messaggi scritti nella chat sono inviati al server del sito, che li trasmette, insieme ai brani delle pagine del sito usati per rispondere, al fornitore di intelligenza artificiale scelto dal titolare (oggi ' . $provider . ') per generare la risposta. I dati di contatto non sono inviati al fornitore.',
		'La conversazione resta sul server del sito per al massimo 24 ore, per dare continuità alle risposte, e nel browser del visitatore (sessionStorage) finché la scheda resta aperta. Per limitare gli abusi il sito salva un’impronta cifrata dell’indirizzo IP, mai l’indirizzo in chiaro, per al massimo un giorno.',
		'Se il visitatore compila il modulo di contatto e conferma il consenso, il sito salva nome, email e/o telefono, il riepilogo della conversazione, il testo e la data del consenso, e invia la richiesta via email al destinatario indicato dal titolare.',
		'Le richieste consegnate per email sono conservate per ' . $days . ' giorni e poi cancellate automaticamente. Le richieste non consegnate (per esempio se la posta del sito non funziona) restano finché il titolare non le rinvia o le elimina, per non perdere una richiesta che il titolare non ha mai ricevuto.',
		'L’interessato può chiedere una copia o la cancellazione delle proprie richieste indicando l’email usata nel modulo: il titolare le gestisce da Strumenti › Esporta dati personali e Strumenti › Cancella dati personali. Le richieste lasciate con il solo telefono si cancellano dal pannello del plugin.',
	);
	return '<p>' . implode( '</p><p>', array_map( 'esc_html', $paragraphs ) ) . '</p>';
}

function wpla_register_privacy_text() {
	if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
		wp_add_privacy_policy_content( 'WP Lead Assistant', wpla_privacy_policy_text() );
	}
}
