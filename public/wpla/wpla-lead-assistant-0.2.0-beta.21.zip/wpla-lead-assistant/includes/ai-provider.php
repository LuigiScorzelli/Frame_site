<?php
/** Server-side provider credentials and bounded API requests for the standalone beta. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wpla_ai_settings() {
	return wp_parse_args( get_option( 'wpla_ai_settings', array() ), array(
		'provider' => 'openai', 'openai_model' => 'gpt-4.1-mini',
		'anthropic_model' => 'claude-haiku-4-5-20251001', 'workspace' => '',
		'consent' => false, 'daily_limit' => 100,
	) );
}

function wpla_encrypt_secret( $plain ) {
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return new WP_Error( 'crypto_missing', 'Questo hosting deve abilitare OpenSSL per custodire la chiave API.' );
	}
	$iv = random_bytes( 12 );
	$tag = '';
	$cipher = openssl_encrypt( $plain, 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, $iv, $tag );
	return false === $cipher ? new WP_Error( 'crypto_failed', 'Impossibile custodire la chiave API.' ) : base64_encode( $iv . $tag . $cipher );
}

function wpla_ai_key_constant( $provider ) {
	return 'openai' === $provider ? 'WPLA_OPENAI_API_KEY' : 'WPLA_ANTHROPIC_API_KEY';
}

/** A key defined in wp-config.php wins over the panel: say so, never show it. */
function wpla_ai_key_notice( $provider ) {
	$constant = wpla_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		return 'Viene usata la chiave definita in wp-config.php (' . $constant . '): prevale su quella inserita qui. Per usare la chiave del pannello, rimuovi la costante da wp-config.php.';
	}
	return wpla_ai_key( $provider ) ? 'Chiave già presente. Lascia vuoto per conservarla.' : 'Chiave non ancora inserita.';
}

function wpla_ai_key( $provider ) {
	$constant = wpla_ai_key_constant( $provider );
	if ( defined( $constant ) ) {
		return (string) constant( $constant );
	}
	$vault = get_option( 'wpla_ai_credentials', array() );
	$raw = base64_decode( $vault[ $provider ] ?? '', true );
	if ( ! $raw || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}
	return openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) ) ?: '';
}

function wpla_ai_save( $input ) {
	$old = wpla_ai_settings();
	$provider = in_array( $input['provider'] ?? '', array( 'openai', 'anthropic' ), true ) ? $input['provider'] : 'openai';
	$settings = $old;
	$settings['provider'] = $provider;
	$settings['consent'] = ! empty( $input['consent'] );
	$settings['daily_limit'] = max( 1, min( 1000, (int) ( $input['daily_limit'] ?? 100 ) ) );
	$settings['workspace'] = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $input['workspace'] ?? '' ) );
	foreach ( array( 'openai_model', 'anthropic_model' ) as $field ) {
		$settings[ $field ] = preg_replace( '/[^A-Za-z0-9._:-]/', '', (string) ( $input[ $field ] ?? $old[ $field ] ) );
		if ( ! $settings[ $field ] ) {
			return new WP_Error( 'model_missing', 'Inserisci il nome del modello per entrambi i provider.' );
		}
	}
	$vault = get_option( 'wpla_ai_credentials', array() );
	foreach ( array( 'openai', 'anthropic' ) as $name ) {
		if ( ! empty( $input[ 'remove_' . $name ] ) ) {
			unset( $vault[ $name ] );
		}
		$key = trim( (string) ( $input[ $name . '_key' ] ?? '' ) );
		if ( $key ) {
			if ( strlen( $key ) > 512 || preg_match( '/\s/', $key ) ) {
				return new WP_Error( 'key_invalid', 'La chiave API contiene caratteri non validi.' );
			}
			$encrypted = wpla_encrypt_secret( $key );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$vault[ $name ] = $encrypted;
		}
	}
	update_option( 'wpla_ai_credentials', $vault, false );
	update_option( 'wpla_ai_settings', $settings, false );
	return true;
}

/** Atomic counters bound public inference spending and flood attempts across PHP workers. */
function wpla_take_quota( $bucket, $limit, $window ) {
	global $wpdb;
	$period = (int) floor( time() / $window );
	$key = hash( 'sha256', $bucket . ':' . $period );
	$table = $wpdb->prefix . 'wpla_counters';
	$ok = $wpdb->query( $wpdb->prepare(
		"INSERT INTO $table (bucket, hits, expires) VALUES (%s, 1, %d) ON DUPLICATE KEY UPDATE hits = hits + 1",
		$key, ( $period + 1 ) * $window
	) );
	return false !== $ok && (int) $wpdb->get_var( $wpdb->prepare( "SELECT hits FROM $table WHERE bucket = %s", $key ) ) <= $limit;
}

/** Absolute time (microtime) by which every AI call must finish; 0 means no limit. Set by the public chat. */
function wpla_ai_deadline( $at = null ) {
	static $deadline = 0;
	if ( null !== $at ) {
		$deadline = (float) $at;
	}
	return $deadline;
}

/** True while the public chat is answering: its calls use the share of the daily limit the panel cannot take. */
function wpla_ai_for_chat( $on = null ) {
	static $chat = false;
	if ( null !== $on ) {
		$chat = (bool) $on;
	}
	return $chat;
}

function wpla_ai_request( $system, $message, $max_tokens = 1200, $pdf = null, $timeout = 25 ) {
	$s = wpla_ai_settings();
	$key = wpla_ai_key( $s['provider'] );
	if ( ! $s['consent'] ) {
		return new WP_Error( 'ai_consent_missing', 'Prima del test seleziona la casella “Autorizzo l’invio al provider selezionato…” e premi “Salva e prova il collegamento AI”.' );
	}
	if ( ! $key ) {
		$label = 'openai' === $s['provider'] ? 'OpenAI' : 'Anthropic';
		$vault = get_option( 'wpla_ai_credentials', array() );
		if ( ! empty( $vault[ $s['provider'] ] ) ) {
			return new WP_Error( 'ai_key_unreadable', 'Non riesco a leggere la chiave API salvata per ' . $label . '. Reinseriscila e premi “Salva e prova il collegamento AI”.' );
		}
		return new WP_Error( 'ai_key_missing', 'Non risulta una chiave API salvata per ' . $label . '. Inseriscila nel campo del provider selezionato e premi “Salva e prova il collegamento AI”.' );
	}
	$deadline = wpla_ai_deadline();
	if ( $deadline ) {
		$left = (int) floor( $deadline - microtime( true ) );
		if ( $left < 2 ) {
			return new WP_Error( 'ai_budget', 'Tempo massimo della risposta raggiunto.' );
		}
		$timeout = min( $timeout, $left );
	}
	// One daily limit; calls outside the public chat may use 70% of it, so the panel never leaves the chat without answers.
	$panel_limit = max( 1, (int) floor( $s['daily_limit'] * 0.7 ) );
	if ( ! wpla_ai_for_chat() && ! wpla_take_quota( 'ai-admin', $panel_limit, DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ai_admin_limit', 'Il pannello ha usato oggi le sue ' . $panel_limit . ' richieste AI su ' . $s['daily_limit'] . ': il resto è riservato alla chat. Riprova domani o alza "Richieste AI al giorno".' );
	}
	if ( ! wpla_take_quota( 'ai-site', $s['daily_limit'], DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ai_daily_limit', 'Raggiunto il limite giornaliero di richieste AI del sito.' );
	}
	if ( 'openai' === $s['provider'] ) {
		$content = array( array( 'type' => 'input_text', 'text' => $message ) );
		if ( $pdf ) {
			array_unshift( $content, array( 'type' => 'input_file', 'filename' => 'document.pdf', 'file_data' => 'data:application/pdf;base64,' . base64_encode( $pdf ) ) );
		}
		$url = 'https://api.openai.com/v1/responses';
		$headers = array( 'Authorization' => 'Bearer ' . $key );
		$body = array( 'model' => $s['openai_model'], 'instructions' => $system, 'input' => array( array( 'role' => 'user', 'content' => $content ) ), 'store' => false, 'max_output_tokens' => $max_tokens );
	} else {
		$content = array( array( 'type' => 'text', 'text' => $message ) );
		if ( $pdf ) {
			array_unshift( $content, array( 'type' => 'document', 'source' => array( 'type' => 'base64', 'media_type' => 'application/pdf', 'data' => base64_encode( $pdf ) ) ) );
		}
		$url = 'https://api.anthropic.com/v1/messages';
		$headers = array( 'x-api-key' => $key, 'anthropic-version' => '2023-06-01' );
		if ( $s['workspace'] ) {
			$headers['anthropic-workspace-id'] = $s['workspace'];
		}
		$body = array( 'model' => $s['anthropic_model'], 'system' => $system, 'messages' => array( array( 'role' => 'user', 'content' => $content ) ), 'max_tokens' => $max_tokens );
	}
	$headers['Content-Type'] = 'application/json';
	$seconds = max( 1, min( 25, (int) $timeout ) );
	$response = wp_remote_post( $url, array( 'headers' => $headers, 'body' => wp_json_encode( $body ), 'timeout' => $seconds, 'redirection' => 0, 'limit_response_size' => 600000 ) );
	// Never return provider response bodies: they may contain secrets or sensitive input.
	if ( is_wp_error( $response ) ) {
		// A slow answer is not a connection problem: cURL error 28 and the streams transport both say "timed out".
		if ( preg_match( '/cURL error 28|timed out/i', $response->get_error_message() ) ) {
			return new WP_Error( 'ai_timeout', 'Il provider non ha completato la risposta entro ' . $seconds . ' secondi. Riprova; se succede ancora, riduci il testo da elaborare.' );
		}
		return new WP_Error( 'ai_network', 'Il provider non risponde. Controlla la connessione e riprova.' );
	}
	$code = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		$constant = wpla_ai_key_constant( $s['provider'] );
		$messages = array( 401 => defined( $constant ) ? 'Chiave API non valida. È la chiave definita in wp-config.php (' . $constant . '), che prevale su quella del pannello.' : 'Chiave API non valida.', 403 => 'Il conto non ha accesso al modello o al workspace.', 429 => 'Quota o limite del provider raggiunto.' );
		return new WP_Error( 'ai_http', $messages[ $code ] ?? 'Richiesta AI non riuscita. Verifica modello, credito e compatibilità del file.', array( 'http_status' => $code ) );
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	$text = '';
	if ( 'openai' === $s['provider'] ) {
		if ( 'completed' !== ( $data['status'] ?? '' ) ) {
			return new WP_Error( 'ai_incomplete', 'Risposta AI incompleta. Riduci la fonte o usa un modello compatibile.' );
		}
		foreach ( $data['output'] ?? array() as $item ) {
			foreach ( $item['content'] ?? array() as $part ) {
				if ( 'output_text' === ( $part['type'] ?? '' ) ) {
					$text .= $part['text'];
				}
			}
		}
	} else {
		if ( ! in_array( $data['stop_reason'] ?? '', array( 'end_turn', 'stop_sequence' ), true ) ) {
			return new WP_Error( 'ai_incomplete', 'Risposta AI incompleta. Riduci la fonte o usa un modello compatibile.' );
		}
		foreach ( $data['content'] ?? array() as $part ) {
			if ( 'text' === ( $part['type'] ?? '' ) ) {
				$text .= $part['text'];
			}
		}
	}
	return trim( $text ) ?: new WP_Error( 'ai_empty', 'Il provider non ha restituito testo utilizzabile.' );
}

/** The connection check must use the fields the customer has just submitted. */
function wpla_ai_save_and_test( $input ) {
	$saved = wpla_ai_save( $input );
	return is_wp_error( $saved ) ? $saved : wpla_ai_connection_test();
}

/** An accepted request proves key, model and quota: a reasoning model may spend the small budget thinking and return no text. */
function wpla_ai_connection_test() {
	$result = wpla_ai_request( 'Rispondi solo OK.', 'Prova del collegamento.', 50 );
	return is_wp_error( $result ) && in_array( $result->get_error_code(), array( 'ai_incomplete', 'ai_empty' ), true ) ? 'OK' : $result;
}

function wpla_ai_json( $text ) {
	$text = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', trim( $text ) );
	$data = json_decode( $text, true );
	return is_array( $data ) ? $data : new WP_Error( 'ai_json', 'Risposta AI non valida. La bozza precedente è conservata; riprova.' );
}
