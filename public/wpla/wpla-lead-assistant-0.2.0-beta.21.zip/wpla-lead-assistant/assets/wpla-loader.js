(function () {
  'use strict';

  var cfg = window.WPLA_PLUGIN_CONFIG;
  if (!cfg || !cfg.assetUrl || !cfg.endpoint || !cfg.siteKey) return;
  var loaded = false;
  var timer;
  var events = ['scroll', 'pointerdown', 'keydown'];

  function load() {
    if (loaded) return;
    loaded = true;
    clearTimeout(timer);
    events.forEach(function (event) { window.removeEventListener(event, load); });
    if (window.WPLA && window.WPLA.__loaded) return;

    var script = document.createElement('script');
    script.src = cfg.assetUrl;
    script.async = true;
    script.dataset.wplaPlugin = 'true';
    var keys = ['endpoint', 'siteKey', 'mode', 'title', 'company', 'color', 'position',
      'welcome', 'privacyUrl', 'fallbackPhone', 'fallbackEmail', 'suggestions', 'launcherLabel', 'consentText'];
    keys.forEach(function (key) { script.dataset[key] = cfg[key] || ''; });
    script.dataset.open = new URLSearchParams(window.location.search).get('wpla') === 'open' ? 'true' : 'false';
    document.body.appendChild(script);
  }

  events.forEach(function (event) { window.addEventListener(event, load, { passive: true }); });
  timer = window.setTimeout(load, 3000);
})();
