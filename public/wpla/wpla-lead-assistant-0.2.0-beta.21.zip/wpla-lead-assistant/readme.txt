=== WP Lead Assistant ===
Contributors: wpla
Tags: lead generation, chat, customer support
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 8.3
Stable tag: 0.2.0-beta.21
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI assistant with your OpenAI or Anthropic API key, site discovery and reviewed knowledge. Free private beta; provider usage is billed separately.

== Description ==

Choose services or products, select WooCommerce/service categories and useful customer assistance pages, scan the saved selection, optionally import TXT/MD, DOCX or PDF documentation, and review a generated knowledge draft before approving it. WooCommerce sources include pricing, stock status and variations. The chat retrieves original passages from approved sources. Unverified answers can fall back to a contact form.

The administrator workspace manages provider connection, sources, approval and recent leads. API keys are encrypted server-side using WordPress security salts. Changing those salts requires entering keys again. OpenSSL is required; DOCX extraction also requires ZipArchive.

Test visibility is restricted to administrators and to whoever opens the private preview link. Appearance, page visibility, shortcode [wpla_chat] and a WP Lead Assistant block are available.

Limits: 3 MB per uploaded file and 60 KB extracted text per source. Only DOCX body text is extracted. PDF extraction uses the selected provider in a single request of at most 25 seconds and must be reviewed; in tests a 10-page text PDF was already at that limit, so split longer PDFs into parts of a few pages. Discovery reads native public WordPress content rather than crawling external sites; some page builders and dynamically rendered content may need supplementary documentation. Changed sources must be rescanned, reanalysed and approved. This beta combines lexical retrieval with bounded AI selection among approved quotations and original passages; it does not guarantee every answer is correct.

== External services ==

The plugin requires an OpenAI API account or an Anthropic Claude API account with available credit. The plugin is free; API usage, including analysis, PDF extraction, connection tests and visitor chat, is billed by the selected provider. A provider subscription is not automatically an API credential.

After an administrator saves credentials and authorizes processing, selected source text, uploaded PDF content when applicable, and chat messages needed for a response are sent to the chosen provider. Keys are never sent to the public browser. No external AI calls are made just by activating the plugin. The request count limit is not a currency spending cap; configure spending controls with the provider too.

OpenAI: https://api.openai.com/v1/responses (store:false)
Documentation: https://developers.openai.com/api/reference/overview
Terms: https://openai.com/policies/services-agreement/
Privacy: https://openai.com/policies/privacy-policy/

Anthropic: https://api.anthropic.com/v1/messages
Documentation: https://platform.claude.com/docs/en/api/overview
Terms: https://www.anthropic.com/legal/commercial-terms
Privacy: https://www.anthropic.com/legal/privacy

Plugin updates: when WordPress checks for plugin updates (about twice a day, and when you open Plugins or Dashboard > Updates), the plugin reads https://aiframe.it/wpla/update.json. The request sends no site address, cookies or other site data. When a newer version is announced and you update, the ZIP file is downloaded from https://aiframe.it/wpla/ and installed only if its SHA-256 matches the one announced.

== Data handling ==

Extracted source text and approved knowledge are stored in private plugin database tables/options. Original document uploads are not published in the media library. Information approved for the assistant can appear in public replies; do not approve confidential material.

The widget uses sessionStorage for the current tab. Server conversations are stored in a private database table, become unreadable after one day and are deleted by daily WP-Cron cleanup. Contacts are submitted only after the form is confirmed; stored leads include consent evidence and the recent server conversation. Leads whose notification email was accepted are kept for 30 days by default (7, 30, 90, 180 or 365, chosen in Received requests) and then deleted by daily WP-Cron cleanup. Leads whose email was never accepted stay until the owner resends or deletes them. Failed wp_mail submissions are retried through WP-Cron; mail acceptance does not guarantee inbox delivery. Backups and the selected provider have their own retention policies.

Tools > Export Personal Data and Tools > Erase Personal Data find the leads whose contact email matches the request, including undelivered ones; leads with only a phone number are deleted from the plugin panel. Server conversations are not linked to an email and expire after one day. Settings > Privacy suggests a privacy policy text that states these retention periods and the AI provider in use.

Cleanup and retries depend on WP-Cron, which WordPress runs only when someone visits the site. If the daily cleanup has not run for more than 48 hours, or is not scheduled, the plugin panel shows a warning and Received requests shows the last cleanup time. To make cleanup reliable, ask your host for a real cron job every 15 minutes, for example `wget -q -O - "https://example.com/wp-cron.php?doing_wp_cron" >/dev/null 2>&1`; once it works you may add `define( 'DISABLE_WP_CRON', true );` to wp-config.php so WordPress stops starting cron on page visits.

Deactivation retains data. Uninstall removes local settings, keys, knowledge, conversations and leads.

== Installation ==

1. Upload the distribution ZIP and activate it.
2. Open Settings > WP Lead Assistant. Choose services or products, lead email, privacy policy and Test visibility.
3. Configure your selected provider API key and explicitly authorize processing. Use Save and test AI connection to save the entered values and test them in one action.
4. Select WooCommerce/service categories and customer assistance pages, save the scope, review its preview and scan. Add supplementary documents if needed.
5. Rebuild the knowledge document. Unusable sources are automatically excluded with reasons; useful sources form a draft. Review the draft and editable agent system prompt, then approve both. Open the preview chat and verify answers and lead delivery.
6. Set visibility to Public and save only when the test is complete. Use HTTPS. The main panel explains any missing requirements that keep the widget hidden; public mode requires approved current knowledge and a privacy policy link.

== Changelog ==

= 0.2.0-beta.21 =
* Privacy tools for the site owner: Tools > Export Personal Data and Tools > Erase Personal Data include the plugin's contact requests, found by the email entered in the form. Erasure also removes undelivered requests and their pending retries; requests with only a phone number are deleted from the plugin panel.
* Received requests lets the owner choose how long delivered requests are kept: 7, 30, 90, 180 or 365 days (default 30, as before). Undelivered requests stay until the owner resends or deletes them.
* Settings > Privacy suggests a privacy policy text with the AI provider, the 24-hour server conversations, the hashed IP, the retention days and the undelivered requests.
* The plugin panel warns when the daily cleanup has not run for more than 48 hours or is not scheduled, and Received requests shows the last cleanup time. The Data handling section explains how to set up a real cron job with your host.

= 0.2.0-beta.20 =
* No changes to how the plugin works. This version exists to check the in-WordPress update from aiframe.it: on a site with 0.2.0-beta.19 it appears in Dashboard > Updates and installs keeping settings, keys, sources and requests.

= 0.2.0-beta.19 =
* Updates arrive inside WordPress: a newer version announced on aiframe.it appears in Dashboard > Updates and on the Plugins page, with "View details" and the changelog, and installs like any other plugin update, keeping settings, keys, sources and requests. The downloaded package is installed only if its SHA-256 matches the announced one; a missing, slow or invalid update file offers nothing and changes nothing. The first version with updates must still be installed with "Replace current with uploaded".

= 0.2.0-beta.18 =
* The chat contact form no longer moves the cursor to the name field while the visitor is already typing in another field. Previously a fast visitor could see the email typed into the name field and the request was rejected.
* When WPLA_OPENAI_API_KEY or WPLA_ANTHROPIC_API_KEY is defined in wp-config.php, the settings page says that this key overrides the one entered in the panel (under the key field and after saving), and a rejected key (HTTP 401) names the constant. The key value is never shown.
* A PDF that takes longer than 25 seconds to read now says it is too long and should be split, instead of "The provider is not responding. Check the connection". A slow provider answer elsewhere is reported as a timeout, not as a connection problem. The settings page and this readme state the practical PDF limit: a few pages per file.
* The chat no longer rejects a correct answer when a number has an Italian thousands separator in only one of the two texts: "6.000" in the source and "6000" in the answer, or the other way round, now match. Only groups of three digits separated by dots count (for example 10.240 or 1.000.000); decimals are unchanged and different numbers never match.
* Rebuilding the documentation or analysing many sources no longer leaves the chat without answers for the rest of the day. There is still one "Richieste AI al giorno" limit, but settings-page operations (analysis, PDFs, connection checks, source search) may use at most 70% of it; the rest is reserved for the chat.
* A contact request whose notification email was never accepted by the mail service is no longer deleted after 30 days: it stays until you resend or delete it. The settings page highlights undelivered requests at the top and in "Richieste ricevute", lists them first, and every request has a new "Elimina la richiesta" button. Accepted requests are still deleted after 30 days.
* "Salva e prova il collegamento AI" now succeeds with reasoning models. The check used to ask for "OK" with a 50-token budget, which a reasoning model spends thinking, and reported an incomplete answer even with a correct key and model. An answer accepted by the provider now confirms the connection; a rejected key still fails.
* The chat always answers before the widget gives up (30 seconds). All AI calls for one message must now finish within 24 seconds, and assisted source selection may use at most 12 of them; a call that can no longer finish in time is not sent. Previously a slow provider could keep the visitor waiting until the widget showed "service not responding" while the server kept working.
* A page deleted or made private while a scan is running no longer breaks the scan or shifts later pages out of it. The page list is fixed by the first batch; pages that disappear meanwhile are skipped and listed in the scan result.
* After "Ricrea la documentazione" the draft to approve is always scrolled into view. Previously the browser could restore the old scroll position on reload and leave the draft off screen.

= 0.2.0-beta.17 =
* Requires WordPress 7.0 and PHP 8.3 (previously 6.4 and 8.0, never tested). Tested on WordPress 7.0 and 7.1 with PHP 8.3.
* Trusted proxies ("Proxy fidati" in the technical settings, "Rete" section): behind Cloudflare, a CDN or a reverse proxy, per-visitor limits use the visitor IP from X-Forwarded-For, read only for requests that come from the listed addresses. Previously every visitor behind a proxy shared one limit.
* The settings page and this readme no longer state that signed-in users can see the chat in "Test only" mode; since 0.2.0-beta.16 only administrators and holders of the preview link can.

= 0.2.0-beta.16 =
* Approved sources are withdrawn only when the text the chat reads actually changes: saving a page without edits or an order that lowers the stock quantity no longer removes products from the chat. Price, availability, privacy and deletion changes still withdraw them immediately.
* Saving or deleting a post that is not a source no longer discards the documentation draft awaiting approval.
* In "Test only" mode the chat and its preview token are visible only to administrators and to whoever opens the preview link; registered customers no longer see it. "Public" mode is unchanged and shows the chat to everyone.

= 0.2.0-beta.15 =
* Short price or availability follow-ups use a single previously cited approved source. When several products could be meant, the chat asks which one instead of choosing an arbitrary price.
* Weak lexical passages are included in the original-passage check after an empty fact selection, so a documented answer is not discarded solely because its fact was omitted from the short index.

= 0.2.0-beta.14 =
* When an approved fact was omitted from the short analysis index, a documented answer can still be found by generating bounded search terms and selecting an exact passage from current approved source text.
* The extra search uses at most two AI calls with shorter timeouts, and is skipped if earlier selection already used its time budget. Only original approved passages can reach answer generation.

= 0.2.0-beta.13 =
* Retrieval now distinguishes a genuine no-match from an unavailable AI selection caused by provider failure, invalid references, an empty fact index or an index size limit.
* Temporary admin diagnostics and source lookup show the selection status. Visitors receive a neutral verification message when selection was unavailable, without disclosing provider details.

= 0.2.0-beta.12 =
* The administrator can review unanswered questions from the existing one-day chat sessions and retry them in the approved-source lookup.
* Retrieval misses and rejected citations now carry their diagnostic code in temporary session history. The admin view masks emails, links and long numbers; expired and converted sessions are excluded.

= 0.2.0-beta.11 =
* Approved facts are selected in up to three complete bounded groups when their index exceeds one provider request. Candidates from different groups receive a final selection of at most three original quotations.
* If the complete index exceeds the bounded group limit or provider selection fails, lexical retrieval remains available. Difficult questions may consume up to four extra AI requests for selection.

= 0.2.0-beta.10 =
* Chat can ask the configured provider to select up to three exact approved quotations when lexical retrieval is empty or weak; unknown and invalid fact references are rejected.
* The live chat loads approved fact analyses for retrieval. Administrators can optionally test the AI selection from the source lookup; this may consume one daily AI request.
* Generic retrieval cases and integration checks cover paraphrases, weak matches, unrelated questions and invented references.

= 0.2.0-beta.9 =
* Retrieval matches common alternate customer wording, uses approved fact labels to locate original passages, prioritizes complete product identifiers, and keeps overlapping citation passages.
* A rejected quotation or numeric claim gets at most one correction attempt against the same approved passages. Different numeric values remain blocked; equivalent decimal formatting is accepted.
* The administrator lookup shows the selected passages. Chat responses expose a non-sensitive diagnostic code for a retrieval miss or rejected evidence.

= 0.2.0-beta.8 =
* Product codes repeated from a verified source title no longer cause an otherwise cited answer to be rejected as an unsupported number.
* Other numbers still require an exact numeric match in a verified citation; unverified technical specifications and prices remain blocked.

= 0.2.0-beta.7 =
* Removed the n8n connection option, webhook diagnostic and external chat routing from the WordPress plugin.
* Upgrading removes saved legacy webhook URL, site key and engine choice; approved local sources, API keys and leads are preserved.
* Existing installations must configure an AI provider and approve local knowledge before enabling the chat.

= 0.2.0-beta.6 =
* Saved discovery scope with WooCommerce categories and descendants, service categories/pages, suggested contact/about/shipping/returns/FAQ pages, and an explicit preview.
* Old out-of-scope imports are retained but excluded. Manual exclusions remain respected when categories are reselected.
* Unusable source text or analysis is automatically excluded with persistent reasons while useful sources continue to a draft. Account, quota and network failures remain retryable without discarding sources.
* Editable agent system prompt generated alongside knowledge, versioned with approval and preserved across rebuilds. Mandatory evidence checks remain active.
* Additive schema upgrade records exclusion provenance; settings, keys and existing data are retained.


= 0.2.0-beta.5 =
* Broad product/service questions retrieve an overview of approved sources; keyword matching handles basic Italian singular/plural forms and product codes.
* Greetings receive a conversational reply without AI requests. New questions are searched before earlier conversation terms.
* Administrator source lookup diagnostic shows approved source counts and matched titles without calling AI.
* Notification panel shows the actual recipient, test email, safe per-lead transport errors and attempt details, plus explicit resend for accepted notifications.
* Mail transport exceptions no longer interrupt contact capture. Inbox delivery still requires checking the site's mail service.


= 0.2.0-beta.4 =
* Searchable source table with type/status/inclusion filters, pagination and bulk include, exclude, reanalyse and remove actions.
* Imported document text can be corrected; original site pages remain editable in WordPress and are never deleted by source removal.
* Persistent source diagnostics and title-only detection before AI calls. Sources without valid evidence are reported while other analyses continue; explicit correction or exclusion is required before building the draft.
* Scan refreshes the collection and retains warnings. Existing exclusions survive rescans; removed site sources can be reimported.
* Additive database migration preserves existing settings, keys and sources.


= 0.2.0-beta.3 =
* Knowledge generation progress and errors appear beside the generation button, including the source that interrupted analysis.
* Successful generation opens and focuses the draft review section with explicit approval instructions.

= 0.2.0-beta.2 =
* Connection testing saves the entered provider, model, key and explicit authorization in the same action.
* Separate actionable errors for missing authorization, missing API key and unreadable stored key.
* Main workspace explains hidden chat with the same readiness checks used by the frontend, including unapproved/stale knowledge and missing privacy policy.
* Public site link and page-filter/cache guidance after configuration is ready.

= 0.2.0-beta.1 =
* Standalone customer workspace, encrypted OpenAI/Anthropic keys, site and WooCommerce discovery, document import and reviewed knowledge generation.
* Source withdrawal on change, source-backed chat, local leads and consent evidence, bounded API request counts and scheduled retention.
* Existing n8n mode retained. Private beta; account sign-in and automatic distribution updates are not included.

= 0.1.0 =
* First private pilot release.
