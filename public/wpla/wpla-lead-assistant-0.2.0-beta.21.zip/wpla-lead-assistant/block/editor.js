(function (blocks, element, components) {
  'use strict';
  blocks.registerBlockType('wpla/chat', {
    edit: function () {
      return element.createElement(components.Placeholder, {
        icon: 'format-chat',
        label: 'WP Lead Assistant',
        instructions: 'Il widget chat apparirà su questa pagina. Configuralo in Impostazioni → WP Lead Assistant.'
      });
    },
    save: function () { return null; }
  });
})(window.wp.blocks, window.wp.element, window.wp.components);
